﻿using MC300V31.Model;
using mcDAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MC300V31.Views.MeasurePage
{
    /// <summary>
    /// RegisterDialog.xaml 的交互逻辑
    /// </summary>
    public partial class RegisterDialog 
    {
        UserInfoDAL userInfoDAL = null;
        UserInfoEntity userinfo = new UserInfoEntity();
        UserViewModel userViewModel = new UserViewModel();
        private Action<UserInfoEntity> tabAction;
        public RegisterDialog(Action<UserInfoEntity> tAction)
        {
            InitializeComponent();
            DataContext = userViewModel;
            tabAction = tAction;
        }
        private void Clear_Click(object sender, RoutedEventArgs e)
        {
            tabAction.Invoke(userinfo);
        }
        /// <summary>
        /// 查询用户名是否被用过
        /// </summary>
        /// <param name="userLoginName"></param>
        /// <returns></returns>
        private bool userLoginNameUsed(string userLoginName)
        {
            bool isUsed = false;
            List<UserInfoEntity> foundUsers = new List<UserInfoEntity>();
            string conditionStr = " userID ='" + userLoginName + "'";
            foundUsers = userInfoDAL.Finds(conditionStr);
            if (foundUsers.Count > 0)
            {
                isUsed = true;
            }
            return isUsed;
        }

        private void Commit_Click(object sender, RoutedEventArgs e)
        {
            if (userViewModel.UserName == "" || userViewModel.UserID == "" || userViewModel.BirthDay == "")
            {
                HandyControl.Controls.Growl.Info("请将信息填写完整！", "SuccessMsg");
                return;
            }
            //查看用户名是否被使用过
            if (userLoginNameUsed(userViewModel.UserID))
            {
                HandyControl.Controls.Growl.Warning("用户名已被使用，请重新填写！", "SuccessMsg");
                return;
            }
            //校验数据合法性 todo
            if (userViewModel.UserWeight < 10 || userViewModel.UserWeight > 1000)
            {
                HandyControl.Controls.Growl.Warning("体重填写有误，请重新填写！", "SuccessMsg");
                return;
            }
            if (userViewModel.UserHeight < 30 || userViewModel.UserHeight > 300)
            {
                HandyControl.Controls.Growl.Warning("身高填写有误，请重新填写！", "SuccessMsg");
                return;
            }
            userinfo.UserId = userViewModel.UserID;
            userinfo.UserName = userViewModel.UserName;
            userinfo.UserSex = userViewModel.UserSex;
            DateTime date = DateTime.Parse(userViewModel.BirthDay);
            userinfo.UserBirthday = date.ToString("d");
            userinfo.UserHeight = userViewModel.UserHeight;
            userinfo.UserWeight = userViewModel.UserWeight;
            userinfo.CreateTime = DateTime.Now.ToString();
            double[] Temp_Distance = new double[3];
            Temp_Distance[0] = (double)(0.8129 * userinfo.UserHeight + 12.328);
            Temp_Distance[1] = (double)(0.2195 * userinfo.UserHeight - 2.0734);
            Temp_Distance[2] = Temp_Distance[0] - Temp_Distance[1];
            userinfo.UserDistance = (float)Math.Round((decimal)Temp_Distance[2], 1, MidpointRounding.AwayFromZero);
            DateTime bir;
            if (DateTime.TryParse(userinfo.UserBirthday, out bir))
            {
                userinfo.UserAge = DateTime.Now.Year - bir.Year;
                if (DateTime.Now.Month < bir.Month)
                {
                    userinfo.UserAge -= 1;
                }
            }
            if (userinfo.UserAge < 7 || userinfo.UserAge > 100)
            {
                HandyControl.Controls.Growl.Warning("出生日期填写有误，请重新填写！", "SuccessMsg");
                return;
            }
            if (userInfoDAL.Insert(userinfo) > 0)
            {
                tabAction.Invoke(userinfo);
                HandyControl.Controls.Growl.Success("用户注册成功！", "SuccessMsg");
                {
                    GC.Collect();
                }

            }
            else
            {
                HandyControl.Controls.Growl.Warning("用户注册失败！", "SuccessMsg");

            }
        }

        private void Border_Loaded(object sender, RoutedEventArgs e)
        {
            userInfoDAL = UserInfoDAL.getInstance();
            userViewModel.UserID = LoginPage.userID;
        }
    }
}
