﻿using FastReport;
using FastReport.Export.Pdf;
using FastReport.MSChart;
using MC300V31.Chart;
using mcAlgorithm;
using mcDAL;
using mcUntil;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ZedGraph;
using FastReport.Preview;
using FastReport.Utils;
using System.Windows.Media.Media3D;
using FastReport.Data;
using FastReport.Export.PS;
using Newtonsoft.Json;
using System.Threading;
using mcBLL;
using System.ComponentModel;
using 动脉硬化;
using System.Reflection;

namespace MC300V31.Views.MeasurePage
{
    /// <summary>
    /// OpenReportPage.xaml 的交互逻辑
    /// </summary>
    public partial class OpenReportPage : Page, INotifyPropertyChanged
    {
        /// <summary>
        /// 数据绑定
        /// </summary>
        #region
        private string image1 = "";
        public string Image1
        {
            get { return image1; }
            set
            {
                image1 = value;
                if (PropertyChanged != null) PropertyChanged(this, new PropertyChangedEventArgs("Image1"));
            }
        }

        private string image2 = "";
        public string Image2
        {
            get { return image2; }
            set
            {
                image2 = value;
                if (PropertyChanged != null) PropertyChanged(this, new PropertyChangedEventArgs("Image2"));
            }
        }

        private string isRunning = "Hidden";
        public string IsRunning
        {
            get { return isRunning; }
            set
            {
                isRunning = value;
                if (PropertyChanged != null) PropertyChanged(this, new PropertyChangedEventArgs("IsRunning"));
            }
        }
        public event PropertyChangedEventHandler PropertyChanged;
        #endregion

        int LeftFlag;
        //ReportPreview preview = new ReportPreview();
        private Report pReport = null;   //实例化一个Report报表; //新建一个私有变量
        private ZedGraphControl zedGraph_Left = null; //绘制左侧测试记录曲线
        private ZedGraphControl zedGraph_Right = null; //绘制右侧测试记录曲线
        private ZedGraphControl zedGraph_ECGPCG = null; //绘制ECGPCG测试记录曲线
        private ZedGraphControl zedGraph_AI = null; //绘制AI测试记录曲线
        PulseDataLocalEntity testResult = null;// 测试的结果实体
        private ZedGraphControl zedGraph_test = null; //绘制测试记录曲线
        private TestZedgraph testZedGraph = null;//测试中zedGraph的操作类
        System.Drawing.Image Left_image = null;
        System.Drawing.Image Right_image = null;
        System.Drawing.Image ECGPCG_image = null;
        System.Drawing.Image AI_image = null;
        string chineseSimpleFrl = System.IO.Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + "\\Resources\\Template\\Chinese.frl";
        
        string reportFile = "./Resources/Template/WPFABIAI202.frx";
        //string reportFile = "./Resources/Template/WPFPWV.frx";
        //public List<BitmapImage> pages = new List<BitmapImage>();
        List<string> fileUrls = new List<string>();
        public OpenReportPage(PulseDataLocalEntity testData)
        {
            InitializeComponent();
            //传入参数
            testResult = testData;
            DataContext = this;
        }

        private void Window_OnLoaded(object sender, RoutedEventArgs e)
        { 
            APPSettingUtil.LoadData();
            if (TestMode.AI_Select)
            {
                reportFile = "./Resources/Template/WPFABIAI202.frx";
                Grid.SetColumn(previewControl1, 0);
                //Grid.SetColumn(previewControl2, 1);
            }
            //else if (TestMode.ECGPCG_Select)
            //{

            //}
            else
            {
                Grid.SetColumn(previewControl1, 0);
                //Grid.SetColumnSpan(previewControl2, 2);
                reportFile = "./Resources/Template/WPFABIAI02.frx";
            }
            Thread thread = new Thread(() =>
            {
                IsRunning = "Visible";
                FastReport.Utils.Res.LoadLocale(chineseSimpleFrl);
                pReport = new Report();
                pReport.Load(reportFile);  //载入报表文件
                EnvironmentSettings s = new EnvironmentSettings();
                s.ReportSettings.ShowProgress = false;
                FastReport.Export.Image.ImageExport ex = new FastReport.Export.Image.ImageExport();
                zedGraph_Left = new ZedGraphControl(); //绘制左侧测试记录曲线
                //zedGraph_Right = new ZedGraphControl(); //绘制左侧测试记录曲线
                //zedGraph_ECGPCG = new ZedGraphControl(); //绘制左侧测试记录曲线
                zedGraph_AI = new ZedGraphControl(); //绘制左侧测试记录曲线
                testZedGraph = new TestZedgraph();//测试中zedGraph的操作类
                ex.HasMultipleFiles = true;
                ex.ImageFormat = FastReport.Export.Image.ImageExportFormat.Png;
                ex.Resolution = 192;
                SetReportData();//设置变量数据
                SetReportChart();
                pReport.Prepare();
                try
                {
                    ex.Export(pReport, Directory.GetCurrentDirectory() + "/Report/test.png");
                }
                catch
                {

                }
                foreach (string file in ex.GeneratedFiles)
                {
                    fileUrls.Add(file);
                }
                //Image1 = fileUrls[0];
                //if (testResult.AI_num == 1)
                //{
                //    Image2 = fileUrls[1];
                //    Dispatcher.BeginInvoke(new Action(() =>
                //    {
                //        previewControl2.Visibility = Visibility.Hidden;
                //        Grid.SetColumn(previewControl2, 0);
                //        Grid.SetColumnSpan(previewControl2, 2);
                //    }));
                //}
                IsRunning = "Hidden";
            });
            thread.Start();
        }

        /// <summary>
        /// 设置报告数据
        /// </summary>
        private void SetReportData()
        {
            //SetTxt("txt_userId", testResult.userId);
            //SetTxt("txt_userName", testResult.userName);
            //SetTxt("txt_userSex", testResult.userSex);
            //SetTxt("txt_Sex", testResult.userSex);
            //SetTxt("txt_userAge", testResult.userAge + " 岁");
            //SetTxt("txt_Age", testResult.userAge.ToString());
            //SetTxt("txt_userHeight", testResult.userHeight.ToString() + " CM");
            //SetTxt("txt_userWeight", testResult.userWeight.ToString() + " Kg");
            //SetTxt("TestDate", testResult.TestDate);
            //SetTxt("txt_LtABI", testResult.LeftABI.ToString("f2"));
            //SetTxt("txt_RtABI", testResult.RightABI.ToString("f2"));
            //SetTxt("txt_ABIAssess", testResult.ABIAssess);
            //SetTxt("txt_LBSbp", testResult.LeftBraSbp.ToString());
            //SetTxt("txt_LBDbp", testResult.LeftBraDbp.ToString());
            //SetTxt("txt_LBMap", testResult.LeftBraMap.ToString());
            //SetTxt("txt_LBPp", (testResult.LeftBraSbp - testResult.LeftBraDbp).ToString());
            //SetTxt("txt_LASbp", testResult.LeftAnkSbp.ToString());
            //SetTxt("txt_LADbp", testResult.LeftAnkDbp.ToString());
            //SetTxt("txt_LAMap", testResult.LeftAnkMap.ToString());
            //SetTxt("txt_LAPp", (testResult.LeftAnkSbp - testResult.LeftAnkDbp).ToString());
            //SetTxt("txt_RBSbp", testResult.RightBraSbp.ToString());
            //SetTxt("txt_RBDbp", testResult.RightBraDbp.ToString());
            //SetTxt("txt_RBMap", testResult.RightBraMap.ToString());
            //SetTxt("txt_RBPp", (testResult.RightBraSbp - testResult.RightBraDbp).ToString());
            //SetTxt("txt_RASbp", testResult.RightAnkSbp.ToString());
            //SetTxt("txt_RADbp", testResult.RightAnkDbp.ToString());
            //SetTxt("txt_RAMap", testResult.RightAnkMap.ToString());
            //SetTxt("txt_RAPp", (testResult.RightAnkSbp - testResult.RightAnkDbp).ToString());
            //SetTxt("txt_LbaPWV", testResult.LbaPWV.ToString("f2"));
            //SetTxt("txt_RbaPWV", testResult.RbaPWV.ToString("f2"));
            //SetTxt("txt_PWVAssess", testResult.PWVAssess);
            //SetTxt("txt_DiagnosisResult", testResult.DiagnosisResult);
            //SetTxt("txt_DiagnosisProposal", testResult.DiagnosisProposal);

            SetTxt("txt_userId", testResult.userId);
            SetTxt("txt_userName", testResult.userName);
            SetTxt("txt_userSex", testResult.userSex);
            SetTxt("txt_userAge", testResult.userAge + " 岁");
            SetTxt("txt_userHeight", testResult.userHeight.ToString() + " cm");
            SetTxt("txt_userWeight", testResult.userWeight.ToString() + " kg");
            SetTxt("TestDate", testResult.TestDate);
            SetTxt("txt_HR", testResult.Hr.ToString());
            SetTxt("txt_ED", testResult.Ed.ToString());
            SetTxt("txt_SPTI", testResult.Spti.ToString());
            SetTxt("txt_DPTI", testResult.Dpti.ToString());
            SetTxt("txt_SEVR", testResult.Sevr.ToString());
            SetTxt("txt_SBP", testResult.Sbp.ToString());
            SetTxt("txt_SBP1", testResult.Sbp.ToString());
            SetTxt("txt_DBP", testResult.Dbp.ToString());
            SetTxt("txt_DBP1", testResult.Dbp.ToString());
            SetTxt("txt_PP", testResult.Pp.ToString());
            SetTxt("txt_SBP2", testResult.Sbp2.ToString());
            SetTxt("txt_AI", testResult.AIx.ToString());
            SetTxt("txt_AIDiagnosisResult", testResult.AIDiagnosisResult.ToString());
            SetTxt("txt_AIDiagnosisProposal", testResult.AIDiagnosisProposal.ToString());

            //if (testResult.AI_num == 1) //判断是否勾选测试心血管
            //{
            //    SetTxt("txt_Id1", testResult.userId);
            //    SetTxt("txt_userName1", testResult.userName);
            //    SetTxt("txt_userSex1", testResult.userSex);
            //    SetTxt("txt_userAge1", testResult.userAge + " 岁");
            //    SetTxt("txt_userHeight", testResult.userHeight.ToString() + " cm");
            //    SetTxt("txt_userWeight", testResult.userWeight.ToString() + " kg");
            //    SetTxt("TestDate1", testResult.TestDate);
            //    SetTxt("txt_HR", testResult.Hr.ToString());
            //    SetTxt("txt_ED", testResult.Ed.ToString());
            //    SetTxt("txt_SPTI", testResult.Spti.ToString());
            //    SetTxt("txt_DPTI", testResult.Dpti.ToString());
            //    SetTxt("txt_SEVR", testResult.Sevr.ToString());
            //    SetTxt("txt_SBP", testResult.Sbp.ToString());
            //    SetTxt("txt_DBP", testResult.Dbp.ToString());
            //    SetTxt("txt_PP", testResult.Pp.ToString());
            //    SetTxt("txt_SBP2", testResult.Sbp2.ToString());
            //    SetTxt("txt_AI", testResult.AIx.ToString());
            //    SetTxt("txt_AIDiagnosisResult", testResult.AIDiagnosisResult.ToString());
            //    SetTxt("txt_AIDiagnosisProposal", testResult.AIDiagnosisProposal.ToString());
            //}
            //if (testResult.ECG_num == 1)
            //{
            //    SetTxt("PEP", testResult.PEP.ToString());
            //    SetTxt("ET", testResult.ET.ToString());
            //    SetTxt("ET_PEP", testResult.ET_PEP.ToString());
            //    SetTxt("LeftBraUT", testResult.LeftBraUT.ToString());
            //    SetTxt("LeftAnkUT", testResult.LeftAnkUT.ToString());
            //    SetTxt("RightBraUT", testResult.RightBraUT.ToString());
            //    SetTxt("RightAnkUT", testResult.RightAnkUT.ToString());
            //    SetTxt("LeftBraMAP_PER", testResult.LeftBraMAP_PER.ToString());
            //    SetTxt("LeftAnkMAP_PER", testResult.LeftAnkMAP_PER.ToString());
            //    SetTxt("RightBraMAP_PER", testResult.RightBraMAP_PER.ToString());
            //    SetTxt("RightAnkMAP_PER", testResult.RightAnkMAP_PER.ToString());
            //}
            //ABIPicLocationSize(testResult.LeftABI, testResult.RightABI);
            //PWVPicLocationSize(testResult.LbaPWV, testResult.RbaPWV, testResult.userAge);
        }
        /// <summary>
        /// 设置报告Chart图
        /// </summary>
        private void SetReportChart()
        {
            //testZedGraph.InitialLeftReport(zedGraph_Left);//初始化图像
            //testZedGraph.InitialRightReport(zedGraph_Right);//初始化图像
            testZedGraph.InitialEPReport(zedGraph_ECGPCG);//初始化图像
            testZedGraph.InitialAI(zedGraph_AI);//初始化图像
            if (testResult.PWV_num != 0)
                ZedGraphDataInitial();
            //zedGraph_Left.Size = new System.Drawing.Size(1688, 786);
            //Left_image = zedGraph_Left.GetImage();
            //zedGraph_Right.Size = new System.Drawing.Size(1688, 786);
            //Right_image = zedGraph_Right.GetImage();

            //FastReport.PictureObject leftpicture = new FastReport.PictureObject();
            //leftpicture = (FastReport.PictureObject)pReport.FindObject("PictureLeft");
            //leftpicture.Image = Left_image;

            //FastReport.PictureObject rightpicture = new FastReport.PictureObject();
            //rightpicture = (FastReport.PictureObject)pReport.FindObject("PictureRight");
            //rightpicture.Image = Right_image;
            //if (testResult.ECG_num == 1)
            //{
            //    zedGraph_ECGPCG.Size = new System.Drawing.Size(1688, 786);
            //    ECGPCG_image = zedGraph_ECGPCG.GetImage();
            //    FastReport.PictureObject eppicture = new FastReport.PictureObject();
            //    eppicture = (FastReport.PictureObject)pReport.FindObject("PictureECGPCG");
            //    eppicture.Image = ECGPCG_image;                                                                                                         
            ////}
            //if (testResult.AI_num == 1)
            //{
                zedGraph_AI.Size = new System.Drawing.Size(1688, 786);
                AI_image = zedGraph_AI.GetImage();
                FastReport.PictureObject aipicture = new FastReport.PictureObject();
                aipicture = (FastReport.PictureObject)pReport.FindObject("PictureAI");                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
                aipicture.Image = AI_image;
            //}
        }
        private void SetTxt(string key, string value)
        {
            FastReport.TextObject txt = (FastReport.TextObject)pReport.FindObject(key);
            txt.Text = value;
        }
        /// <summary>
        /// ABI位置
        /// </summary>
        /// <param name="BMIvalue"></param>
        /// <param name="oCR"></param>
        //private void ABIPicLocationSize(double LABI, double RABI)
        //{
        //    float LABIvalue = (float)LABI;
        //    float RABIvalue = (float)RABI;
        //    float PosX1 = 28f;//起点位置
        //    float PosX2 = 175f;//分界线
        //    float PosX3 = 320f;//分界线
        //    float PosX4 = 350;//终点线
        //    LeftFlag++;
        //    float PositionX = 0f;
        //    //左侧
        //    if (LABIvalue < 0.4)
        //        PositionX = PosX1;//起点位置
        //    else if (LABIvalue >= 0.4 & LABIvalue < 0.9)
        //        PositionX = PosX1 + (PosX2 - PosX1) * (LABIvalue - (float)0.4) / ((float)0.9 - (float)0.4);
        //    else if (LABIvalue >= 0.9 & LABIvalue < 1.4)
        //        PositionX = PosX2 + (PosX3 - PosX2) * (LABIvalue - (float)0.9) / ((float)1.4 - (float)0.9);
        //    else if (LABIvalue >= 1.4 & LABIvalue < 1.5)
        //        PositionX = PosX3 + (PosX4 - PosX3) * (LABIvalue - (float)1.4) / ((float)1.5 - (float)1.4);
        //    else if (LABIvalue >= 1.5)
        //        PositionX = PosX4;
        //    FastReport.PictureObject picLeftABI = (FastReport.PictureObject)pReport.FindObject("picLeftABI");
        //    picLeftABI.Left = PositionX;
        //    //右侧
        //    if (RABIvalue < 0.4)
        //        PositionX = PosX1;//起点位置
        //    else if (RABIvalue >= 0.4 & RABIvalue < 0.9)
        //        PositionX = PosX1 + (PosX2 - PosX1) * (RABIvalue - (float)0.4) / ((float)0.9 - (float)0.4);
        //    else if (RABIvalue >= 0.9 & RABIvalue < 1.4)
        //        PositionX = PosX2 + (PosX3 - PosX2) * (RABIvalue - (float)0.9) / ((float)1.4 - (float)0.9);
        //    else if (RABIvalue >= 1.4 & RABIvalue < 1.5)
        //        PositionX = PosX3 + (PosX4 - PosX3) * (RABIvalue - (float)1.4) / ((float)1.5 - (float)1.4);
        //    else if (RABIvalue >= 1.5)
        //        PositionX = PosX4;
        //    FastReport.PictureObject picRightABI = (FastReport.PictureObject)pReport.FindObject("picRightABI");
        //    picRightABI.Left = PositionX;
        //    LeftFlag = 0;
        //}

        //pwv图片位置
        //private void PWVPicLocationSize(double lbpwv, double rbpwv, int age)
        //{
        //    float lbPwvValue = (float)lbpwv;
        //    float rbPwvValue = (float)rbpwv;
        //    float PosX1 = 62;//起始位置
        //    float PosX2 = 350;//终点位置
        //    float PosY1 = 750;//起点
        //    float PosY2 = 894;//终点
        //    float PositionX;
        //    float PositionY;
        //    if (lbPwvValue <= 8)
        //    {
        //        PositionY = PosY2;
        //    }
        //    else if (lbPwvValue > 8 && lbPwvValue < 24)
        //    {
        //        PositionY = PosY2 - (PosY2 - PosY1) * ((lbPwvValue - 8) / 16);
        //    }
        //    else
        //    {
        //        PositionY = PosY1;
        //    }
        //    PictureObject piclbpwvValue = (PictureObject)pReport.FindObject("picLeftPWV");
        //    piclbpwvValue.Top = (int)PositionY;
        //    if (rbPwvValue <= 8)
        //    {
        //        PositionY = PosY2;
        //    }
        //    else if (rbPwvValue > 8 && rbPwvValue < 24)
        //    {
        //        PositionY = PosY2 - (PosY2 - PosY1) * ((rbPwvValue - 8) / 16);
        //    }
        //    else
        //    {
        //        PositionY = PosY1;
        //    }
        //    PictureObject picrbpwvValue = (PictureObject)pReport.FindObject("picRightPWV");
        //    picrbpwvValue.Top = (int)PositionY;
        //    PositionX = PosX1 + (PosX2 - PosX1) * (float)((double)(age - 20) / (80 - 20));
        //    piclbpwvValue.Left = PositionX;
        //    picrbpwvValue.Left = PositionX;
        //    picrbpwvValue.Visible = true;
        //    piclbpwvValue.Visible = true;


        //}
        /// <summary>
        /// 初始化数据
        /// </summary>
        private void ZedGraphDataInitial()
        {
            string lcpdatalist = testResult.LCpRawData;
            string lfpdatalist = testResult.LFpRawData;
            //string rcpdatalist = testResult.RCpRawData;
            //string rfpdatalist = testResult.RFpRawData;
            string aidatalist = testResult.RpRawData;
            //string ecgdatalist = testResult.ECGRawData;
            //string pcgdatalist = testResult.PCGRawData;
            //if (testResult.LABP_Select == "1")
            //{
                //string[] lfpList = lfpdatalist.Split(';');
                //for (int i = 0; i < lfpList.Length; i++)
                //{
                //    testZedGraph.PlotTestDataLF(zedGraph_Left, Convert.ToDouble(lfpList[i]), i);
                //}
            //}
            if (testResult.LBBP_Select == "1")
            {
                //string[] lcpList = lcpdatalist.Split(';');
                //for (int i = 0; i < lcpList.Length; i++)
                //{
                //    testZedGraph.PlotTestDataLC(zedGraph_Left, Convert.ToDouble(lcpList[i]), i);
                //}
            }
            //if (testResult.RBBP_Select == "1")
            //{
            //    string[] rcpList = rcpdatalist.Split(';');
            //    for (int i = 0; i < rcpList.Length; i++)
            //    {
            //        testZedGraph.PlotTestDataRC(zedGraph_Right, Convert.ToDouble(rcpList[i]), i);
            //    }
            //}
            //if (testResult.RABP_Select == "1")
            //{
            //    string[] rfpList = rfpdatalist.Split(';');
            //    for (int i = 0; i < rfpList.Length; i++)
            //    {
            //        testZedGraph.PlotTestDataRF(zedGraph_Right, Convert.ToDouble(rfpList[i]), i);
            //    }
            //}
            //if (testResult.ECG_num == 1)
            //{
            //    if (ecgdatalist != "")
            //    {
            //        string[] ecgList = ecgdatalist.Split(';');
            //        for (int i = 0; i < ecgList.Length; i++)
            //        {
            //            testZedGraph.PlotTestDataECG(zedGraph_Right, Convert.ToDouble(ecgList[i]), i);
            //        }
            //    }
            //    if (pcgdatalist != "")
            //    {
            //        string[] pcgList = pcgdatalist.Split(';');
            //        for (int i = 0; i < pcgList.Length; i++)
            //        {
            //            if (i % 5 == 0)
            //            {
            //                testZedGraph.PlotTestDataPCG(zedGraph_Right, Convert.ToDouble(pcgList[i]), i);
            //            }
            //        }
            //    }
            //}
            if (testResult.AI_num == 1)
            {
                string[] aiList = aidatalist.Split(';');
                for (int i = 0; i < aiList.Length; i++)
                {
                    testZedGraph.PlotTestDataAI(zedGraph_AI, Convert.ToDouble(aiList[i])-280, i);
                }
            }
        }
        private void PrintBtn(object sender, RoutedEventArgs e)
        {
            pReport.Print();
        }
        private void SaveBtn(object sender, RoutedEventArgs e)
        {
            SaveFileDialog saveImageDialog = new SaveFileDialog();
            saveImageDialog.Title = "保存文件";
            saveImageDialog.Filter = "(*.pdf)|*.pdf";
            saveImageDialog.DefaultExt = ".pdf";
            if (saveImageDialog.ShowDialog() == DialogResult.OK)
            {
                Thread thread = new Thread(() =>
                {
                    Dispatcher.Invoke(new Action(() => {
                        SaveBtnO.IsEnabled = false;
                    }));
                    PDFExport export = new PDFExport();
                    export.Export(pReport, saveImageDialog.FileName);
                    HandyControl.Controls.Growl.Success("保存成功！");
                    Dispatcher.Invoke(new Action(() => {
                        SaveBtnO.IsEnabled = true;
                    }));
                });
                thread.Start();
            }
            else
            {
            }
        }
        private void UploadBtn(object sender, RoutedEventArgs e)
        {
            ThreadAPIStart();
        }
        
        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            bool isVisible = (bool)e.NewValue;//判断当前界面是否可见
            if (!isVisible)//不可见主动回收资源
            {
                GC.Collect();
            }
        }

        private async void InsertNet()
        {
            try
            {
                Dispatcher.Invoke(new Action(() => {
                    Upload.IsEnabled = false;
                }));
                PDFExport export = new PDFExport();
                string filePath = System.IO.Directory.GetCurrentDirectory() + "/"+ testResult.Report_Name;
                export.Export(pReport,filePath);
                var code = await ApiBLL.CommitDataAPI(testResult, filePath);
                if (code == 200)
                {
                    HandyControl.Controls.Growl.Success("数据上传成功！");
                }
                else
                {
                    HandyControl.Controls.Growl.Success("数据上传失败！");
                }
                File.Delete(filePath);
                Dispatcher.Invoke(new Action(() => {
                    Upload.IsEnabled = true;
                }));
            }
            catch (Exception ex)
            {
                Dispatcher.Invoke(new Action(() => {
                    Upload.IsEnabled = true;
                }));
                HandyControl.Controls.Growl.Success("数据上传失败！");
                LogUtil.Error("上传数据", ex.Message);
            }

        }

        private void ThreadAPIStart()
        {
            Thread thread = new Thread(() =>
            {
                InsertNet();
            });
            thread.Start();
        }

        private void BackBtn(object sender, RoutedEventArgs e)
        {
            this.NavigationService.GoBack();
        }

        private new void ManipulationBoundaryFeedback(object sender, ManipulationBoundaryFeedbackEventArgs e)
        {
            e.Handled = true;
        }
    }
}
