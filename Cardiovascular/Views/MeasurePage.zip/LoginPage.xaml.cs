﻿using HandyControl.Controls;
using MC300V31.Model;
using MC300V31.Views.UserManagePage;
using mcBLL;
using mcDAL;
using mcUntil;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Web.UI.WebControls;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MC300V31.Views.MeasurePage
{
    /// <summary>
    /// LoginPage.xaml 的交互逻辑
    /// </summary>
    public partial class LoginPage : Page
    {
        Dialog d = null;
        UserInfoDAL userInfoDAL = null;
        LoginViewModel loginViewModel = new LoginViewModel();
        public static string userID = "";
        private Action<UserInfoEntity> tabAction;
        public LoginPage()
        {
            InitializeComponent();
            DataContext = loginViewModel;
            tabAction += TabCallBackExcute;
        }
        private void TabCallBackExcute(UserInfoEntity user)
        {
            if (user != null && user.UserId != null)
            {
                d.Close();

                this.NavigationService.Navigate(new RegisterPage2(user));
            }
            else
            {
                d.Close();
            }
        }
        private async void LoginAPI()
        {
            try
            {
                Login.IsEnabled = false;
                var data = new Dictionary<string, object>
                {
                    { "UserId", loginViewModel.UserID }
                };
                UserInfoEntity userInfo = await ApiBLL.LoginAPI(data);
                if (userInfo != null)
                {
                    this.NavigationService.Navigate(new MeasureReePage(userInfo));
                }
                else
                {
                    HandyControl.Controls.Growl.Warning("查无此用户信息！");
                }
                Login.IsEnabled = true;
            }
            catch (Exception ex)
            {
                Login.IsEnabled = true;
                LogUtil.Error("登录",ex.Message);
                HandyControl.Controls.Growl.Warning("参数错误！");
            }
        }
        private void LoginBtn(object sender, RoutedEventArgs e)
        {
            if (loginViewModel.UserID=="")
            {
                HandyControl.Controls.Growl.Warning("请填写账号！","SuccesMsg");
                return;
            }
            if (APPSettingUtil.APP_ApiOrDb == "0")
            {
                LoginLocal();
            }
            else
            {
                LoginAPI();
            }

        }
        private void LoginLocal()
        {
            UserInfoEntity userInfo = new UserInfoEntity();
            string conditionStr = " UserId ='" + loginViewModel.UserID + "'";
            userInfo = userInfoDAL.Find(conditionStr);
            if (userInfo != null)
            {
                this.NavigationService.Navigate(new MeasureReePage(userInfo));
            }
            else
            {
                userID = loginViewModel.UserID;
                d = Dialog.Show(new RegisterDialog(tabAction));
            }
        }

        private void CloseBtn(object sender, RoutedEventArgs e)
        {
            this.NavigationService.GoBack();
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            bool isVisible = (bool)e.NewValue;//判断当前界面是否可见
            if (!isVisible)
            {
                GC.Collect();
            }
        }
        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            userInfoDAL = UserInfoDAL.getInstance();
        }

        private void GetID(object sender, RoutedEventArgs e)
        {
            DateTime today = DateTime.Today;
            DateTime todayStart = today.Date;
            int Temp_Num = 0;
            string Temp_Str = DateTime.Now.Date.ToString("yyyyMMdd");//查询今天0点到现在时间的注册个数，定位Temp_Num;
            string conditionStr = " ( createTime > '" + todayStart + "' and createTime < '" + DateTime.Now.ToString() + " '" + ')';
            List<UserInfoEntity> user = new List<UserInfoEntity>();
            user = userInfoDAL.Finds(conditionStr);
            if (user != null)
            {
                Temp_Num = user.Count + 1;
            }
            loginViewModel.UserID = Temp_Str + Temp_Num.ToString("000");
        }
    }
}
