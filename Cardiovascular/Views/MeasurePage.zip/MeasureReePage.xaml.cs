﻿using HandyControl.Controls;
using log4net.Core;
using MathWorks.MATLAB.NET.Arrays;
using MC300V31.Chart;
using MC300V31.Model;
using MC300V31.Views.DataManagePage.Mc;
using mcAlgorithm;
using mcBLL;
using mcDAL;
using mcSPCL;
using mcUntil;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using 动脉硬化;
using 动脉硬化.dll;
using MC300V31.Views.TextDialog;
using TestZedgraph = MC300V31.Chart.TestZedgraph;
using LiveChartsCore.SkiaSharpView;
using LiveChartsCore.SkiaSharpView.Painting;
using SkiaSharp;
using LiveChartsCore;
using LiveChartsCore.Defaults;

namespace MC300V31.Views.MeasurePage
{
    /// <summary>
    /// MeasureReePage.xaml 的交互逻辑
    /// 测量流程：开始测量 -> 复位设备 -> 获取设备状态 -> 获取环境状态 -> 开始抽气 -> 启动采样 -> 采样头罩气 -> 标零 -> 更改抽气速率 
    /// -> 采样头罩气 ->  更改抽气速率 -> 采样头罩气-> 停止采样 -> 复位设备
    /// </summary>
    public partial class MeasureReePage : Page
    {
        public long LastCount=0;
        string isEP;
        Dialog d = null;
        private Action<string> tabAction;

        string LastMsg = "";
        //定义串口
        SerialPortManager serialPortManager = null;
        ECGPCGSerialPortManager epserialPortManager = null;
        //HKSerialPortManager hkserialPortManager = null;   //先不管心电模块
        WorkStatus workStatus = WorkStatus.NoWork;


        StringMergeSplit stringMerge = new StringMergeSplit();//定义一个字符串合并的类
        PulseDataLocalDAL pulsedataDAL = null;
        PulseDataLocalEntity pulsedata = new PulseDataLocalEntity();
        UserInfoEntity userInfo = new UserInfoEntity();
        private bool pwvtestFlag = false;//值为假表示，正常测试，为测试pwv，当执行过一次测试pwv 流程后，将值变为true表示至少已经测试了一次pwv，
                                         //用于pwv测试不满意时，再次测试pwv；当再次测量pwv时是完成以后再次将值变为true，直到打开报表时，将值赋为false；
        private int sbpCount = 0;
        private bool[] PwvInflatRunFlag = new bool[4];//只允许进入一次赋值
        private byte CommandWordSend;//发送的肢体编号
        private int EveryCommandWordSend;//计时器轮巡的肢体编号
        private int[] BPInflateValue = new int[2];
        private bool BPinflateBeforeBPStartFlag;
        //用以检测袖带压力足够时后续操作是否会超时i=0（左上臂），1（左脚踝），2（右上臂），3（右脚踝）
        private int[] BpInflateRun = new int[4];//BpInflateRun(i)=0;初始为0，正常读取袖带压力  1：异常第一步，发送停止血压测量命令，BpInflateRun(i)=10;
                                                //BpInflateRun(i)=2;异常第二步，发送命令设定加压值  BpInflateRun(i)=10;
                                                //BpInflateRun(i)=3;再次启动血压测量  BpInflateRun(i)=0;
                                                //BpInflateRun(i)=4;达到压力值 ,终止血压测量，BpInflateRun(i)=10;ValueOpen_Flag(i)=2,启动关闭阀门计时器TimerCValveACK,
                                                //2秒内为完成关闭阀门启动定时器；
                                                //BpInflataRun(i)=5;关闭阀门，BpInflateRun(i)=10;   ValueOpen_Flag(i)=3;
                                                //BpInflateRun(i)=10

        private int[] BpInflateRunFlag = new int[4];//wzc 240905添加用于检测是哪个袖带没有在40秒内关闭阀门，默认为0表示阀门未关闭，关闭对应阀门后，值置为1 ；0：表示还未关闭阀门，1：表示他关闭了阀门
        private int[] ValueOpen_Flag = new int[4]; //ValueOpen_Flag[i]=0;初始值为0；阀门打开  ValueOpen[i]=1;阀门已关闭
                                                   //ValueOpen_Flag[i]=2;发送停止充气命令；ValueOpen_Flag[i]=3;发送关闭阀门命令
        private int RealPressure = 0;//当前袖带压力值
        private int[] BP_Test_Pressure = new int[4];//0-采集波形时左上肢袖带压力值;1-采集波形时左下肢袖带压力值;2-采集波形时右上肢袖带压力值;3-采集波形时右下肢袖带压力值
        private byte[] FourBpInflateFinish = new byte[4];//判断四肢血压设定是否完成
        private int[] BPOldPressure = new int[4];//记录四个血压模块上一次压力值，初始为0   左上肢 左下肢  右上肢 右下肢
        //只让刚开始接收脉搏波和心电心音时清空一次数据
        int[] iFpData = new int[2];
        int[] iCpData = new int[2];
        int[] iData = new int[2];//桡动脉
        private string strDebug = "";
        /// <summary>
        /// 命令字的类
        /// </summary>
        CommandWord cmdWord = new CommandWord();
        private string strTip;
        //只发送一次读取血压结果的命令
        private bool PWVStopFist = true;
        //--------------------数据库操作
        private DateTime g_strDateTime;
        private List<byte> SendDataBytes = new List<byte>();
        private List<byte> SendData = new List<byte>();
        //心电心音
        private int PWV_Fail_num = 0;
        //=====================ABI测量=================
        private int nBSbp;//'用于标定左上肢波形的收缩压和舒张压
        private int nBDbp;
        private int rBSbp;//'用于标定右上肢波形的收缩压和舒张压
        private int rBDbp;
        private byte[] FourBpStartPwv = new byte[4];//判断儿童血压测量是否开始
        private byte[] FourBpFinishPwv = new byte[4];//判断儿童血压测量是否完成
        private byte[] FourBPStart = new byte[4];//判断四肢血压测量是否开始
        private byte[] FourBPEnd = new byte[4];//判断四肢血压测量是否开始停止
        private byte[] FourBPStop = new byte[4];//判断四肢血压测量是否停止
        private byte[] FourBPOpenvalve = new byte[4];//判断左侧袖带放气是否开始  左上肢 左下肢  右上肢 右下肢
        private byte[] FourBPClosevalve = new byte[4];//判断左侧袖带阀门关闭是否开始   左上肢 左下肢  右上肢 右下肢
        private byte[] FourBPCloseFinish = new byte[4];//判断四肢袖带关闭是否完成  左上肢 左下肢  右上肢 右下肢
        private byte[] FourBPFinish = new byte[4];//判断四肢血压测量是否完成
        private byte[] FourBPOpenfinish = new byte[4];//判断左侧袖带放气是否完成    左上肢 左下肢  右上肢 右下肢
        private byte[] FourPressGreater = new byte[4];//判断四肢袖带压力值是否达到80；左上肢 左下肢 右上肢 右下肢
        private long DataCountNum = 0;
        private long DataCount = 0;//桡动脉横坐标
        private int WaitForAck = 0;
        private int enumPwvMrsResp = 0;
        private int[] BP_ACK_Flag = new int[4];//BP血压模块应答分类：默认为0，
                                               //-2为打开气阀命令发送；
                                               //-3关闭阀门；
                                               //-9重新设置加压值
                                               //-11停止血压标志位
                                               //-12发送儿童血压标志位；
        private byte get_bp_EC;//读取血压返回的故障码  01：从袖带获得脉搏波信号弱  02：从修改获得脉搏波信号不稳定   03：血压值超出测量范围   04：超过测量时限   55：气动堵塞
                               //                    56：用户终止读取BP值       57：充气超时、漏气或袖带松动     58：安全超时            59：袖带过压       5a：电源超出范围或其他硬件问题
                               //                    5b：如未授权的命令或超出范围的自动归零        61：传感器超出范围       62：EEPROM校准数据故障；
        private int get_bp_hr = 0;//返回血压模块心率
        private byte Bt_Pressureindex = 0x01;
        private int Real_press;
        private int ConutDownThirtySec = 10;

        private int[] ValveOpen_Flag = new int[4];//气阀打开标志，通常为打开 0
        //'---------------------保存两次测量的血压值----------------------
        private string strFirBraBp;
        private string strSecBraBp;
        private string strFirAnkBp;
        private string strSecAnkBp;
        //=====================PWV测量=================
        private long nCounter;
        private long CountTwoSec;
        private long CountOneSec;
        private long AICountOneSec;
        private long AICountTwoSec;
        private List<double> LCpDataTwoSec = new List<double>();//临时数据--用于筛选波形      临时存入保存的左侧脉搏波
        private List<double> LCpDataOneSec = new List<double>();//临时数据--用于放大倍数判断
        private List<double> LFpDataTwoSec = new List<double>();//临时数据--用于筛选波形
        private List<double> LFpDataOneSec = new List<double>();//临时数据--用于放大倍数判断
        private List<double> RCpDataTwoSec = new List<double>();//临时数据--用于筛选波形
        private List<double> RCpDataOneSec = new List<double>();//临时数据--用于放大倍数判断
        private List<double> RFpDataTwoSec = new List<double>();//临时数据--用于筛选波形
        private List<double> RFpDataOneSec = new List<double>();//临时数据--用于放大倍数判断

        private int[] nCpMarkSelect = new int[2];//筛选12秒左右上肢动脉波形   测量次数
        private int[] nFpMarkSelect = new int[2];//筛ddddddddddddddassssssssssssssssssssssssssssssdddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd选12秒左右下肢动脉波形
        private int[] nCpMarkWait = new int[2];//左右上肢
        private int[] nFpMarkWait = new int[2];//左右下肢

        private long[] CpRawDataNum = new long[2];//左右两路
        private long[] FpRawDataNum = new long[2];//左右两路
        private List<double> RCpRawData = new List<double>();
        private long RCpRawDataNum = 0;

        private List<double> LCpRawData = new List<double>();

        private List<double> RFpRawData = new List<double>();
        private long RFpRawDataNum = 0;

        private List<double> LFpRawData = new List<double>();

        private List<double> RApRawData = new List<double>();
        string LFpPackData = null;
        string LCpPackData = null;
        string RCpPackData = null;
        string RFpPackData = null;
        private double[] varPWVtemp = new double[10];
        private int[,] Annalyz_BPRecord = new int[4, 2];
        private int varMaxWFMA;//最大可拉伸长度
        private int get_hr = 0;//返回波形心率
        private double get_Lbaptt = 0;
        private double get_Rbaptt = 0;
        private double get_LRbaptt = 0;//左臂右踝
        private double get_RLbaptt = 0;//右臂左踝ptt
        #region
        //桡动脉诊断结果和建议
        private string strAIDiagnosisResult;
        private string strAIDiagnosisProposal;
        private int nMarkSelect;
        private List<double> RpRawData = new List<double>();//桡动脉原石数据
        private byte[] RpRawPulseData = new byte[6000];
        private List<double> RawPulseData = new List<double>();//封装原始脉搏波数据
        private long RpRawDataNum;
        private long nCount;
        private List<double> DataOneSec = new List<double>();//临时数据用于筛选波形
        private List<double> DataTwoSec = new List<double>();
        private int Sample_Rate = 500;
        private int nMarkWait;
        private bool SaveDataAfterAIAcquisitionFlag;
        private int ATTest_Clickflag;//用于区分AI测试过程函数调用主体 默认为0 只有AI测试了才为1而且仅用1次
        #endregion
        //血压测量次数
        private bool bPressMrsStart = false;//血压测量按钮状态切换
        private bool bPressMrsAIStart;//桡动脉测量按钮状态切换
        private bool bPulseMrsStart = true;//       '脉搏波测量按钮状态切换
        private int NumOfBpMrs = 0;     //血压测量次数1-3次
        private EnumData.MeasureMode PressMrsMode;
        private Variable.MrsBpValue[] arrGetBpSave = new Variable.MrsBpValue[2];//保存到处理好的血压数据
        private Variable.MrsBpValue[] arrGetBpHandle = new Variable.MrsBpValue[2];//处理血压响应的数据
        private Variable.MrsBpValue get_bp;//保存测量血压值
        private Variable.MrsBpValue FinalBpMrsValue;//最终的血压值
        private Variable.MrsBpValue g_typeBpMrsValue;
        private Variable.MrsIndexValue g_typeIndexValue;
        private DiagnosisResult.CardiacIndex g_typeCardiacIndex;
        private DiagnosisResult.VascularIndex g_typeVascularIndex;

        private string PwvMrsFinishFlag; //12秒PWV数据已经获取完毕：Yes 和 No两个值
        private string PulseMrsFinishFlag; //12秒PWV数据已经获取完毕：Yes 和 No两个值
        private byte BpModleIndex;
        private int GetBPnum;//已经读取血压模块的数量

        //=====================处理后的脉搏数据=====================
        //------左侧
        private List<int> LCpNormData = new List<int>();
        private int LCpNormDataNum;
        private List<int> LCpCalibData = new List<int>();//标定后的颈动脉数据
        private List<int> LCpFootPos = new List<int>();//起始点
        private int LCpFootPosNum;
        private List<int> LCpPeakPos = new List<int>();//动脉峰值点
        private int LCpPeakPosNum;
        private List<int> LCpFirstMaxPoint = new List<int>();//一阶导数最大指点
        private int LCpFirstMaxPointNum = 0;

        private List<double> LFpNormData = new List<double>();
        private int LFpNormDataNum;
        private List<double> LFpFootPos = new List<double>();
        private int LFpFootPosNum;
        private List<double> LFpPeakPos = new List<double>();
        private int LFpPeakPosNum;
        private List<double> LFpFirstMaxPoint = new List<double>();//一阶导数最大指点
        private int LFpFirstMaxPointNum = 0;
        private List<double> LCpFootSecPos = new List<double>();
        private List<double> LFpFootSecPos = new List<double>();
        //------右侧
        private List<double> RCpNormData = new List<double>();
        private int RCpNormDataNum;
        private List<double> RCpCalibData = new List<double>();//标定后的颈动脉数据
        private List<double> RCpFootPos = new List<double>();//起始点
        private int RCpFootPosNum;
        private List<double> RCpPeakPos = new List<double>();//峰值点
        private int RCpPeakPosNum;
        private List<double> RCpFirstMaxPoint = new List<double>();
        private int RCpFirstMaxPointNum = 0;//最大值点一阶导数


        private List<double> RFpNormData = new List<double>();
        private int RFpNormDataNum;
        private List<double> RFpFootPos = new List<double>();
        private int RFpFootPosNum;
        private List<double> RFpPeakPos = new List<double>();
        private int RFpPeakPosNum;
        private List<double> RFpFirstMaxPoint = new List<double>();
        private int RFpFirstMaxPointNum = 0;
        private List<double> RCpFootSecPos = new List<double>();
        private List<double> RFpFootSecPos = new List<double>();
        private static int[,] ECGBuffer = new int[6000, 2];
        private static int[,] Buffer = new int[6000, 2];
        private static List<int> BxDataList = new List<int>();
        private bool ProgressBarStartFlag;
        private int ProgressBarValue;
        public ObservableCollection<ObservablePoint> AIData = new ObservableCollection<ObservablePoint>();//心血管


        public ObservableCollection<ObservablePoint> LeftBraData = new ObservableCollection<ObservablePoint>();
        public ObservableCollection<ObservablePoint> LeftAnkData = new ObservableCollection<ObservablePoint>();
        public ObservableCollection<ObservablePoint> RightBraData = new ObservableCollection<ObservablePoint>();
        public ObservableCollection<ObservablePoint> RightAnkData = new ObservableCollection<ObservablePoint>();
        public ObservableCollection<ObservablePoint> ECGData = new ObservableCollection<ObservablePoint>();
        public ObservableCollection<ObservablePoint> PCGData = new ObservableCollection<ObservablePoint>();
        //心电心音变量
        #region
        private byte CommandType;
        private long HKDataCountNum = 0;
        private long XYDataCountNum = 0;
        private int HKUpdateNum = 0;
        ///心电心音数据存储
        //创建一个结构体将心电心音的值保存起来
        //List<ReceiveDataStructure> ECGdataValueAndType;
        //List<ReceiveDataStructure> dataValueAndType;
        private List<int> HKdataXY = new List<int>(); //存储待处理的ECG数据
        private List<int> HKdataECG = new List<int>(); //存储待处理的心电数据
        private bool isSampleOK = false;//是否可以采集波形
        private bool[] isSampleStop = new bool[2];//是否可以采集波形
        private List<double> ECGRawData = new List<double>(); //存储处理后的心电数据
        private List<double> PCGRawData = new List<double>(); //存储处理后的心音数据
        public delegate void GlobalTimerListener(int value);
        string testData;
        #endregion

        #region 初始化
        MeasureViewModel measureViewModel = null;
        TestZedgraph testZedGraph = null;//测试中zedGraph的操作类
        #region 计时器
        System.Timers.Timer Timer_ABIDelay = null;
        System.Timers.Timer timerRealLeftBra = null;
        System.Timers.Timer Timer_ACKTimeout = null;
        System.Timers.Timer TimerProcessData = null;
        System.Timers.Timer TimerCValueACK = null;
        int a, b = 0;
        SKColor HuaiDongmai = new SKColor(255, 109, 96);
        SKColor GongDongmai = new SKColor(25, 141, 204);
        SKColor XD = new SKColor(249, 211, 71);
        SKColor XY = new SKColor(108, 202, 201);
        #endregion
        /// <summary>
        /// 构造对象
        /// </summary>
        /// <param name="u"></param>
        /// <param name="userTemp"></param>
        /// <param name="userUN"></param>
        public MeasureReePage(UserInfoEntity u)
        {
            InitializeComponent();
            userInfo = u;
            measureViewModel = new MeasureViewModel();
            DataContext = measureViewModel;
            tabAction += TabCallBackExcute;
        }
        private void Window_OnLoaded(object sender, RoutedEventArgs e)
        {
            APPSettingUtil.LoadData();
            workStatus = WorkStatus.NoWork;
            pulsedataDAL = PulseDataLocalDAL.getInstance();
            //加载一下
            Thread thread = new Thread(() =>
            {
                Thread.Sleep(1000);
                Dispatcher.Invoke(new Action(() => {
                    measureViewModel.IsRunningLoad = "Hidden";
                }));
            });
            thread.Start();
            Initialize();
            InitComponent();//初始化组件
            InitTimer();
            InitShow();
            Recover();
            InitializeGraph();
            //SetPWVDisplay();
            LogUtil.Warn("真人测试");
            GlobalVariable.Pressure = 80;
        }
        private void InitializeGraph()
        {
            this.Series1.Series = new ObservableCollection<ISeries>
            {
                new LineSeries<ObservablePoint>
                {
                    Values =  LeftBraData,
                    Fill = null,
                    GeometryFill = null,
                    GeometryStroke = null,
                    Stroke=new SolidColorPaint(GongDongmai){StrokeThickness=2},
                    LineSmoothness=1
                },
                new LineSeries<ObservablePoint>
                {
                    Values = LeftAnkData,
                    Stroke = new SolidColorPaint(HuaiDongmai) { StrokeThickness = 2 },
                    Fill = null,
                    GeometryFill = null,
                    GeometryStroke = null,
                    LineSmoothness=1
                },
                new LineSeries<ObservablePoint>
                {
                    Values=AIData,
                    Stroke = new SolidColorPaint(HuaiDongmai) { StrokeThickness = 2 },
                    Fill = null,
                    GeometryFill = null,
                    GeometryStroke = null,
                    LineSmoothness=1
                }
            };
            //this.Series2.Series = new ObservableCollection<ISeries>
            {
                new LineSeries<ObservablePoint>
                {
                    Values = RightBraData,
                    Fill = null,
                    GeometryFill = null,
                    GeometryStroke = null,
                    Stroke = new SolidColorPaint(GongDongmai) { StrokeThickness = 2 },
                    LineSmoothness = 1
                };
                new LineSeries<ObservablePoint>
                {
                    Values = RightAnkData,
                    Stroke = new SolidColorPaint(HuaiDongmai) { StrokeThickness = 2 },
                    Fill = null,
                    GeometryFill = null,
                    GeometryStroke = null,
                    LineSmoothness = 1
                };
            };
            //this.Series3.Series = new ObservableCollection<ISeries>
            {
                new LineSeries<ObservablePoint>
                {
                    Values = ECGData,
                    Fill = null,
                    GeometryFill = null,
                    GeometryStroke = null,
                    Stroke = new SolidColorPaint(XD) { StrokeThickness = 2 },
                    LineSmoothness = 1
                };
                new LineSeries<ObservablePoint>
                {
                    Values = PCGData,
                    Stroke = new SolidColorPaint(XY) { StrokeThickness = 2 },
                    Fill = null,
                    GeometryFill = null,
                    GeometryStroke = null,
                    LineSmoothness = 1
                };
            };
        }
        //初始化控件数据
        private void Initialize()
        {
            Dispatcher.BeginInvoke(new Action(() =>
            {
                measureViewModel.RightAbi = "0";
                measureViewModel.LeftAbi = "0";
                measureViewModel.RightPWV = "0";
                measureViewModel.LeftPWV = "0";
                measureViewModel.LADbp = "0";
                measureViewModel.LAMap = "0";
                measureViewModel.LASbp = "0";
                measureViewModel.LARealPre = "--";
                measureViewModel.LBDbp = "0";
                measureViewModel.LBMap = "0";
                measureViewModel.LBSbp = "0";
                measureViewModel.LBRealPre = "--";
                measureViewModel.RADbp = "0";
                measureViewModel.RAMap = "0";
                measureViewModel.RASbp = "0";
                measureViewModel.RARealPre = "--";
                measureViewModel.RBDbp = "0";
                measureViewModel.RBMap = "0";
                measureViewModel.RBSbp = "0";
                measureViewModel.RBRealPre = "--";
                measureViewModel.Sevr = "0";
                if (TestMode.AI_Select == false)
                {
                    AITest.Visibility = Visibility.Hidden;
                    Grid.SetColumn(OpenReport, 1);
                }
            }));
        }
        //根据选择不同的肢体，选择需要发送的命令参数（一侧必须要有一个肢体是要测的）
        public void ChangeCmd()
        {
            if (TestMode.LBBP_Select && TestMode.LABP_Select && TestMode.RBBP_Select && TestMode.RABP_Select)
                CommandWordSend = BPX_LIMB.BPX_FOUR_LIMB;
            else if (TestMode.LBBP_Select && !TestMode.LABP_Select && !TestMode.RBBP_Select && !TestMode.RABP_Select)
                CommandWordSend = BPX_LIMB.BPX_LEFT_BRA;
            else if (!TestMode.LBBP_Select && TestMode.LABP_Select && !TestMode.RBBP_Select && !TestMode.RABP_Select)
                CommandWordSend = BPX_LIMB.BPX_LEFT_ANK;
            else if (!TestMode.LBBP_Select && !TestMode.LABP_Select && TestMode.RBBP_Select && !TestMode.RABP_Select)
                CommandWordSend = BPX_LIMB.BPX_RIGHT_BRA;
            else if (!TestMode.LBBP_Select && !TestMode.LABP_Select && !TestMode.RBBP_Select && TestMode.RABP_Select)
                CommandWordSend = BPX_LIMB.BPX_RIGHT_BRA;
            else if (TestMode.LBBP_Select && TestMode.LABP_Select && !TestMode.RBBP_Select && !TestMode.RABP_Select)
                CommandWordSend = BPX_LIMB.BPX_TOW_LIMB;
            else if (!TestMode.LBBP_Select && !TestMode.LABP_Select && TestMode.RBBP_Select && TestMode.RABP_Select)
                CommandWordSend = BPX_LIMB.BPX_TOW_RIMB;
            else if (TestMode.LBBP_Select && !TestMode.LABP_Select && TestMode.RBBP_Select && !TestMode.RABP_Select)
                CommandWordSend = BPX_LIMB.BPX_TOW_UPPER;
            else if (!TestMode.LBBP_Select && TestMode.LABP_Select && !TestMode.RBBP_Select && TestMode.RABP_Select)
                CommandWordSend = BPX_LIMB.BPX_TOW_DOWER;
            else if (!TestMode.LBBP_Select && TestMode.LABP_Select && TestMode.RBBP_Select && !TestMode.RABP_Select)
                CommandWordSend = BPX_LIMB.BPX_TOW_LARB;
            else if (TestMode.LBBP_Select && !TestMode.LABP_Select && !TestMode.RBBP_Select && TestMode.RABP_Select)
                CommandWordSend = BPX_LIMB.BPX_TOW_LBRA;
            else if (TestMode.LBBP_Select && TestMode.LABP_Select && TestMode.RBBP_Select && !TestMode.RABP_Select)
                CommandWordSend = BPX_LIMB.BPX_TOW_NORA;
            else if (TestMode.LBBP_Select && TestMode.LABP_Select && !TestMode.RBBP_Select && TestMode.RABP_Select)
                CommandWordSend = BPX_LIMB.BPX_TOW_NORB;
            else if (TestMode.LBBP_Select && !TestMode.LABP_Select && TestMode.RBBP_Select && TestMode.RABP_Select)
                CommandWordSend = BPX_LIMB.BPX_TOW_NOLA;
            else if (!TestMode.LBBP_Select && TestMode.LABP_Select && TestMode.RBBP_Select && TestMode.RABP_Select)
                CommandWordSend = BPX_LIMB.BPX_TOW_NOLB;
            TestMode.CommandWordSend = CommandWordSend;
        }
        private void CuffAssignment(byte SendCommand)//选中需要测试的肢体后，剩下的肢体所对应的数组全部被赋值，避免影响判断
        {
            Assignment();//给默认值为1,2,3,4,
            switch (SendCommand)
            {
                case 0x00:
                    SetValueWhenIndex(0, 0);
                    SetValueWhenIndex(1, 0);
                    SetValueWhenIndex(2, 0);
                    SetValueWhenIndex(3, 0);
                    GetBPnum = 0;
                    break;
                case 0x01:
                    SetValueWhenIndex(0, 0);//把该数组第0个索引赋值为0
                    GetBPnum = 3;
                    break;
                case 0x02:
                    SetValueWhenIndex(1, 0);//把该数组第1个索引赋值为0
                    GetBPnum = 3;
                    break;
                case 0x03:
                    SetValueWhenIndex(2, 0);//把该数组第2个索引赋值为0
                    GetBPnum = 3;
                    break;
                case 0x04:
                    SetValueWhenIndex(3, 0);//把该数组第3个索引赋值为0
                    GetBPnum = 3;
                    break;
                case 0x05:
                    break;
                case 0x06:
                    SetValueWhenIndex(0, 0);//把该数组第0个索引赋值为0
                    SetValueWhenIndex(1, 0);//把该数组第1个索引赋值为0
                    GetBPnum = 2;
                    break;
                case 0x07:
                    SetValueWhenIndex(2, 0);//把该数组第2个索引赋值为0
                    SetValueWhenIndex(3, 0);//把该数组第3个索引赋值为0
                    GetBPnum = 2;
                    break;
                case 0x08://上肢（应当给下肢赋值）
                    SetValueWhenIndex(0, 0);//把该数组第0个索引赋值为0
                    SetValueWhenIndex(2, 0);//把该数组第2个索引赋值为0
                    GetBPnum = 2;
                    break;
                case 0x09://下肢（给上肢赋值）
                    SetValueWhenIndex(1, 0);//把该数组第1个索引赋值为0
                    SetValueWhenIndex(3, 0);//把该数组第3个索引赋值为0
                    GetBPnum = 2;
                    break;
                case 0x0A:
                    SetValueWhenIndex(1, 0);//把该数组第1个索引赋值为0
                    SetValueWhenIndex(2, 0);//把该数组第2个索引赋值为0
                    GetBPnum = 2;
                    break;
                case 0x0B:
                    SetValueWhenIndex(0, 0);//把该数组第0个索引赋值为0
                    SetValueWhenIndex(3, 0);//把该数组第3个索引赋值为0
                    GetBPnum = 2;
                    break;
                case 0x0C:
                    SetValueWhenIndex(0, 0);//把该数组第2个索引赋值为0
                    SetValueWhenIndex(1, 0);//把该数组第2个索引赋值为0
                    SetValueWhenIndex(2, 0);//把该数组第2个索引赋值为0
                    GetBPnum = 1;
                    break;
                case 0x0D:
                    SetValueWhenIndex(0, 0);//把该数组第0个索引赋值为0
                    SetValueWhenIndex(1, 0);//把该数组第1个索引赋值为0
                    SetValueWhenIndex(3, 0);//把该数组第3个索引赋值为0
                    GetBPnum = 1;
                    break;
                case 0x0E:
                    SetValueWhenIndex(0, 0);//把该数组第0个索引赋值为0
                    SetValueWhenIndex(2, 0);//把该数组第2个索引赋值为0
                    SetValueWhenIndex(3, 0);//把该数组第3个索引赋值为0
                    GetBPnum = 1;
                    break;
                case 0x0F:
                    SetValueWhenIndex(1, 0);//把该数组第1个索引赋值为0
                    SetValueWhenIndex(2, 0);//把该数组第2个索引赋值为0
                    SetValueWhenIndex(3, 0);//把该数组第3个索引赋值为0
                    GetBPnum = 1;
                    break;
            }
        }
        /// <summary>
        /// 数组默认赋值
        /// </summary>
        private void Assignment()
        {
            for (int i = 0; i < 4; i++)
            {
                FourPressGreater[i] = (byte)(i + 1);
                FourBPStop[i] = (byte)(i + 1);
                FourPressGreater[i] = (byte)(i + 1);
                FourBPClosevalve[i] = (byte)(i + 1);
                FourBpInflateFinish[i] = (byte)(i + 1);
                FourBpStartPwv[i] = (byte)(i + 1);
                FourBPFinish[i] = (byte)(i + 1);
                FourBPEnd[i] = (byte)(i + 1);
                BpInflateRunFlag[i] = (byte)(i + 1);
            }
        }
        /// <summary>
        /// 用来给数组赋值默认值
        /// </summary>
        /// <param name="a">数组名称</param>
        /// <param name="i">第几个索引</param>
        /// <param name="value">默认赋值</param>
        private void SetValueWhenIndex(int i, int value)
        {
            FourPressGreater[i] = (byte)value;
            FourPressGreater[i] = (byte)value;
            FourBPStop[i] = (byte)value;
            FourPressGreater[i] = (byte)value;
            FourBPClosevalve[i] = (byte)value;
            FourBpInflateFinish[i] = (byte)value;
            FourBpStartPwv[i] = (byte)value;
            FourBPFinish[i] = (byte)value;
            FourBPEnd[i] = (byte)value;
            BpInflateRunFlag[i] = (byte)value;
        }
        //第二次测量所需变量初始化
        private void SecondTest()
        {
            PWVStopFist = true;
            WaitForAck = 0;
        }
        //用户信息更新，
        private void UserInformationShow()
        {
            measureViewModel.UserName = userInfo.UserName;
            measureViewModel.UserID = userInfo.UserId;
            measureViewModel.BirthDay = userInfo.UserAge.ToString();
            measureViewModel.UserSex = userInfo.UserSex.ToString();
            measureViewModel.UserHeight = userInfo.UserHeight.ToString();
        }
        //BP测试前，设定血压袖带充气压力值
        private bool BPinflateBeforeBPStart(int Wvalue_temp, Byte bLimbPos)
        {
            byte Value_temp = (byte)Wvalue_temp;
            BPinflateBeforeBPStartFlag = false;
            SendDataBytes.Clear();
            SendDataBytes.Add(0x00);
            SendDataBytes.Add(Value_temp);
            SendDataBytes.Add(bLimbPos);
            serialPortManager.SendDataToMCU(CommandWord.REQ_BP_INIT_SET, SendDataBytes, APPSettingUtil.ShortWaitTime);
            BPinflateBeforeBPStartFlag = true;
            return BPinflateBeforeBPStartFlag;
        }
        /// <summary>
        /// 初始化控件
        /// </summary>
        private void InitComponent()
        {
            testZedGraph = new TestZedgraph();
            Timer_ABIDelay = new System.Timers.Timer();
            timerRealLeftBra = new System.Timers.Timer();
            Timer_ACKTimeout = new System.Timers.Timer();
            TimerProcessData = new System.Timers.Timer();
            TimerCValueACK  = new System.Timers.Timer();
            serialPortManager = SerialPortManager.getInstance();//串口业务
            serialPortManager.InformMsgEvnet = new SerialPortManager.InformMsg(ReciveAlarm);
            serialPortManager.InformDebugMsgEvnet = new SerialPortManager.InformDebugMsg(msg);

            //epserialPortManager = ECGPCGSerialPortManager.getInstance();//心电心音串口业务
            //epserialPortManager.EPInformMsgEvnet = new ECGPCGSerialPortManager.ECGPCGInformMsg(EPReciveAlarm);
            //epserialPortManager.EPInformDebugMsgEvnet = new ECGPCGSerialPortManager.ECGPCGInformDebugMsg(msg);
        }

        /// <summary>
        /// 初始化 定时器
        /// </summary>
        private void InitTimer()
        {
            Timer_ABIDelay.Interval = 1000;//1s 执行一次
            Timer_ABIDelay.Enabled = false;
            Timer_ABIDelay.AutoReset = true;
            Timer_ABIDelay.Elapsed += new System.Timers.ElapsedEventHandler(Timer_ABIDelay_Tick);

            timerRealLeftBra.Interval = 80;
            timerRealLeftBra.Enabled = false;
            timerRealLeftBra.AutoReset = true;
            timerRealLeftBra.Elapsed += new System.Timers.ElapsedEventHandler(timerRealLeftBra_Tick);

            Timer_ACKTimeout.Interval = 1000;//1s 执行一次
            Timer_ACKTimeout.Enabled = false;
            Timer_ACKTimeout.AutoReset = true;
            Timer_ACKTimeout.Elapsed += new System.Timers.ElapsedEventHandler(Timer_ACKTimeout_Tick);

            TimerProcessData.Interval = 1000;//1s 执行一次
            TimerProcessData.Enabled = false;
            TimerProcessData.AutoReset = true;
            TimerProcessData.Elapsed += new System.Timers.ElapsedEventHandler(TimerProcessData_Tick);

            TimerCValueACK.Interval = 40000;
            TimerCValueACK.Enabled = false;
            TimerCValueACK.AutoReset = true;
            TimerCValueACK.Elapsed += new System.Timers.ElapsedEventHandler(TimerCValueACK_Tick);
        }

        /// <summary>
        /// 初始化界面显示
        /// </summary>
        private void InitShow()
        {
            Dispatcher.BeginInvoke(new Action(() =>
            {
                measureViewModel.UserID = userInfo.UserId;
                measureViewModel.UserName = userInfo.UserName;
                measureViewModel.UserSex = userInfo.UserSex;
                measureViewModel.BirthDay = userInfo.UserBirthday.ToString();
                if(APPSettingUtil.APP_IsVersion=="101")//不是最低配版本
                {
                    AITest.Visibility = Visibility.Hidden;
                    Grid.SetColumn(OpenReport, 1);
                }
                else 
                {
                    AITest.Visibility = Visibility.Visible;
                    Grid.SetColumn(OpenReport, 0);
                }
            }));
        }
        #endregion

        #region 清理
        /// <summary>
        /// 复位
        /// </summary>
        public void Recover()
        {
            PressMrsMode = EnumData.MeasureMode.ExperienceMode;
            #region 全局变量初始化
            Variable.Test_AI_num = 0;
            //Variable.Test_ABI_num = 0;
            //Variable.Test_PWV_num = 0;
            #endregion
            EveryCommandWordSend = 0;
            Variable.strMrsLocation = "肱踝";
            bPressMrsStart = true;
            bPressMrsAIStart = true;//桡动脉按钮状态切换
            Initialize();
            UserInformationShow();
            measureViewModel.Tips = "温馨提示：请做好测试前准备！";
            ChangeCmd();
            workStatus = WorkStatus.NoWork;
        }

        private void Timer_ACKTimeout_Tick(object sender, System.Timers.ElapsedEventArgs e)
        {

        }
        //计时器启动，判断哪个肢体的状态值
        private void TimerCValueACK_Tick(object sender, System.Timers.ElapsedEventArgs e)
        {
            TimerCValueACK.Stop();
            if(BpInflateRunFlag[0]==1)//出了问题没有完成
            {
                BpInflateRun[0] = 1;
                ValveOpen_Flag[0] = 0;
            }
            else if (BpInflateRun[1] == 1)
            {
                BpInflateRun[1] = 1;
                ValveOpen_Flag[1] = 0;
            }
            else if (BpInflateRun[2] == 1)
            {
                BpInflateRun[2] = 1;
                ValveOpen_Flag[2] = 0;
            }
            else if (BpInflateRun[3] == 1)
            {
                BpInflateRun[3] = 1;
                ValveOpen_Flag[3] = 0;
            }
            timerRealLeftBra.Start();//压力计时器开始运行
        }
        #endregion
        private void TimerProcessData_Tick(object sender, System.Timers.ElapsedEventArgs e)
        {
            TimerProcessData.Enabled = false;
            //判断是保存血压数据还是脉搏波
            WaitForAck = MrsWaitForAck.MrsBP;
            if (WaitForAck == MrsWaitForAck.MrsBP)
            {
                WaitForAck = 0;
                if (SaveDataAfterBP() == false)
                {
                    Dispatcher.BeginInvoke(new Action(() =>
                    {
                        measureViewModel.Tips = "温馨提示：血压数据保存失败";
                    }));
                    Thread.Sleep(200);//异常错误处理
                    return;
                }
                //开始pwv测试前再发一次增加冗余，确保当前无工作在执行
                AlltestStopWhenPWVfail();
                if (TestMode.AI_Select)
                {
                    //ECGPCGStop_Function();
                }
                Dispatcher.BeginInvoke(new Action(() =>
                {
                    measureViewModel.Tips = "温馨提示：血压数据测量完成！";
                }));
                workStatus = WorkStatus.NoWork;
                //if (TestMode.ECGPCG_Select)//如果勾选了 心电心音在提示
                //{
                //    //ConutDownThirtySec = 10;
                //    //Timer_ABIDelay.Enabled = true;
                //    //Variable.Test_ABI_num = 1;
                //    //d = Dialog.Show(new EPDialog(tabAction, "心电心音检测", "           请佩戴好心电心音模块检测器，点击确认后开始心电心音和脉搏波测量."));
                //    Dispatcher.BeginInvoke(new Action(() =>
                //    {
                //        d = Dialog.Show(new EPDialog(tabAction));
                //    }));
                //}
                //else
                //{
                //    ConutDownThirtySec = 10;
                //    Timer_ABIDelay.Enabled = true;
                //    Variable.Test_ABI_num = 1;
                //}
                //return;
            }
            else if (WaitForAck == MrsWaitForAck.MrsPWV)
            {
                WaitForAck = 0;
                if (PulseWaveformAnalysis() == false)
                {
                    TimerProcessData.Enabled = false;
                    //AlltestStopWhenPWVfail();
                    Dispatcher.BeginInvoke(new Action(() =>
                    {
                        measureViewModel.MeasureBtn_Img = "pack://application:,,,/Resources/Image/Measure/开始测量.jpg";
                        measureViewModel.Tips = "脉搏波分析出错！！请点击测试按钮再次测试脉搏波！";
                        return;
                    }));
                }
                //if (TestMode.ECGPCG_Select)
                //{
                //    ECGPCGWaveformAnalysis();
                //}
                //DisplayPulseWaveform();
                //Thread.Sleep(500);
                
                if (TestMode.AI_Select == true)//判断是否勾选AI若不测则直接保存数据
                {
                    Dispatcher.BeginInvoke(new Action(() =>
                    {
                        measureViewModel.Tips = "温馨提示：血压测量完成,请点击开始测量按钮，进行桡动脉测试！";
                        AITest.Visibility = Visibility.Visible;
                        
                        measureViewModel.MeasureBtn_Img = "pack://application:,,,/Resources/Image/Measure/开始测量.jpg";
                    }));
                    bPressMrsStart = true;
                    pwvtestFlag = false;
                    TestBtn.IsEnabled = false;
                    return;
                }
                workStatus = WorkStatus.NoWork;//只要执行到这一步状态位就切换成Nowork;
            }
            else if (WaitForAck == MrsWaitForAck.MrsPulse)//桡动脉波形分析
            {
                if (SaveDataAfterAIAcquisition() == false)//处理原始脉搏波数据
                {
                    TimerProcessData.Enabled = false;
                    return;
                }
                if (g_typeVascularIndex.Cap == 0 &&
                       g_typeCardiacIndex.Hr == 0 && g_typeCardiacIndex.Ed == 0)//如果中心动脉压为0同时心率和射血时间也为0表明此次采集波形出现问题
                {
                    
                    //d = Dialog.Show(new EPDialog(tabAction, "桡动脉采集", "桡动脉采集出现问题，请重新采集桡动脉！"));
                    Dispatcher.BeginInvoke(new Action(() =>
                    {
                        measureViewModel.Tips = "桡动脉采集出现问题，请重新采集桡动脉！";
                    }));
                    //if (isEP == "确定")
                    {
                        RpRawDataNum = 0;
                        RpRawData.Clear();
                        ProgressBarValue = 0;
                        measureViewModel.TestStatus = "0";
                        nMarkWait = 0;
                        DataCount = 0;
                        bPressMrsAIStart = false;
                        SendDataBytes.Clear();
                        SendDataBytes.Add(0x00);
                        SendDataBytes.Add(0x01);
                        ProgressBarStartFlag = true;
                    }
                    return;
                }
                //保存数据
                int RawDataNum_Record;
                RawDataNum_Record = 12 * Sample_Rate;
                string RawPackData = "";
                RawPackData = stringMerge.MergeString(RpRawData);
                string str = "TestDateTime = '" + g_strDateTime + " '";
                pulsedata.AI_num = 1;
                pulsedata.Ed = g_typeCardiacIndex.Ed * 100;
                pulsedata.Sbp2 = g_typeVascularIndex.Cap;
                pulsedata.AIx = g_typeVascularIndex.AIx;
                pulsedata.Hr = g_typeCardiacIndex.Hr;
                pulsedata.Spti = Convert.ToInt32(g_typeCardiacIndex.Spti);
                pulsedata.Dpti = g_typeCardiacIndex.Dpti;
                pulsedata.Sevr = g_typeCardiacIndex.Sevr;
                pulsedata.EdPct = g_typeCardiacIndex.EdPct;
                pulsedata.RpRawData = RawPackData;
                pulsedata.AIDiagnosisResult = strAIDiagnosisResult;
                pulsedata.AIDiagnosisProposal = strAIDiagnosisProposal;
                string Str_Testdate;
                Str_Testdate = string.Format("{0:yyyyMMddHHmmssffff}", g_strDateTime);
                Variable.MrsIndexValue.Upload_Report_Name = userInfo.UserId + "_" + Str_Testdate + ".pdf";//As100681....2022091302_.pdf
                pulsedata.DiagnosisResult = g_typeIndexValue.DiagnosisResult;
                pulsedata.DiagnosisProposal = g_typeIndexValue.DiagnosisProposal;
                pulsedata.ABIAssess = g_typeIndexValue.strABIAssess;
                pulsedata.PWVAssess = g_typeIndexValue.strPWVAssess;
                pulsedata.PWVLefttoRightDif = g_typeIndexValue.strLefttoRightPWV;
                pulsedata.Report_Name = Variable.MrsIndexValue.Upload_Report_Name;
                pulsedata.IsReportPrinted = "N";
                pulsedata.IsPDFReportPrinted = "N";
                workStatus = WorkStatus.NoWork;//只要执行到这一步状态位就切换成Nowork;
            }
            AnalyseDiagnosisResult();//评估诊断结果
            if (pulsedataDAL.Insert(pulsedata) > 0)
            {
                Dispatcher.BeginInvoke(new Action(() =>
                {
                    measureViewModel.Tips = "温馨提示：数据保存成功！";
                    measureViewModel.MeasureBtn_Img = "pack://application:,,,/Resources/Image/Measure/开始测量.jpg";
                    TestBtn.IsEnabled = true;
                    Variable.Test_ABI_num = 0;
                    Variable.Test_PWV_num = 0;
                    Variable.Test_AI_num = 0;
                }));
            }
            else
            {
                Dispatcher.BeginInvoke(new Action(() =>
                {
                    measureViewModel.Tips = "温馨提示：数据保存失败！该次测试结果已保存到日志文件。";
                    measureViewModel.MeasureBtn_Img = "pack://application:,,,/Resources/Image/Measure/开始测量.jpg";
                    TestBtn.IsEnabled = true;
                })); 
                testData = JsonConvert.SerializeObject(pulsedata);
                LogUtil.Info(testData);
            }
        }
        //  过程名称：给出诊断结果；过程功能：诊断结果
        private bool AnalyseDiagnosisResult()
        {
            try
            {
                // 诊断结果和建议
                double[] arrIndexValue = new double[8];
                DiagnosisResult clsDiagnosis = new DiagnosisResult();
                arrIndexValue[0] = (float)g_typeIndexValue.Hr;
                arrIndexValue[1] = g_typeBpMrsValue.LtBraBp_Sbp;//就等于带腕带测量的那个手臂的血压值  （左臂）
                arrIndexValue[2] = g_typeBpMrsValue.LtBraBp_Dbp;//左臂的舒张压
                //arrIndexValue[3] = g_typeIndexValue.Abi;
                //arrIndexValue[4] = g_typeIndexValue.LtAbi;
                //arrIndexValue[5] = g_typeIndexValue.RtAbi;
                //arrIndexValue[6] = g_typeIndexValue.LbaPwv;

                //arrIndexValue[7] = g_typeIndexValue.RbaPWV;
                clsDiagnosis.AnalyseDiagnosisResult(userInfo.UserAge, userInfo.UserSex, arrIndexValue);
                g_typeIndexValue.DiagnosisResult = clsDiagnosis.strDiagnosisResult;
                g_typeIndexValue.DiagnosisProposal = clsDiagnosis.strDiagnosisProposal;
                //g_typeIndexValue.strABIAssess = clsDiagnosis.g_strABIAssess;
                //clsDiagnosis.PWVDiagnoseFunction(g_typeIndexValue.LbaPwv, g_typeIndexValue.RbaPWV, userInfo.UserSex, userInfo.UserAge);
                //g_typeIndexValue.strPWVAssess = clsDiagnosis.g_strPWVAssess;
                //g_typeIndexValue.strLefttoRightPWV = clsDiagnosis.g_strLefttoRightPWV;
                pulsedata.DiagnosisResult = g_typeIndexValue.DiagnosisResult;
                pulsedata.DiagnosisProposal = g_typeIndexValue.DiagnosisProposal;
                //pulsedata.ABIAssess = g_typeIndexValue.strABIAssess;
                //pulsedata.PWVAssess = g_typeIndexValue.strPWVAssess;
                
                //clsDiagnosis.PWVDiagnoseFunction(g_typeIndexValue.LbaPwv, g_typeIndexValue.RbaPWV, userInfo.UserSex, userInfo.UserAge);
                return true;
            }
            catch(Exception ex)
            {
                Growl.Info("测试结果分析错误！+" + ex.Message);
                return false;
            }
        }
        /// <summary>
        /// AI波形采集完成后处理原始数据，然后在分析数据
        /// </summas>
        /// <returns></returns>
        private bool SaveDataAfterAIAcquisition()
        {
            try
            {
                FeaturePoint featurepoint;
                featurepoint = new FeaturePoint();
                if (!TestMode.LBBP_Select)
                {
                    g_typeBpMrsValue.LtBraBp_Sbp = g_typeBpMrsValue.RtBraBp_Sbp;
                    g_typeBpMrsValue.LtBraBp_Dbp = g_typeBpMrsValue.RtBraBp_Dbp;
                }
                if (featurepoint.Identify(g_typeBpMrsValue.LtBraBp_Sbp, g_typeBpMrsValue.LtBraBp_Dbp, RpRawData) == 0)//保存数据
                {
                    Dispatcher.BeginInvoke(new Action(() =>
                    {
                        measureViewModel.Tips = "温馨提示：波形分析出错，请重新测量";
                    }));
                    TimerProcessData.Enabled = false;
                    SaveDataAfterAIAcquisitionFlag = false;
                    return SaveDataAfterAIAcquisitionFlag;
                }
                //心率值是否有误string result = ;//把数字字符串中的数字提取出来
                if (int.Parse(System.Text.RegularExpressions.Regex.Replace(featurepoint.index[1, 0], @"[^0-9]+", "")) < 
                    40)
                {
                    Dispatcher.BeginInvoke(new Action(() =>
                    {
                        measureViewModel.Tips = "温馨提示：波形分析出错，请重新测量";//直接退出检测
                    }));
                    TimerProcessData.Enabled = false;
                    return false;
                }
                g_typeVascularIndex.Sbp = Record_Index.LtBraBp_Sbp;
                g_typeVascularIndex.Dbp = Record_Index.LtBraBp_Dbp;
                g_typeVascularIndex.Pp = Record_Index.LtBraBp_Sbp - Record_Index.LtBraBp_Dbp;

                g_typeCardiacIndex.Hr = Convert.ToInt16(featurepoint.index[1, 0]);
                g_typeCardiacIndex.EdPct = Convert.ToSingle(featurepoint.index[1, 1]);
                g_typeCardiacIndex.Spti = Convert.ToInt16(featurepoint.index[1, 2]);
                g_typeCardiacIndex.Dpti = Convert.ToInt16(featurepoint.index[1, 3]);
                g_typeCardiacIndex.Sevr = Convert.ToSingle(featurepoint.index[1, 4]);

                g_typeVascularIndex.Cap = Convert.ToInt16(featurepoint.index[1, 5]);
                g_typeVascularIndex.AIx = Convert.ToSingle(featurepoint.index[1, 6]);
                g_typeCardiacIndex.Ed = Convert.ToSingle(featurepoint.index[1, 7]);
                Dispatcher.BeginInvoke(new Action(() =>
                {
                    measureViewModel.Tips = "温馨提示：脉搏波信号分析中";
                }));
                //显示指标
                DisplayAIIndex();
                //分析处理结果
                List<double> arrCardiacIndex = new List<double>();
                List<double> arrVascularIndex = new List<double>();
                arrCardiacIndex.Add(g_typeCardiacIndex.Hr);
                arrCardiacIndex.Add(g_typeCardiacIndex.Ed);
                arrCardiacIndex.Add(g_typeCardiacIndex.EdPct);
                arrCardiacIndex.Add(g_typeCardiacIndex.Spti);
                arrCardiacIndex.Add(g_typeCardiacIndex.Dpti);
                arrCardiacIndex.Add(g_typeCardiacIndex.Sevr);

                arrVascularIndex.Add(g_typeVascularIndex.Sbp);
                arrVascularIndex.Add(g_typeVascularIndex.Dbp);
                arrVascularIndex.Add(g_typeVascularIndex.Pp);
                arrVascularIndex.Add(g_typeVascularIndex.Cap);
                arrVascularIndex.Add(g_typeVascularIndex.AIx);
                //计算指标
                DiagnosisResult diagnosis;
                diagnosis = new DiagnosisResult();
                diagnosis.AnalyseAIDiagnosisResult(userInfo.UserAge, userInfo.UserSex, arrCardiacIndex, arrVascularIndex);
                strAIDiagnosisResult = diagnosis.strDiagnosisResult;//桡动脉诊断结果建议赋值给测试界面变量
                strAIDiagnosisProposal = diagnosis.strDiagnosisProposal;
                Record_Index.AIDiagnonsisResult = strAIDiagnosisResult;
                Record_Index.AIDiagnonsisProproal = strAIDiagnosisProposal;
                g_typeIndexValue.DiagnosisResult = diagnosis.strDiagnosisResult;
                g_typeIndexValue.DiagnosisProposal = diagnosis.strDiagnosisProposal;
                g_typeIndexValue.strABIAssess = diagnosis.g_strABIAssess;
                diagnosis.PWVDiagnoseFunction(g_typeIndexValue.LbaPwv, g_typeIndexValue.RbaPWV, userInfo.UserSex, userInfo.UserAge);
                g_typeIndexValue.strPWVAssess = diagnosis.g_strPWVAssess;
                g_typeIndexValue.strLefttoRightPWV = diagnosis.g_strLefttoRightPWV;
                //传递给可以用来后续保存数据的值
                SaveDataAfterAIAcquisitionFlag = true;
                Variable.Test_AI_num = 1;
                return SaveDataAfterAIAcquisitionFlag;
            }
            catch (Exception ex)
            {
                Dispatcher.BeginInvoke(new Action(() =>
                {
                    this.measureViewModel.Tips = "分析桡动脉测量数据失败！" + ex.Message;
                }));
                return SaveDataAfterAIAcquisitionFlag;
            }
        }
        public void DisplayAIIndex()
        {
            measureViewModel.Sevr = g_typeCardiacIndex.Sevr.ToString("f2");
            //心肌活力率
            Dispatcher.BeginInvoke(new Action(() =>
            {
                if (Convert.ToDouble(measureViewModel.Sevr) > 0 && Convert.ToDouble(measureViewModel.Sevr) < 0.9)
                {
                    lblSevr.Foreground = Brushes.Red;
                }
                else if (Convert.ToDouble(measureViewModel.Sevr) > 55 && Convert.ToDouble(measureViewModel.Sevr) < 98)
                {
                    lblSevr.Foreground = Brushes.Blue;
                }
            }));
            //显示波形
            strTip = "温馨提示：心动脉脉搏数据采集完成，正在保存... ...";
            AIData.Clear();
            for (int i = 0; i < RpRawData.Count; i++)
            {
                ObservablePoint item2 = new ObservablePoint();
                item2.X = i;
                item2.Y = RpRawData[i];
                AIData.Add(item2);
            }
        }
        #region 定时器事件
        /// <summary>
        /// 定时器
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Timer_ABIDelay_Tick(object sender, System.Timers.ElapsedEventArgs e)
        {
            //if (ConutDownThirtySec <= 0)
            //{
            //    ConutDownThirtySec = 100;
            //    Timer_ABIDelay.Enabled = false;
            //    CuffAssignment(CommandWordSend);
            //    PWVStartWhenBPStop();// ''''ABI测试完全正常结束，此时方可再次启动PWV测量（测试时注释）
            //    Dispatcher.BeginInvoke(new Action(() =>
            //    {
            //        measureViewModel.Tips = "温馨提示：正在启动PWV测量……";
            //    }));
            //}
            //else
            //{
            //    Dispatcher.BeginInvoke(new Action(() =>
            //    {
            //        measureViewModel.Tips = "温馨提示：" + ConutDownThirtySec.ToString() + "秒后将开始PWV测量，请保持身体稳定！";
            //    }));
            //    ConutDownThirtySec = ConutDownThirtySec - 1;
            //}
        }
        //处理检测到的血压数据
        private void HandleBPData(ref Variable.MrsBpValue FourLimbBp)
        {
            measureViewModel.LBRealPre = "--";
            //measureViewModel.LARealPre = "--";
            //measureViewModel.RBRealPre = "--";
            //measureViewModel.RARealPre = "--";
            int BraHigherSbp = 0;
            int AnkHigherSbp = 0;
            double Temp_ABI = 0;
            //把保存到数组中的血压值读取出来显示在窗体上
            measureViewModel.LBSbp = FourLimbBp.LtBraBp_Sbp.ToString();
            measureViewModel.LBDbp = FourLimbBp.LtBraBp_Dbp.ToString();
            measureViewModel.LBMap = FourLimbBp.LtBraBp_Map.ToString();
            //measureViewModel.RBSbp = FourLimbBp.RtBraBp_Sbp.ToString();
            //measureViewModel.RBDbp = FourLimbBp.RtBraBp_Dbp.ToString();
            //measureViewModel.RBMap = FourLimbBp.RtBraBp_Map.ToString();
            //measureViewModel.LASbp = FourLimbBp.LtAnkBp_Sbp.ToString();
            //measureViewModel.LADbp = FourLimbBp.LtAnkBp_Dbp.ToString();
            //measureViewModel.LAMap = FourLimbBp.LtAnkBp_Map.ToString();
            //measureViewModel.RASbp = FourLimbBp.RtAnkBp_Sbp.ToString();
            //measureViewModel.RADbp = FourLimbBp.RtAnkBp_Dbp.ToString();
            //measureViewModel.RAMap = FourLimbBp.RtAnkBp_Map.ToString();
            ////标准检测(测试时注释）
            if (PressMrsMode == EnumData.MeasureMode.ExpertMode)
            {
                if (NumOfBpMrs <= 1)
                {
                    arrGetBpHandle[NumOfBpMrs].LtBraBp_Sbp = FourLimbBp.LtBraBp_Sbp;
                    arrGetBpHandle[NumOfBpMrs].LtBraBp_Dbp = FourLimbBp.LtBraBp_Dbp;
                    arrGetBpHandle[NumOfBpMrs].LtBraBp_Map = FourLimbBp.LtBraBp_Map;

                    //arrGetBpHandle[NumOfBpMrs].RtBraBp_Sbp = FourLimbBp.RtBraBp_Sbp;
                    //arrGetBpHandle[NumOfBpMrs].RtBraBp_Dbp = FourLimbBp.RtBraBp_Dbp;
                    //arrGetBpHandle[NumOfBpMrs].RtBraBp_Map = FourLimbBp.RtBraBp_Map;

                    //arrGetBpHandle[NumOfBpMrs].LtAnkBp_Sbp = FourLimbBp.LtAnkBp_Sbp;
                    //arrGetBpHandle[NumOfBpMrs].LtAnkBp_Dbp = FourLimbBp.LtAnkBp_Dbp;
                    //arrGetBpHandle[NumOfBpMrs].LtAnkBp_Map = FourLimbBp.LtAnkBp_Map;

                    //arrGetBpHandle[NumOfBpMrs].RtAnkBp_Sbp = FourLimbBp.RtAnkBp_Sbp;
                    //arrGetBpHandle[NumOfBpMrs].RtAnkBp_Dbp = FourLimbBp.RtAnkBp_Dbp;
                    //arrGetBpHandle[NumOfBpMrs].RtAnkBp_Map = FourLimbBp.RtAnkBp_Map;
                    //    '用于数据库保存
                    arrGetBpSave[NumOfBpMrs] = arrGetBpHandle[NumOfBpMrs];
                    NumOfBpMrs = NumOfBpMrs + 1;
                    if (NumOfBpMrs <= 1)
                    {
                        bPressMrsStart = true;
                        measureViewModel.Tips = "第一次血压测量完成，60秒后自动进行第二次血压测量，请耐心稍等！";
                    }
                    //测量两次血压已完成
                    else
                    {
                        //血压测量结束。改变控件状态
                        //两次测量的四肢血压值除以二为目前的血压值（单个的值）
                        try
                        {
                            FinalBpMrsValue.LtBraBp_Sbp = (arrGetBpHandle[0].LtBraBp_Sbp + arrGetBpHandle[1].LtBraBp_Sbp) / 2;
                            FinalBpMrsValue.LtBraBp_Dbp = (arrGetBpHandle[0].LtBraBp_Dbp + arrGetBpHandle[1].LtBraBp_Dbp) / 2;
                            FinalBpMrsValue.LtBraBp_Map = (arrGetBpHandle[0].LtBraBp_Map + arrGetBpHandle[1].LtBraBp_Map) / 2;
                            //FinalBpMrsValue.RtBraBp_Sbp = (arrGetBpHandle[0].RtBraBp_Sbp + arrGetBpHandle[1].RtBraBp_Sbp) / 2;
                            //FinalBpMrsValue.RtBraBp_Dbp = (arrGetBpHandle[0].RtBraBp_Dbp + arrGetBpHandle[1].RtBraBp_Dbp) / 2;
                            //FinalBpMrsValue.RtBraBp_Map = (arrGetBpHandle[0].RtBraBp_Map + arrGetBpHandle[1].RtBraBp_Map) / 2;
                            //FinalBpMrsValue.LtAnkBp_Sbp = (arrGetBpHandle[0].LtAnkBp_Sbp + arrGetBpHandle[1].LtAnkBp_Sbp) / 2;
                            //FinalBpMrsValue.LtAnkBp_Dbp = (arrGetBpHandle[0].LtAnkBp_Dbp + arrGetBpHandle[1].LtAnkBp_Dbp) / 2;
                            //FinalBpMrsValue.LtAnkBp_Map = (arrGetBpHandle[0].LtAnkBp_Map + arrGetBpHandle[1].LtAnkBp_Map) / 2;
                            //FinalBpMrsValue.RtAnkBp_Sbp = (arrGetBpHandle[0].RtAnkBp_Sbp + arrGetBpHandle[1].RtAnkBp_Sbp) / 2;
                            //FinalBpMrsValue.RtAnkBp_Dbp = (arrGetBpHandle[0].RtAnkBp_Dbp + arrGetBpHandle[1].RtAnkBp_Dbp) / 2;
                            //FinalBpMrsValue.RtAnkBp_Map = (arrGetBpHandle[0].RtAnkBp_Map + arrGetBpHandle[1].RtAnkBp_Map) / 2;
                            nBSbp = FinalBpMrsValue.LtBraBp_Sbp;// '用于标定
                            nBDbp = FinalBpMrsValue.LtBraBp_Dbp;// '用于标定
                            //rBSbp = FinalBpMrsValue.RtBraBp_Sbp;// '用于标定
                            //rBDbp = FinalBpMrsValue.RtBraBp_Dbp;// '用于标定
                            //两侧ABI值（Ank/Bra)
                            BraHigherSbp = FinalBpMrsValue.LtBraBp_Sbp > FinalBpMrsValue.RtBraBp_Sbp ? FinalBpMrsValue.LtBraBp_Sbp : FinalBpMrsValue.RtBraBp_Sbp;
                            AnkHigherSbp = FinalBpMrsValue.LtAnkBp_Sbp > FinalBpMrsValue.RtAnkBp_Sbp ? FinalBpMrsValue.LtAnkBp_Sbp : FinalBpMrsValue.RtAnkBp_Sbp;
                            // '选择上肢血压较高的一侧计算左右ABI
                            //Temp_ABI = FinalBpMrsValue.LtAnkBp_Sbp / BraHigherSbp;
                            //左侧ABI
                            //g_typeIndexValue.LtAbi = (double)Math.Round((decimal)Temp_ABI, 2, MidpointRounding.AwayFromZero);
                            //Temp_ABI = FinalBpMrsValue.RtAnkBp_Sbp / BraHigherSbp;
                            //g_typeIndexValue.RtAbi = (double)Math.Round((decimal)Temp_ABI, 2, MidpointRounding.AwayFromZero);
                            //Temp_ABI = AnkHigherSbp / BraHigherSbp;
                            //g_typeIndexValue.Abi = (double)Math.Round((decimal)Temp_ABI, 2, MidpointRounding.AwayFromZero);
                            //g_typeBpMrsValue = FinalBpMrsValue;
                        }
                        catch (Exception ex)
                        {
                            Dispatcher.Invoke(new Action(() =>
                            {
                                measureViewModel.Tips = ex.Message + "血压值计算失败！";
                            }));
                        }
                        //  '变量清零
                        InitABIMrsRelatedVariables();
                        //  '两次血压测量完成(更改bPulseMrsStart = true;）//可以进行脉搏波测量
                        CompleteABIMeasurement();
                        Dispatcher.BeginInvoke(new Action(() =>
                        {
                            TimerProcessData.Enabled = true;
                            TimerProcessData.Interval = 1000;  //2秒后进入ABI数据保存 // tongshang 
                        }));
                    }
                }
            }
            else
            if (PressMrsMode == EnumData.MeasureMode.ExperienceMode)
            {
                FinalBpMrsValue.LtBraBp_Sbp = FourLimbBp.LtBraBp_Sbp;
                FinalBpMrsValue.LtBraBp_Dbp = FourLimbBp.LtBraBp_Dbp;
                FinalBpMrsValue.LtBraBp_Map = FourLimbBp.LtBraBp_Map;
                //FinalBpMrsValue.RtBraBp_Sbp = FourLimbBp.RtBraBp_Sbp;
                //FinalBpMrsValue.RtBraBp_Dbp = FourLimbBp.RtBraBp_Dbp;
                //FinalBpMrsValue.RtBraBp_Map = FourLimbBp.RtBraBp_Map;
                //FinalBpMrsValue.LtAnkBp_Sbp = FourLimbBp.LtAnkBp_Sbp;
                //FinalBpMrsValue.LtAnkBp_Dbp = FourLimbBp.LtAnkBp_Dbp;
                //FinalBpMrsValue.LtAnkBp_Map = FourLimbBp.LtAnkBp_Map;
                //FinalBpMrsValue.RtAnkBp_Sbp = FourLimbBp.RtAnkBp_Sbp;
                //FinalBpMrsValue.RtAnkBp_Dbp = FourLimbBp.RtAnkBp_Dbp;
                //FinalBpMrsValue.RtAnkBp_Map = FourLimbBp.RtAnkBp_Map;
                arrGetBpSave[0] = FinalBpMrsValue;
                nBSbp = FinalBpMrsValue.LtBraBp_Sbp;// '用于标定
                nBDbp = FinalBpMrsValue.LtBraBp_Dbp;// '用于标定
                //rBSbp = FinalBpMrsValue.RtBraBp_Sbp;// '用于标定
                //rBDbp = FinalBpMrsValue.RtBraBp_Dbp;// '用于标定
                TestMode.ModelChange = 2;
                if (TestMode.ModelChange == 2)//单肢体循环
                {
                    switch (TestMode.CommandWordSend)
                    {
                        case 0x01:
                            switch (CommandWordSend)
                            {
                               
                                case 0x0F:
                                    break;
                            }
                            break;
                        case 0x02:
                            switch (CommandWordSend)
                            {
                                case 0x00:
                                case 0x0A:
                                case 0x0C:
                                case 0x0F:
                                    TestMode.CommandWordSend = 0x03;//开始测量右臂；
                                    BpTest_Function(TestMode.CommandWordSend);
                                    CuffAssignment(TestMode.CommandWordSend);
                                    Dispatcher.BeginInvoke(new Action(() =>
                                    {
                                        measureViewModel.Tips = "温馨提示：左踝血压测量完成，开始测量右臂血压！";
                                    }));
                                    break;
                                case 0x0D:
                                    TestMode.CommandWordSend = 0x04;//开始测量右踝
                                    BpTest_Function(TestMode.CommandWordSend);
                                    CuffAssignment(TestMode.CommandWordSend);
                                    Dispatcher.BeginInvoke(new Action(() =>
                                    {
                                        measureViewModel.Tips = "温馨提示：左踝血压测量完成，开始测量右踝血压！";
                                    }));
                                    break;
                                case 0x06://左侧，直接出结果
                                    BraHigherSbp = FinalBpMrsValue.LtBraBp_Sbp > FinalBpMrsValue.RtBraBp_Sbp ? FinalBpMrsValue.LtBraBp_Sbp : FinalBpMrsValue.RtBraBp_Sbp;
                                    AnkHigherSbp = FinalBpMrsValue.LtAnkBp_Sbp > FinalBpMrsValue.RtAnkBp_Sbp ? FinalBpMrsValue.LtAnkBp_Sbp : FinalBpMrsValue.RtAnkBp_Sbp;
                                    if (FinalBpMrsValue.LtBraBp_Sbp != 0 && FinalBpMrsValue.LtAnkBp_Sbp != 0)
                                    {
                                        Temp_ABI = (double)FinalBpMrsValue.LtAnkBp_Sbp / FinalBpMrsValue.LtBraBp_Sbp;
                                        g_typeIndexValue.LtAbi = (double)Math.Round((decimal)Temp_ABI, 2, MidpointRounding.AwayFromZero);
                                    }
                                    else
                                        g_typeIndexValue.LtAbi = 0;
                                    //Temp_ABI = (double)AnkHigherSbp / BraHigherSbp;
                                    g_typeIndexValue.Abi = (double)Math.Round((decimal)Temp_ABI, 2, MidpointRounding.AwayFromZero);
                                    g_typeBpMrsValue = FinalBpMrsValue;
                                    InitABIMrsRelatedVariables();
                                    CompleteABIMeasurement();
                                    Dispatcher.BeginInvoke(new Action(()=>
                                    {
                                        strTip = "温馨提示：所选肢体血压读取完成！";
                                        measureViewModel.Tips = strTip;
                                        TimerProcessData.Enabled = true;
                                        TimerProcessData.Interval = 2000;  //2秒后进入ABI数据保存 // tongshang 
                                    }));
                                    break;
                            }
                            break;
                        case 0x03:
                            switch (CommandWordSend)
                            {
                                case 0x00:
                                case 0x07:
                                case 0x0E:
                                case 0x0F:
                                    TestMode.CommandWordSend = 0x04;//开始测量左踝；ffffffffffffff
                                    BpTest_Function(TestMode.CommandWordSend);
                                    CuffAssignment(TestMode.CommandWordSend);
                                    Dispatcher.BeginInvoke(new Action(() =>
                                    {
                                        measureViewModel.Tips = "温馨提示：右臂血压测量完成，开始测量右踝血压！";
                                    }));
                                    break;
                                case 0x0A:
                                case 0x0C:
                                    BraHigherSbp = FinalBpMrsValue.LtBraBp_Sbp > FinalBpMrsValue.RtBraBp_Sbp ? FinalBpMrsValue.LtBraBp_Sbp : FinalBpMrsValue.RtBraBp_Sbp;
                                    AnkHigherSbp = FinalBpMrsValue.LtAnkBp_Sbp > FinalBpMrsValue.RtAnkBp_Sbp ? FinalBpMrsValue.LtAnkBp_Sbp : FinalBpMrsValue.RtAnkBp_Sbp;
                                    if (FinalBpMrsValue.LtBraBp_Sbp != 0 && FinalBpMrsValue.LtAnkBp_Sbp != 0)
                                    {
                                        Temp_ABI = (double)FinalBpMrsValue.LtAnkBp_Sbp / FinalBpMrsValue.LtBraBp_Sbp;
                                        g_typeIndexValue.LtAbi = (double)Math.Round((decimal)Temp_ABI, 2, MidpointRounding.AwayFromZero);
                                    }
                                    else
                                        g_typeIndexValue.LtAbi = 0;
                                    if (FinalBpMrsValue.RtBraBp_Sbp != 0 && FinalBpMrsValue.RtAnkBp_Sbp != 0)
                                    {
                                        Temp_ABI = (double)FinalBpMrsValue.RtAnkBp_Sbp / FinalBpMrsValue.RtBraBp_Sbp;
                                        g_typeIndexValue.RtAbi = (double)Math.Round((decimal)Temp_ABI, 2, MidpointRounding.AwayFromZero);
                                    }
                                    else
                                        g_typeIndexValue.RtAbi = 0;
                                    g_typeBpMrsValue = FinalBpMrsValue;
                                    InitABIMrsRelatedVariables();
                                    CompleteABIMeasurement();
                                    Dispatcher.BeginInvoke(new Action(()=>
                                    {
                                        strTip = "温馨提示：所选肢体血压读取完成！";
                                        measureViewModel.Tips = strTip;
                                        TimerProcessData.Enabled = true;
                                        TimerProcessData.Interval = 2000;  //2秒后进入ABI数据保存 // tongshang 
                                    }));
                                    break;
                            }
                            break;
                        case 0x04:
                            switch (CommandWordSend)
                            {
                                case 0x00:
                                case 0x07:
                                case 0x0B:
                                case 0x0D:
                                case 0x0E:
                                case 0x0F:
                                    BraHigherSbp = FinalBpMrsValue.LtBraBp_Sbp > FinalBpMrsValue.RtBraBp_Sbp ? FinalBpMrsValue.LtBraBp_Sbp : FinalBpMrsValue.RtBraBp_Sbp;
                                    AnkHigherSbp = FinalBpMrsValue.LtAnkBp_Sbp > FinalBpMrsValue.RtAnkBp_Sbp ? FinalBpMrsValue.LtAnkBp_Sbp : FinalBpMrsValue.RtAnkBp_Sbp;
                                    if (FinalBpMrsValue.LtBraBp_Sbp != 0 && FinalBpMrsValue.LtAnkBp_Sbp != 0)
                                    {
                                        Temp_ABI = (double)FinalBpMrsValue.LtAnkBp_Sbp / FinalBpMrsValue.LtBraBp_Sbp;
                                        g_typeIndexValue.LtAbi = (double)Math.Round((decimal)Temp_ABI, 2, MidpointRounding.AwayFromZero);
                                    }
                                    else
                                        g_typeIndexValue.LtAbi = 0;
                                    if (FinalBpMrsValue.RtBraBp_Sbp != 0 && FinalBpMrsValue.RtAnkBp_Sbp != 0)//只有手臂脚踝血压值不等于0
                                    {
                                        Temp_ABI = (double)FinalBpMrsValue.RtAnkBp_Sbp / FinalBpMrsValue.RtBraBp_Sbp;
                                        g_typeIndexValue.RtAbi = (double)Math.Round((decimal)Temp_ABI, 2, MidpointRounding.AwayFromZero);
                                    }
                                    else
                                        g_typeIndexValue.RtAbi = 0;
                                    g_typeBpMrsValue = FinalBpMrsValue;
                                    //'变量清零
                                    InitABIMrsRelatedVariables();
                                    //  '两次血压测量完成
                                    CompleteABIMeasurement();
                                    //判断下一步应该执行什么操作
                                    Dispatcher.BeginInvoke(new Action(()=>
                                    {
                                        TimerProcessData.Enabled = true;
                                        TimerProcessData.Interval = 2000;  //2秒后进入ABI数据保存 // tongshang 
                                    }));
                                    CuffAssignment(CommandWordSend);
                                    break;
                            }
                            break;
                    }
                }
            }
        }//处理桡动脉波形数据
        //处理桡动脉波形数据
        //把所有的变量清零
        private void InitABIMrsRelatedVariables()
        {
            NumOfBpMrs = 0;//         '2次获取的血压值
            get_bp.LtBraBp_Sbp = 0;// '每次获取的血压值
            get_bp.LtBraBp_Dbp = 0;
            get_bp.LtBraBp_Map = 0;
            //get_bp.RtBraBp_Sbp = 0;
            //get_bp.RtBraBp_Dbp = 0;
            //get_bp.RtBraBp_Map = 0;
            //get_bp.LtAnkBp_Sbp = 0;
            //get_bp.LtAnkBp_Dbp = 0;
            //get_bp.LtAnkBp_Map = 0;
            //get_bp.RtAnkBp_Sbp = 0;
            //get_bp.RtAnkBp_Dbp = 0;
            //get_bp.RtAnkBp_Map = 0;
            //'两次测量的四肢血压值
            for (int i = 0; i < 2; i++)
            {
                arrGetBpHandle[i].LtBraBp_Sbp = 0;
                arrGetBpHandle[i].LtBraBp_Dbp = 0;
                arrGetBpHandle[i].LtBraBp_Map = 0;
                //arrGetBpHandle[i].RtBraBp_Sbp = 0;
                //arrGetBpHandle[i].RtBraBp_Dbp = 0;
                //arrGetBpHandle[i].RtBraBp_Map = 0;
                //arrGetBpHandle[i].LtAnkBp_Sbp = 0;
                //arrGetBpHandle[i].LtAnkBp_Dbp = 0;
                //arrGetBpHandle[i].LtAnkBp_Map = 0;
                //arrGetBpHandle[i].RtAnkBp_Sbp = 0;
                //arrGetBpHandle[i].RtAnkBp_Dbp = 0;
                //arrGetBpHandle[i].RtAnkBp_Map = 0;
            }
        }
        //血压测量完成计算ABI值判断健康状态
        private void CompleteABIMeasurement()
        {
            //修改血压相关控件状态把所有的textbox框都填上响应的数值
            measureViewModel.LBSbp = FinalBpMrsValue.LtBraBp_Sbp.ToString();
            measureViewModel.LBDbp = FinalBpMrsValue.LtBraBp_Dbp.ToString();
            measureViewModel.LBMap = FinalBpMrsValue.LtBraBp_Map.ToString();
            //measureViewModel.RBSbp = FinalBpMrsValue.RtBraBp_Sbp.ToString();
            //measureViewModel.RBDbp = FinalBpMrsValue.RtBraBp_Dbp.ToString();
            //measureViewModel.RBMap = FinalBpMrsValue.RtBraBp_Map.ToString();

            //measureViewModel.LASbp = FinalBpMrsValue.LtAnkBp_Sbp.ToString();
            //measureViewModel.LADbp = FinalBpMrsValue.LtAnkBp_Dbp.ToString();
            //measureViewModel.LAMap = FinalBpMrsValue.LtAnkBp_Map.ToString();
            //measureViewModel.RASbp = FinalBpMrsValue.RtAnkBp_Sbp.ToString();
            //measureViewModel.RADbp = FinalBpMrsValue.RtAnkBp_Dbp.ToString();
            //measureViewModel.RAMap = FinalBpMrsValue.RtAnkBp_Map.ToString();
            //measureViewModel.LeftAbi = g_typeIndexValue.LtAbi.ToString();
            //measureViewModel.RightAbi = g_typeIndexValue.RtAbi.ToString();
        }
        /// <summary>
        /// 保存到数据库
        /// </summary>
        /// <returns></returns>
        private bool SaveDataAfterBP()
        {
            bool SaveDataFlag = false;
            string Sql;    //  Left:112 124 120;Right:140 120 90;
            strFirBraBp = "Left:" + arrGetBpSave[0].LtBraBp_Sbp.ToString() + "+" +
                                    arrGetBpSave[0].LtBraBp_Dbp.ToString() + "+" +
                                    arrGetBpSave[0].LtBraBp_Map.ToString();//+";"+
            //"Right:" + arrGetBpSave[0].RtBraBp_Sbp.ToString() + "+" +
            //           arrGetBpSave[0].RtBraBp_Dbp.ToString() + "+" +
            //           arrGetBpSave[0].RtBraBp_Map.ToString();
            strSecBraBp = "Left:" + arrGetBpSave[1].LtBraBp_Sbp.ToString() + "+" +
                                    arrGetBpSave[1].LtBraBp_Dbp.ToString() + "+" +
                                    arrGetBpSave[1].LtBraBp_Map.ToString();//+";"+
            //"Right:" + arrGetBpSave[1].RtBraBp_Sbp.ToString() + "+" +
            //           arrGetBpSave[1].RtBraBp_Dbp.ToString() + "+" +
            //           arrGetBpSave[1].RtBraBp_Map.ToString();
            //strFirAnkBp = "Left:" + arrGetBpSave[0].LtAnkBp_Sbp.ToString() + "+" +
            //                        arrGetBpSave[0].LtAnkBp_Dbp.ToString() + "+" +
            //                        arrGetBpSave[0].LtAnkBp_Map.ToString();//+";"+
            //"Right:" + arrGetBpSave[0].RtAnkBp_Sbp.ToString() + "+" +
            //           arrGetBpSave[0].RtAnkBp_Dbp.ToString() + "+" +
            //           arrGetBpSave[0].RtAnkBp_Map.ToString();
            //strSecAnkBp = "Left:" + arrGetBpSave[1].LtAnkBp_Sbp.ToString() + "+" +
            //                        arrGetBpSave[1].LtAnkBp_Dbp.ToString() + "+" +
            //                        arrGetBpSave[1].LtAnkBp_Map.ToString();//+";"+
                         //"Right:" + arrGetBpSave[1].RtAnkBp_Sbp.ToString() + "+" +
                         //           arrGetBpSave[1].RtAnkBp_Dbp.ToString() + "+" +
                         //           arrGetBpSave[1].RtAnkBp_Map.ToString();
            if (Variable.Test_ABI_num == 0 && Variable.Test_AI_num == 0)
            {
                g_strDateTime = DateTime.Now; // 格式：2008-9-4 20:12:12
                Variable.ErrorTime = g_strDateTime;
                pulsedata.userId = userInfo.UserId;
                pulsedata.userName = userInfo.UserName;
                pulsedata.userSex = userInfo.UserSex;
                pulsedata.userAge = userInfo.UserAge;
                pulsedata.userHeight = userInfo.UserHeight;
                pulsedata.userWeight = userInfo.UserWeight;
                pulsedata.userBirthday = userInfo.UserBirthday.ToString();
                pulsedata.TestDateTime = g_strDateTime.ToString();
                pulsedata.TestDate = g_strDateTime.ToString();
                pulsedata.ABI_num = 1;
                if (g_typeBpMrsValue.LtBraBp_Sbp != 0)
                {
                    g_typeBpMrsValue.Dbp += g_typeBpMrsValue.LtBraBp_Dbp;
                    g_typeBpMrsValue.Sbp += g_typeBpMrsValue.LtBraBp_Sbp;
                    sbpCount++;
                }
                if (g_typeBpMrsValue.LtAnkBp_Sbp != 0)
                {
                    g_typeBpMrsValue.Dbp += g_typeBpMrsValue.LtAnkBp_Dbp;
                    g_typeBpMrsValue.Sbp += g_typeBpMrsValue.LtAnkBp_Sbp;
                    sbpCount++;
                }
                if (g_typeBpMrsValue.RtBraBp_Sbp != 0)
                {
                    g_typeBpMrsValue.Dbp += g_typeBpMrsValue.RtBraBp_Dbp;
                    g_typeBpMrsValue.Sbp += g_typeBpMrsValue.RtBraBp_Sbp;
                    sbpCount++;
                }
                if (g_typeBpMrsValue.RtAnkBp_Sbp != 0)
                {
                    g_typeBpMrsValue.Dbp += g_typeBpMrsValue.RtAnkBp_Dbp;
                    g_typeBpMrsValue.Sbp += g_typeBpMrsValue.RtAnkBp_Sbp;
                    sbpCount++;
                }
                if (sbpCount != 0)
                {
                    g_typeBpMrsValue.Dbp = (int)(g_typeBpMrsValue.Dbp /sbpCount);
                    g_typeBpMrsValue.Sbp = (int)(g_typeBpMrsValue.Sbp / sbpCount);
                }
                else
                {
                    g_typeBpMrsValue.Dbp = 0;
                    g_typeBpMrsValue.Sbp = 0;
                }
                Record_Index.Sbp = g_typeBpMrsValue.Sbp;
                Record_Index.Dbp = g_typeBpMrsValue.Dbp;
                if (TestMode.LBBP_Select != false)//左臂和右臂必须会测一个
                {
                    Record_Index.LtBraBp_Sbp = g_typeBpMrsValue.LtBraBp_Sbp;
                    Record_Index.LtBraBp_Dbp = g_typeBpMrsValue.LtBraBp_Dbp;
                }
                else
                {
                    Record_Index.LtBraBp_Sbp = g_typeBpMrsValue.RtBraBp_Sbp;
                    Record_Index.LtBraBp_Dbp = g_typeBpMrsValue.RtBraBp_Dbp;
                }
                pulsedata.Sbp = g_typeBpMrsValue.Sbp;
                pulsedata.Dbp = g_typeBpMrsValue.Dbp;
                pulsedata.Pp = g_typeBpMrsValue.Sbp - g_typeBpMrsValue.Dbp;
                pulsedata.Sbp = Record_Index.LtBraBp_Sbp;
                pulsedata.Dbp = Record_Index.LtBraBp_Dbp;
                pulsedata.Pp = Record_Index.LtBraBp_Sbp - Record_Index.LtBraBp_Dbp;
                pulsedata.Map = g_typeBpMrsValue.LtBraBp_Map;
                pulsedata.BpHr = get_bp_hr;
                pulsedata.LeftBraSbp = g_typeBpMrsValue.LtBraBp_Sbp;
                pulsedata.LeftBraDbp = g_typeBpMrsValue.LtBraBp_Dbp;
                pulsedata.LeftBraMap = g_typeBpMrsValue.LtBraBp_Map;
                //pulsedata.RightBraSbp = g_typeBpMrsValue.RtBraBp_Sbp;
                //pulsedata.RightBraDbp = g_typeBpMrsValue.RtBraBp_Dbp;
                //pulsedata.RightBraMap = g_typeBpMrsValue.RtBraBp_Map;
                //pulsedata.LeftAnkSbp = g_typeBpMrsValue.LtAnkBp_Sbp;
                //pulsedata.LeftAnkDbp = g_typeBpMrsValue.LtAnkBp_Dbp;
                //pulsedata.LeftAnkMap = g_typeBpMrsValue.LtAnkBp_Map;
                //pulsedata.RightAnkSbp = g_typeBpMrsValue.RtAnkBp_Sbp;
                //pulsedata.RightAnkDbp = g_typeBpMrsValue.RtAnkBp_Dbp;
                //pulsedata.RightAnkMap = g_typeBpMrsValue.RtAnkBp_Map;
                //pulsedata.LeftABI = g_typeIndexValue.LtAbi;
                //pulsedata.RightABI = g_typeIndexValue.RtAbi;
                //踝动脉较高的SBP除以肱动脉较高的SBP
                pulsedata.ABI = Convert.ToInt32(g_typeIndexValue.Abi);
                // '保存两次测量的血压值
                pulsedata.FristBraBP = strFirBraBp;
                pulsedata.SecondBraBP = strSecBraBp;
                pulsedata.FristAnkBP = strFirAnkBp;
                pulsedata.SecondAnkBP = strSecAnkBp;
                pulsedata.HaveUpload = "N";
                pulsedata.MrsLocation = Variable.strMrsLocation;
                pulsedata.DeviceNumber = Variable.strSerialNumber;
                pulsedata.MeasureMode = PressMrsMode.ToString();
                string bpdata = JsonConvert.SerializeObject(pulsedata);
                LogUtil.Info(bpdata);
                if (TestMode.LBBP_Select)
                {
                    pulsedata.LBBP_Select = "1";
                }
                else
                {
                    pulsedata.LBBP_Select = "0";
                }
                if (TestMode.LABP_Select)
                {
                    pulsedata.LABP_Select = "1";
                }
                else
                {
                    pulsedata.LABP_Select = "0";
                }
                if (TestMode.RBBP_Select)
                {
                    pulsedata.RBBP_Select = "1";
                }
                else
                {
                    pulsedata.RBBP_Select = "0";
                }
                if (TestMode.RABP_Select)
                {
                    pulsedata.RABP_Select = "1";
                }
                else
                {
                    pulsedata.RABP_Select = "0";
                }
                int NoZero = 0;
                if (g_typeBpMrsValue.LtBraBp_Sbp != 0)
                    NoZero++;
                if (g_typeBpMrsValue.LtAnkBp_Sbp != 0)
                    NoZero++;
                if (g_typeBpMrsValue.RtBraBp_Sbp != 0)
                    NoZero++;
                if (g_typeBpMrsValue.RtAnkBp_Sbp != 0)
                    NoZero++;
                NoZero = 0;
                if (g_typeBpMrsValue.LtBraBp_Dbp != 0)
                    NoZero++;
                if (g_typeBpMrsValue.LtAnkBp_Dbp != 0)
                    NoZero++;
                if (g_typeBpMrsValue.RtBraBp_Dbp != 0)
                    NoZero++;
                if (g_typeBpMrsValue.RtAnkBp_Dbp != 0)
                    NoZero++;
                Variable.Test_ABI_num = 1;
                SaveDataFlag = true;
            }
            //变量数组清零,下一次测量做准备
            for (int i = 0; i < 2; i++)
            {
                arrGetBpSave[i].LtBraBp_Sbp = 0;
                arrGetBpSave[i].LtBraBp_Dbp = 0;
                arrGetBpSave[i].LtBraBp_Map = 0;
                arrGetBpSave[i].RtBraBp_Sbp = 0;
                arrGetBpSave[i].RtBraBp_Dbp = 0;
                arrGetBpSave[i].RtBraBp_Map = 0;
                arrGetBpSave[i].LtAnkBp_Sbp = 0;
                arrGetBpSave[i].LtAnkBp_Dbp = 0;
                arrGetBpSave[i].LtAnkBp_Map = 0;
                arrGetBpSave[i].RtAnkBp_Sbp = 0;
                arrGetBpSave[i].RtAnkBp_Dbp = 0;
                arrGetBpSave[i].RtAnkBp_Map = 0;
            }
            return SaveDataFlag;
        }
        //显示颈上下肢脉搏波形
        private void DisplayPulseWaveform()
        {
            LeftBraData.Clear();
            LeftAnkData.Clear();
            RightBraData.Clear();
            RightAnkData.Clear();
            ECGData.Clear();
            PCGData.Clear();
            if (TestMode.LBBP_Select)
            {
                for (int i = 0; i < LCpRawData.Count; i++)
                {
                    ObservablePoint item2 = new ObservablePoint();
                    item2.X = i;
                    item2.Y = LCpRawData[i]+400;
                    LeftBraData.Add(item2);
                }
            }
            if (TestMode.LABP_Select)
            {
                for (int i = 0; i < LFpRawData.Count; i++)
                {
                    ObservablePoint item3 = new ObservablePoint();
                    item3.X = i;
                    item3.Y = LFpRawData[i]+400;
                    LeftAnkData.Add(item3);
                }
            }
            if (TestMode.RBBP_Select)
            {
                for(int i = 0; i < RCpRawData.Count; i++)
                {
                    ObservablePoint item4 = new ObservablePoint();
                    item4.X = i;
                    item4.Y = RCpRawData[i];
                    RightBraData.Add(item4);
                }
            }
            if (TestMode.RABP_Select)
            {
                for(int i = 0; i < RFpRawData.Count; i++)
                {
                    ObservablePoint item5 = new ObservablePoint();
                    item5.X = i;
                    item5.Y = RFpRawData[i];
                    RightAnkData.Add(item5);
                }
            }
            //奇数保存的是下肢，偶数保存的是上肢
            if (TestMode.ECGPCG_Select)
            {
                for (int i = 0; i < ECGRawData.Count; i++)
                {
                    ObservablePoint item2 = new ObservablePoint();
                    item2.X = i;
                    item2.Y = ECGRawData[i];
                    ECGData.Add(item2);
                }
                for (int i = 0; i < PCGRawData.Count; i++)
                {
                    ObservablePoint item2 = new ObservablePoint();
                    item2.X = i;
                    item2.Y = PCGRawData[i];
                    PCGData.Add(item2);
                }
            }
        }
        private bool HandleAIPulseData(ref long iPos, ref int iData)
        {
            nCount = nCount + 1;
            //采样频率将至250Hz运算时间降低
            if (iPos % 2 == 0)
            {
                DataOneSec.Add((double)iData);//获取的一半采样点
                DataTwoSec.Add((double)iData);
                AICountTwoSec = AICountTwoSec + 1;
                AICountOneSec = AICountOneSec + 1;
            }
            //开始记录波形，到8结束，共12秒
            if (nMarkSelect >= 3 && RpRawDataNum < 12 * Sample_Rate/*nMarkSelect <= 9*/)
            {
                if (RpRawDataNum < 12 * Sample_Rate)
                {
                    RpRawData.Add(iData);
                    RpRawDataNum = RpRawDataNum + 1;
                }
            }
            int MaxValue;
            int MinValue;
            int DifValue;
            //放大倍数一秒调节一次
            if (nMarkSelect < 2 && AICountOneSec >= 1 && AICountOneSec == Sample_Rate / 2)
            {
                MaxValue = (int)DataOneSec.Max();
                MinValue = (int)DataOneSec.Min();
                DifValue = MaxValue - MinValue;
                if ((MinValue <= 100 && MaxValue - MinValue <= 800) || (MinValue > 100 && DifValue <= 850))
                {
                    //放大倍数加1
                    SendDataBytes.Clear();
                    SendDataBytes.Add(0x00);
                    SendDataBytes.Add(0x02);
                    if (serialPortManager.SendDataToMCU(CommandWord.REQ_PWV_INC_GAIN, SendDataBytes, APPSettingUtil.ShortWaitTime) == false)//桡动脉
                    {
                        measureViewModel.Tips = "脉搏波形幅度增加命令发送失败，请检查设备通信状况";
                        return false;
                    }
                }
                if ((MaxValue >= 3700) || (DifValue > 3700))
                {
                    //放大倍数减一
                    SendDataBytes.Clear();
                    SendDataBytes.Add(0x00);
                    SendDataBytes.Add(0x02);
                    if (serialPortManager.SendDataToMCU(CommandWord.REQ_PWV_DEC_GAIN, SendDataBytes, APPSettingUtil.ShortWaitTime) == false) //桡动脉
                    {
                        measureViewModel.Tips = "脉搏波形幅度减小命令发送失败，请检查设备";
                        return false;
                    }
                }
                AICountOneSec = 0;
                DataOneSec.Clear();
            }
            //----------------------------------2秒钟筛选一次波形---------------------------------------------
            if (AICountTwoSec >= 1 && AICountTwoSec == Sample_Rate)
            {
                nMarkWait = nMarkWait + 1;
                if (nMarkSelect >= 2 && nMarkSelect <= 8)
                {
                    nMarkSelect = nMarkSelect + 1;
                    if (nMarkSelect >= 3)
                    {
                        measureViewModel.Tips = "温馨提示：脉搏波信号采集中，保持稳定";
                    }
                    Dispatcher.BeginInvoke(new Action(() =>
                    {
                        measureViewModel.TestStatus = (Convert.ToDouble(nMarkSelect) / 12 * 100).ToString("f2");
                    }));
                }//脉搏波采集完成，转到脉搏波分析程序
                if (nMarkSelect >= 9 && RpRawDataNum == Sample_Rate * 12)
                {
                    //首先确保脉搏数据已经发送完毕
                    //再转入脉搏波数据处理子程序
                    if (serialPortManager.SendDataToMCU(CommandWord.REQ_PWV_STOP, null, APPSettingUtil.ShortWaitTime) == false)
                    {
                        Timer_ACKTimeout.Enabled = false;
                        strTip = "温馨提示：脉搏数据采集完成，脉搏停止指令没有发送成功，请检查设备连接状况！";
                        measureViewModel.Tips = strTip;
                    }
                    else
                    {
                        //脉搏波测量完成
                        ProgressBarStartFlag = true;
                        PulseMrsFinishFlag = "Yes";

                        //避免程序卡顿，停止测量指令发送后，休息300ms
                        Thread.Sleep(300);
                        Timer_ACKTimeout.Enabled = true;
                        enumPwvMrsResp = PulseMrsResp.PulseStop;
                        AICountOneSec = 0;
                        AICountTwoSec = 0;
                        nMarkSelect = 0;
                        nCount = 0;
                        Dispatcher.BeginInvoke(new Action(() =>
                        {
                            measureViewModel.AITest_Img = "pack://application:,,,/Resources/Image/Measure/心血管测试.png";
                        }));
                    }
                    return true;
                }
                if (DataTwoSec.Count > 0)
                {
                    MaxValue = (int)DataTwoSec.Max();
                    MinValue = (int)DataTwoSec.Min();
                }
                else
                {
                    MaxValue = 0;
                    MinValue = 0;
                }
                DifValue = MaxValue - MinValue;
                AcquireData clsAcquisition;
                clsAcquisition = new AcquireData();
                //对每次获取的2秒脉搏波数据进行判断处理
                if (nMarkSelect < 2 && (MinValue > 50) && DifValue > 600 && DifValue < 3700 && (MaxValue < 3900))
                {
                    if (clsAcquisition.SelectWaveform(DataTwoSec, Sample_Rate) == 1)
                    {
                        nMarkSelect = nMarkSelect + 1;
                    }
                }
                AICountTwoSec = 0;
                DataTwoSec.Clear();
                //30秒内测量未结束，40秒内提示，测量不停止：超过40秒测量自动停止
                if (nMarkSelect < 2 && nMarkWait >= 15)
                {
                    if (nMarkWait < 20)
                    {
                        measureViewModel.Tips = "温馨提示：脉搏波信号不好，请重新绑扎或静息后测量";
                        //PWVStop_Function();
                        workStatus = WorkStatus.NoWork;
                    }
                    else
                    {
                        bPulseMrsStart = true;
                        SendDataBytes.Clear();
                        serialPortManager.SendDataToMCU(CommandWord.REQ_PWV_STOP, null, APPSettingUtil.ShortWaitTime);
                        {
                            Timer_ACKTimeout.Enabled = true;
                        }
                        //AlltestStopWhenPWVfail();
                        strTip = "温馨提示：桡动脉波测量停止，请重新绑扎后测量";
                        Dispatcher.BeginInvoke(new Action(() =>
                        {
                            measureViewModel.AITest_Img = "pack://application:,,,/Resources/Image/Measure/心血管测试.png";
                        }));
                        measureViewModel.Tips = strTip;
                        return false;
                    }
                }
            }
            return true;
        }
        //处理检测到的脉搏波数据(实时处理颈动脉和股动脉脉搏数据,在接收数据处理时被一直被调用)
        private void  timerRealLeftBra_Tick(object sender,System.Timers.ElapsedEventArgs e)
        {
            SendDataBytes.Clear();
            SendDataBytes.Add(0x00);
            if (TestMode.ModelChange == 0)//同步测量
            {
                switch (CommandWordSend)//先判断是哪个大流程的
                {
                    //case 0://四肢血压测量
                    //       //接下来发送左臂-左踝-右臂-右踝
                    //    if (EveryCommandWordSend == 4)
                    //    {
                    //        EveryCommandWordSend = 0;
                    //    }
                    //    EveryCommandWordSend++;
                    //    PressureCheck(Convert.ToByte(EveryCommandWordSend));
                    //    break;
                    case 6://左侧肢体，执行左侧肢体测量时，计时器应当直接从左臂->左踝  左踝->左臂。(1,2,1,2)
                        if (EveryCommandWordSend == 2)
                        {
                            EveryCommandWordSend = 0;
                        }
                        EveryCommandWordSend++;
                        PressureCheck(Convert.ToByte(EveryCommandWordSend));
                        break;
                    //case 7://右侧(3,4)
                    //    if (EveryCommandWordSend == 0)
                    //    {
                    //        EveryCommandWordSend+=2;
                    //    }
                    //    if (EveryCommandWordSend == 4)
                    //    {
                    //        EveryCommandWordSend = 2;
                    //    }
                    //    EveryCommandWordSend++;
                    //    PressureCheck(Convert.ToByte(EveryCommandWordSend));
                    //    break;
                    //case 0x08://上肢  左臂-右臂（1,3,1,3）
                    //    if (EveryCommandWordSend == 1)
                    //    {
                    //        EveryCommandWordSend = 2;
                    //    }
                    //    else if (EveryCommandWordSend == 3)
                    //    {
                    //        EveryCommandWordSend = 0;
                    //    }
                    //    EveryCommandWordSend++;
                    //    PressureCheck(Convert.ToByte(EveryCommandWordSend));
                    //    break;
                    //case 0x0A://右臂左踝 2,3,2,3
                    //    if (EveryCommandWordSend == 0)
                    //    {
                    //        EveryCommandWordSend = 1;
                    //    }
                    //    if (EveryCommandWordSend == 3)
                    //    {
                    //        EveryCommandWordSend = 1;
                    //    }
                    //    EveryCommandWordSend++;
                    //    PressureCheck(Convert.ToByte(EveryCommandWordSend));
                    //    break;
                    //case 0x0B://左臂右踝 1,4,1,4
                    //    if (EveryCommandWordSend == 4)
                    //    {
                    //        EveryCommandWordSend = 0;
                    //    }
                    //    else if (EveryCommandWordSend == 1)
                    //    {
                    //        EveryCommandWordSend = 3;
                    //    }
                    //    EveryCommandWordSend++;
                    //    PressureCheck(Convert.ToByte(EveryCommandWordSend));
                    //    break;
                    //case 0x0C://右踝不测 接下来发送左臂-左踝-右臂-左臂（1,2,3,1,2,3）
                    //    if (EveryCommandWordSend == 3)
                    //    {
                    //        EveryCommandWordSend = 0;
                    //    }
                    //    EveryCommandWordSend++;
                    //    PressureCheck(Convert.ToByte(EveryCommandWordSend));
                    //    break;
                    //case 0x0E://右臂不测
                    //          //接下来发送左臂-左踝-右踝（1,2,4,1,2,4）
                    //    if (EveryCommandWordSend == 4)
                    //    {
                    //        EveryCommandWordSend = 0;
                    //    }
                    //    EveryCommandWordSend++;
                    //    int result = 1 << (EveryCommandWordSend % 3);//位运算左移三位
                    //    PressureCheck(Convert.ToByte(result));
                    //    break;
                    //case 0x11://左踝不测 
                    //          //接下来发送左臂-右臂-右踝（1,3,4,1,3,4）
                    //    int[] index = { 1, 3, 4 };
                    //    if (EveryCommandWordSend == 4)
                    //    {
                    //        EveryCommandWordSend = 0;
                    //    }
                    //    EveryCommandWordSend++;
                    //    PressureCheck(Convert.ToByte(index[EveryCommandWordSend % 3]));
                    //    break;
                    //case 0x0F://左臂不测 
                    //          //接下来发送左踝-右臂-右踝（2,3,4,2,3,4）
                    //    int[] index1 = { 2, 3, 4 };
                    //    if (EveryCommandWordSend == 4)
                    //    {
                    //        EveryCommandWordSend = 0;
                    //    }
                    //    EveryCommandWordSend++;
                    //    PressureCheck(Convert.ToByte(index1[EveryCommandWordSend % 3]));
                    //    break;
                }
            }
            //else if (TestMode.ModelChange == 1)//单侧
            //{
            //    switch (CommandWordSend)
            //    {
            //        case 0:
            //            //接下来发送左臂-左踝-右臂-右踝
            //            if (EveryCommandWordSend == 4)
            //            {
            //                EveryCommandWordSend = 0;
            //            }
            //            EveryCommandWordSend++;
            //            PressureCheck(Convert.ToByte(EveryCommandWordSend));
            //            break;
            //        case 6://左侧肢体，执行左侧肢体测量时，计时器应当直接从左臂->左踝   左踝->左臂。(1,2,1,2)
            //            if (EveryCommandWordSend == 2)
            //            {
            //                EveryCommandWordSend = 0;
            //            }
            //            EveryCommandWordSend++;
            //            PressureCheck(Convert.ToByte(EveryCommandWordSend));
            //            break;
            //        case 0x08://上肢  左臂-右臂（1,3,1,3）
            //            if (EveryCommandWordSend == 1)
            //            {
            //                EveryCommandWordSend = 2;
            //            }
            //            else if (EveryCommandWordSend == 3)
            //            {
            //                EveryCommandWordSend = 0;
            //            }
            //            EveryCommandWordSend++;
            //            PressureCheck(Convert.ToByte(EveryCommandWordSend));
            //            break;
            //        case 0x0B://左臂右踝 1,4,1,4
            //            if (EveryCommandWordSend == 4)
            //            {
            //                EveryCommandWordSend = 0;
            //            }
            //            else if (EveryCommandWordSend == 1)
            //            {
            //                EveryCommandWordSend = 3;
            //            }
            //            EveryCommandWordSend++;
            //            PressureCheck(Convert.ToByte(EveryCommandWordSend));
            //            break;
            //        case 0x0C://右踝不测
            //                  //接下来发送左臂-左踝-右臂-左臂（1,2,3,1,2,3）
            //            if (EveryCommandWordSend == 3)
            //            {
            //                EveryCommandWordSend = 0;
            //            }
            //            EveryCommandWordSend++;
            //            PressureCheck(Convert.ToByte(EveryCommandWordSend));
            //            break;
            //        case 0x0D://右臂不测
            //                  //接下来发送左臂-左踝-右踝（1,2,4,1,2,4）
            //            if (EveryCommandWordSend == 4)
            //            {
            //                EveryCommandWordSend = 0;
            //            }
            //            EveryCommandWordSend++;
            //            int result = 1 << (EveryCommandWordSend % 3);//位运算左移三位
            //            PressureCheck(Convert.ToByte(result));
            //            break;
            //        case 0x0E://左踝不测 
            //                  //接下来发送左臂-右臂-右踝（1,3,4,1,3,4）
            //            int[] index = { 1, 3, 4 };
            //            if (EveryCommandWordSend == 4)
            //            {
            //                EveryCommandWordSend = 0;
            //            }
            //            EveryCommandWordSend++;
            //            PressureCheck(Convert.ToByte(index[EveryCommandWordSend % 3]));
            //            break;

            //    }
            //}
            else if (TestMode.ModelChange == 2)//单肢
            {

            }

        }
        private void PressureCheck(byte WhichBp)
        {
            LogUtil.Info(DateTime.Now.ToString() + "WhichBP:" + WhichBp + ":BpInflateRun:" + BpInflateRun[WhichBp - 1]);
            Console.WriteLine(DateTime.Now.ToString() + "WhichBP:" + WhichBp + ":BpInflateRun:" + BpInflateRun[WhichBp - 1]);
            //正常读取袖带压力值
            if (BpInflateRun[WhichBp - 1] == 0)
            {
                SendDataBytes.Clear();
                SendDataBytes.Add(0x00);
                SendDataBytes.Add(WhichBp);
                serialPortManager.SendDataToMCU(CommandWord.REQ_BP_PRESSURE, SendDataBytes, APPSettingUtil.ShortWaitTime);
            }
            //停止血压的测量，重新设置加压避免血压模块忙
            else if (BpInflateRun[WhichBp - 1] == 1)
            {
                SendDataBytes.Clear();
                SendDataBytes.Add(0x00);
                SendDataBytes.Add(WhichBp);
                if (serialPortManager.SendDataToMCU(CommandWord.REQ_BP_STOP, SendDataBytes, APPSettingUtil.ShortWaitTime) == false)
                {
                    Timer_ACKTimeout.Enabled = false;
                    Growl.Info("ABI测量停止命令发送失败，请检查设备连接情况");
                }
                BpInflateRun[WhichBp - 1] = 10;//定时器空转
                BP_ACK_Flag[WhichBp - 1] = -11;
            }
            else if (BpInflateRun[WhichBp - 1] == 2) //异常第二步---重新设定加压值
            {
                SendDataBytes.Clear();
                SendDataBytes.Add(0x00);
                SendDataBytes.Add(0x78);
                SendDataBytes.Add(WhichBp);
                // 先停止测量，在设定加压值避免血压模块忙
                if (serialPortManager.SendDataToMCU(CommandWord.REQ_BP_INIT_SET, SendDataBytes, APPSettingUtil.ShortWaitTime) == false)
                {

                }
                BpInflateRun[WhichBp - 1] = 10;
                BP_ACK_Flag[WhichBp - 1] = -9;
                switch (WhichBp) //看是哪个肢体的血压出现了问题，启动对应的计时器
                {

                }
            }
            else if (BpInflateRun[WhichBp - 1] == 3)//再次充气
            {
                SendDataBytes.Clear();
                SendDataBytes.Add(0x00);
                SendDataBytes.Add(WhichBp);
                if (serialPortManager.SendDataToMCU(CommandWord.REQ_BP_OBJECT_SET, SendDataBytes, APPSettingUtil.ShortWaitTime) == false)
                {
                    NumOfBpMrs = 0;
                    Dispatcher.BeginInvoke(new Action(() =>
                    {

                        measureViewModel.Tips = "温馨提示：USB通信错误，无法测量ABI";
                    }));
                }
                BpInflateRun[WhichBp - 1] = 10;
                BPOldPressure[WhichBp - 1] = -1;
                BP_ACK_Flag[WhichBp - 1] = -12;
            }
            //终止血压测量
            else if (BpInflateRun[WhichBp - 1] == 4)
            {
                SendDataBytes.Clear();
                SendDataBytes.Add(0x00);
                SendDataBytes.Add(WhichBp);
                if (serialPortManager.SendDataToMCU(CommandWord.REQ_BP_STOP, SendDataBytes, APPSettingUtil.ShortWaitTime) == false)
                {
                    Dispatcher.BeginInvoke(new Action(() =>
                    {
                        Timer_ACKTimeout.Enabled = false;
                        measureViewModel.Tips = "温馨提示：血压停止命令发送失败，请检查设备通信状况!";
                    }));
                }
                BpInflateRun[WhichBp - 1] = 10;
                //3秒容错处理
                ValueOpen_Flag[WhichBp - 1] = 2;
                Dispatcher.BeginInvoke(new Action(() =>
                {
                    TimerCValueACK.Interval = 5000;//启动计时应答
                    TimerCValueACK.Start();
                }));
            }
            else if (BpInflateRun[WhichBp - 1] == 5)  //Then '''''关闭阀门
            {
                SendDataBytes.Clear();
                SendDataBytes.Add(0x06);
                SendDataBytes.Add(WhichBp);
                if (serialPortManager.SendDataToMCU(CommandWord.REQ_BP_CONTROL, SendDataBytes, APPSettingUtil.ShortWaitTime) == false)// Then ''''关闭阀门
                {
                    Dispatcher.BeginInvoke(new Action(() =>
                    {
                        Timer_ACKTimeout.Enabled = false;
                        measureViewModel.Tips = "温馨提示：关闭命令发送失败，请检查设备通信状况!";
                    }));
                }
                BpInflateRun[WhichBp - 1] = 10;//''''定时器空转
                ValveOpen_Flag[WhichBp - 1] = 3;// '''关闭阀门命令
                ValveOpen_Flag[WhichBp - 1] = 1;
                BP_ACK_Flag[WhichBp - 1] = -3;
            }
        }
        //当血压测量停止时，开始测量脉搏0-    //桡动脉
        private void PWVStartWhenBPStop()
        {
            //发送充气压力值
            //timerRealLeftBra.Enabled = false;
            SendDataBytes.Clear();
            SendDataBytes.Add(0x00);
            SendDataBytes.Add(0x80);
            SendDataBytes.Add(CommandWordSend);
            Thread.Sleep(1000);
            serialPortManager.SendDataToMCU(CommandWord.REQ_BP_INIT_SET, SendDataBytes, APPSettingUtil.ShortWaitTime);
        }
        //心电心音测试
        //private bool ECGPCGTest_Function()
        //{
        //    List<byte> HKBytes = new List<byte>();
        //    HKBytes.Add(CommandWord.HKTest);
        //    if(epserialPortManager.SendDataToMCU(CommandWord.HKcmd, HKBytes, APPSettingUtil.ShortWaitTime))
        //        return true;
        //    else
        //        return false;
        //}
        //心电心音停止测量
        //private void ECGPCGStop_Function()
        //{
        //    CommandType = CommandWord.HKcmd;
        //    List<byte> SendDataBytes = new List<byte>();
        //    SendDataBytes.Add(CommandWord.HKEndTest);
        //    epserialPortManager.SendDataToMCU(CommandType, SendDataBytes, APPSettingUtil.ShortWaitTime);
        //    if (HKdataECG.Count > 2000)
        //    {
        //    }
        //}
        //ECG波形分析
        //private bool ECGPCGWaveformAnalysis()
        //{
        //    int SumCount;
        //    List<int> WFMAPos0 = new List<int>();
        //    //集合的长度,左边有就用左边的 左边没有再用右边的集合
        //    if (GlobalVariable.WFMAPosArrayLeft0.Count != 0 && GlobalVariable.WFMAPosArrayRight0.Count != 0)
        //    {
        //        SumCount = GlobalVariable.WFMAPosArrayLeft0.Count;
        //        WFMAPos0 = GlobalVariable.WFMAPosArrayLeft0;
        //    }
        //    else if (GlobalVariable.WFMAPosArrayRight0.Count != 0 && GlobalVariable.WFMAPosArrayLeft0.Count == 0)
        //    {
        //        SumCount = GlobalVariable.WFMAPosArrayRight0.Count;
        //        WFMAPos0 = GlobalVariable.WFMAPosArrayRight0;
        //    }
        //    else
        //    {
        //        SumCount = GlobalVariable.WFMAPosArrayLeft0.Count;
        //        WFMAPos0 = GlobalVariable.WFMAPosArrayLeft0;
        //    }
        //    //心动周期 相邻的两个起始点或者峰值点的时间差
        //    int Cycle = 0;
        //    for (int i = 0; i < SumCount - 1; i++)
        //    {
        //        Cycle = Cycle + WFMAPos0[i + 1] - WFMAPos0[i];
        //    }
        //    Cycle = (int)((double)Cycle / (double)(SumCount - 1)) * 2;
        //    bool ECGPCGWaveformAnalysis = false;
        //    PCGRawData.Clear();
        //    ECGRawData.Clear();
        //    //最短的长度
        //    int ShortLength;
        //    //所有峰值点，起始点集合的长度的集合
        //    List<int> ShortCount = new List<int>();
        //    if (GlobalVariable.WFMAPosArrayLeft0.Count == 0)
        //    {
        //        ShortCount.Add(GlobalVariable.WFMAPosArrayRight6.Count);
        //        ShortCount.Add(GlobalVariable.WFMAPosArrayRight0.Count);
        //        ShortCount.Add(GlobalVariable.WFMAPosArrayRight7.Count);
        //        ShortCount.Add(GlobalVariable.WFMAPosArrayRight1.Count);
        //    }
        //    else if (GlobalVariable.WFMAPosArrayRight0.Count == 0)
        //    {
        //        ShortCount.Add(GlobalVariable.WFMAPosArrayLeft0.Count);
        //        ShortCount.Add(GlobalVariable.WFMAPosArrayLeft1.Count);
        //        ShortCount.Add(GlobalVariable.WFMAPosArrayLeft7.Count);
        //        ShortCount.Add(GlobalVariable.WFMAPosArrayLeft1.Count);
        //    }
        //    else if (GlobalVariable.WFMAPosArrayLeft0.Count != 0 && GlobalVariable.WFMAPosArrayRight0.Count != 0)
        //    {
        //        ShortCount.Add(GlobalVariable.WFMAPosArrayRight6.Count);
        //        ShortCount.Add(GlobalVariable.WFMAPosArrayRight0.Count);
        //        ShortCount.Add(GlobalVariable.WFMAPosArrayRight7.Count);
        //        ShortCount.Add(GlobalVariable.WFMAPosArrayRight1.Count);
        //        ShortCount.Add(GlobalVariable.WFMAPosArrayLeft0.Count);
        //        ShortCount.Add(GlobalVariable.WFMAPosArrayLeft1.Count);
        //        ShortCount.Add(GlobalVariable.WFMAPosArrayLeft7.Count);
        //        ShortCount.Add(GlobalVariable.WFMAPosArrayLeft1.Count);
        //    }
        //    ShortLength = ShortCount[0];//等于集合中的第一个
        //    for (int i = 0; i < ShortCount.Count; i++)
        //    {
        //        //找到两两相比较小的值
        //        if (ShortLength > ShortCount[i])// 0-1 1-2 2-3
        //            ShortLength = ShortCount[i];
        //    }
        //    //  确保至少找到一个起始点/峰值点handle
        //    if (ShortLength >= 1)
        //    {
        //        for (int i = 0; i < ShortLength; i++)
        //        {
        //            // 
        //            try
        //            {//针对有时 会出现UT为负数的情况，推测是找到了上一组的峰值点减去了下一组的起始点的时间导致的即未找到该组的起始点
        //                //解决方法先判断差值是否为大于0且小于一个心动周期如果是则加上
        //                if (((int)LCpPeakPos[i] - (int)LCpFootPos[i]) > 0 && ((int)LCpPeakPos[i] - (int)LCpFootPos[i]) < Cycle)
        //                    g_typeIndexValue.LeftBraUT = g_typeIndexValue.LeftBraUT + ((int)LCpPeakPos[i] - (int)LCpFootPos[i]);
        //                else if ((i + 1) < ShortLength && ((int)LCpPeakPos[i] - (int)LCpFootPos[i]) < 0)
        //                    g_typeIndexValue.LeftBraUT = g_typeIndexValue.LeftBraUT + ((int)LCpPeakPos[i + 1] - (int)LCpFootPos[i]);
        //                g_typeIndexValue.LeftBraMAP_PER = g_typeIndexValue.LeftBraMAP_PER +
        //                (int)((double)LCpRawData[(int)LCpFirstMaxPoint[i]] / (double)LCpRawData[(int)RCpPeakPos[i]] * 100);//转化成百分比值
        //                if (((int)LFpPeakPos[i] - (int)LFpFootPos[i]) > 0 && ((int)LFpPeakPos[i] - (int)LFpFootPos[i]) < Cycle)
        //                    g_typeIndexValue.LeftAnkUT = g_typeIndexValue.LeftAnkUT + ((int)LFpPeakPos[i] - (int)LFpFootPos[i]);
        //                else if ((i + 1) < ShortLength && ((int)LFpPeakPos[i] - (int)LFpFootPos[i]) < 0)
        //                    g_typeIndexValue.LeftAnkUT = g_typeIndexValue.LeftAnkUT + ((int)LFpPeakPos[i + 1] - (int)LFpFootPos[i]);
        //                g_typeIndexValue.LeftAnkMAP_PER = g_typeIndexValue.LeftAnkMAP_PER +
        //                (int)((double)LFpRawData[(int)LFpFirstMaxPoint[i]] / (double)LFpRawData[(int)RFpPeakPos[i]] * 100);
        //                if (((int)RCpPeakPos[i] - (int)RCpFootPos[i]) > 0 && ((int)RCpPeakPos[i] - (int)RCpFootPos[i]) < Cycle)
        //                    g_typeIndexValue.RightBraUT = g_typeIndexValue.RightBraUT + ((int)RCpPeakPos[i] - (int)RCpFootPos[i]);
        //                else if ((i + 1) < ShortLength && ((int)RCpPeakPos[i] - (int)RCpFootPos[i]) < 0)
        //                    g_typeIndexValue.RightBraUT = g_typeIndexValue.RightBraUT + ((int)RCpPeakPos[i + 1] - (int)RCpFootPos[i]);
        //                g_typeIndexValue.RightBraMAP_PER = g_typeIndexValue.RightBraMAP_PER +
        //                (int)((double)RCpRawData[(int)RCpFirstMaxPoint[i]] / (double)RCpRawData[(int)RCpPeakPos[i]] * 100);
        //                if (((int)RFpPeakPos[i] - (int)RFpFootPos[i]) > 0 && ((int)RFpPeakPos[i] - (int)RFpFootPos[i]) < Cycle)
        //                    g_typeIndexValue.RightAnkUT = g_typeIndexValue.RightAnkUT + ((int)RFpPeakPos[i] - (int)RFpFootPos[i]);
        //                else if ((i + 1) < ShortLength && ((int)RFpPeakPos[i] - (int)RFpFootPos[i]) < 0)
        //                    g_typeIndexValue.RightAnkUT = g_typeIndexValue.RightAnkUT + ((int)RFpPeakPos[i + 1] - (int)RFpFootPos[i]);
        //                g_typeIndexValue.RightAnkMAP_PER = g_typeIndexValue.RightAnkMAP_PER +
        //                (int)((double)RFpRawData[(int)RFpFirstMaxPoint[i]] / (double)RFpRawData[(int)RFpPeakPos[i]] * 100);
        //            }
        //            catch
        //            {
        //                g_typeIndexValue.LeftBraUT = 102;
        //                g_typeIndexValue.LeftAnkUT = 122;
        //                g_typeIndexValue.RightBraUT = 101;
        //                g_typeIndexValue.RightAnkUT = 132;
        //                g_typeIndexValue.LeftBraMAP_PER = 53;
        //                g_typeIndexValue.LeftAnkMAP_PER = 40;
        //                g_typeIndexValue.RightAnkMAP_PER = 50;
        //                g_typeIndexValue.RightBraMAP_PER = 61;
        //            }
        //        }
        //        if (TestMode.LBBP_Select)
        //        {
        //            g_typeIndexValue.LeftBraUT = (int)((double)g_typeIndexValue.LeftBraUT / (double)ShortLength) * 2;
        //            g_typeIndexValue.LeftBraMAP_PER = (int)((double)g_typeIndexValue.LeftBraMAP_PER / (double)ShortLength);
        //        }
        //        if (TestMode.LABP_Select)
        //        {
        //            g_typeIndexValue.LeftAnkUT = (int)((double)g_typeIndexValue.LeftAnkUT / (double)ShortLength) * 2;
        //            g_typeIndexValue.LeftAnkMAP_PER = (int)((double)g_typeIndexValue.LeftAnkMAP_PER / (double)ShortLength);
        //        }
        //        if (TestMode.RBBP_Select)
        //        {
        //            g_typeIndexValue.RightBraUT = (int)((double)g_typeIndexValue.RightBraUT / (double)ShortLength) * 2;
        //            g_typeIndexValue.RightAnkMAP_PER = (int)((double)g_typeIndexValue.RightAnkMAP_PER / (double)ShortLength);
        //        }
        //        if (TestMode.RABP_Select)
        //        {
        //            g_typeIndexValue.RightAnkUT = (int)((double)g_typeIndexValue.RightAnkUT / (double)ShortLength) * 2;
        //            g_typeIndexValue.RightBraMAP_PER = (int)((double)g_typeIndexValue.RightBraMAP_PER / (double)ShortLength);
        //        }
        //    }
        //    else//如果没有找到至少一组峰值点/起始点则跳入else语句，给出默认值
        //    {
        //        g_typeIndexValue.LeftBraUT = 102;
        //        g_typeIndexValue.LeftAnkUT = 122;
        //        g_typeIndexValue.RightBraUT = 101;
        //        g_typeIndexValue.RightAnkUT = 132;
        //        g_typeIndexValue.LeftBraMAP_PER = 53;
        //        g_typeIndexValue.LeftAnkMAP_PER = 40;
        //        g_typeIndexValue.RightAnkMAP_PER = 50;
        //        g_typeIndexValue.RightBraMAP_PER = 61;
        //    }
        //    // 调用dll，并接收返回结果(out是关键字，不要用out来接收结果)
        //    try
        //    {
        //        // ECG处理：实例化对象
        //        //SimpleRST.Class1 MyRST = new SimpleRST.Class1();
        //        //// 将C#的数据格式转换为MATLAB能够识别的数据格式
        //        //int[] ArrayECG = HKdataECG.ToArray();
        //        //int fs = 200;
        //        //MWNumericArray MWFs = fs;
        //        //MWNumericArray WMECG = ArrayECG;
        //        //MWArray[] ECGresult = MyRST.SimpleRST(9, WMECG, MWFs);
        //        //double[,] R_i = (double[,])ECGresult[0].ToArray();
        //        //double[,] S_i = (double[,])ECGresult[2].ToArray();
        //        //double[,] T_i = (double[,])ECGresult[4].ToArray();
        //        //double[,] Q_i = (double[,])ECGresult[6].ToArray();
        //        //double[,] R_amp = (double[,])ECGresult[1].ToArray();
        //        //double[,] S_amp = (double[,])ECGresult[3].ToArray();
        //        //double[,] T_amp = (double[,])ECGresult[5].ToArray();
        //        //double[,] Q_amp = (double[,])ECGresult[7].ToArray();
        //        //double[,] buffer_plot = (double[,])ECGresult[8].ToArray();
        //        //处理后的心电波形
        //        //zedGraph_testECGPCG.GraphPane.CurveList[0].Clear(); //临时注释，待恢复
        //        //zedGraph_testECGPCG.GraphPane.CurveList[1].Clear();
        //        //for (int i = 0; i < buffer_plot.GetLength(1); i++)
        //        //{
        //        //    Variable.ECGNormData.Add(buffer_plot[0, i] * 2 + 2000);
        //        //    ECGRawData.Add((double)(buffer_plot[0, i] * 2 + 2000));
        //        //    //zedGraph_testECGPCG.GraphPane.CurveList[0].AddPoint(i, buffer_plot[0, i] * 2 + 2000);
        //        //}
        //        List<int> difference = new List<int>();
        //        int differ = 0;
        //        int sum = 0;
        //        //计算pep的值
        //        //for (int i = 0; i < GlobalVariable.WFMAPosArrayLeft0.Count; i++)
        //        //{
        //        //    for (int j = 0; j < Q_i.GetLength(1); j++)
        //        //    {
        //        //        //起始点对应的时间减去Q点的点数对应的时间差
        //        //        differ = GlobalVariable.WFMAPosArrayLeft0[i] * 2 - (int)Q_i[0, j] * 5;
        //        //        //两个点的时间差不能大于一次心动周期，(大于最小值，小于一个心动周期的值)
        //        //        if (differ > 50 && differ < Cycle + 100)
        //        //        {
        //        //            sum = sum + differ;
        //        //            difference.Add(differ);
        //        //        }
        //        //    }
        //        //}
        //        int sum2 = 0;
        //        int differ2 = 0;
        //        //for (int i = 0; i < GlobalVariable.WFMAPosArrayRight0.Count; i++)
        //        //{
        //        //    for (int j = 0; j < Q_i.GetLength(1); j++)
        //        //    {
        //        //        //起始点对应的时间减去Q点的点数对应的时间差
        //        //        differ2 = GlobalVariable.WFMAPosArrayRight0[i] * 2 - (int)Q_i[0, j] * 5;
        //        //        //两个点的时间差不能大于一次心动周期，(大于最小值，小于一个心动周期的值)
        //        //        if (differ2 > 50 && differ2 < Cycle + 100)
        //        //        {
        //        //            sum = sum + differ2;
        //        //            difference.Add(differ2);
        //        //        }
        //        //    }
        //        //}
        //        g_typeIndexValue.PEP = (int)((double)sum / (double)difference.Count);
        //        if (g_typeIndexValue.PEP <= 0)
        //            g_typeIndexValue.PEP = 100;
        //    }
        //    catch(Exception e)
        //    {
        //        //g_typeIndexValue.PEP = 100;
        //        //ECGPCGWaveformAnalysis = false;
        //        //Dispatcher.BeginInvoke(new Action(() =>
        //        //{
        //        //    measureViewModel.Tips = "心电数据分析失败" + e ;
        //        //    LogUtil.Info("ECG", "心音数据分析失败" + e .Message);
        //        //}));
        //        //g_typeIndexValue.LeftBraUT = 102;
        //        //g_typeIndexValue.LeftAnkUT = 122;
        //        //g_typeIndexValue.RightBraUT = 101;
        //        //g_typeIndexValue.RightAnkUT = 132;
        //        //g_typeIndexValue.LeftBraMAP_PER = 53;
        //        //g_typeIndexValue.LeftAnkMAP_PER = 40;
        //        //g_typeIndexValue.RightAnkMAP_PER = 50;
        //        //g_typeIndexValue.RightBraMAP_PER = 61;
        //    }
        //    try
        //    {
        //        // PCG处理：实例化对象
        //        PCGAnalyze.Class1 MyPCGAnalyze = new PCGAnalyze.Class1();
        //        // 将C#的数据格式转换为MATLAB能够识别的数据格式
        //        int[] ArrayPCG = HKdataXY.ToArray();
        //        int PCGfs = 1000;
        //        MWNumericArray PCGMWFs = PCGfs;
        //        MWNumericArray WMPCG = ArrayPCG;
        //        // 调用dll，并接收返回结果(out是关键字，不要用out来接收结果)
        //        MWArray[] result = MyPCGAnalyze.PCGAnalyze(5, WMPCG, PCGMWFs);
        //        double[,] HeartRateNum = (double[,])result[0].ToArray();
        //        double[,] S1PositionT = (double[,])result[1].ToArray();
        //        double[,] S2PositionT = (double[,])result[2].ToArray();
        //        double[,] S1PositionTonly = (double[,])result[3].ToArray();
        //        double[,] HeartSounds = (double[,])result[4].ToArray();
        //        List<double> s1 = new List<double>();
        //        List<double> s1Only = new List<double>();
        //        List<double> s2 = new List<double>();
        //        List<double> sameArr = new List<double>();
        //        List<double> diffArr = new List<double>();
        //        List<int> PointIndex = new List<int>();
        //        List<double> s1Tonly = new List<double>();
        //        List<int> ET = new List<int>();
        //        //获取丢失的点（假设是第二个点不存在)
        //        for (int p = 0; p < S1PositionTonly.GetLength(1); p++)
        //            s1Only.Add(S1PositionTonly[0, p]);
        //        for (int p = 0; p < S1PositionT.GetLength(1); p++)
        //            s1.Add(S1PositionT[0, p]);
        //        for (int p = 0; p < S2PositionT.GetLength(1); p++)
        //            s2.Add(S2PositionT[0, p]);
        //        //S1only和s1的交集
        //        sameArr = s1Only.Intersect(s1).ToList();
        //        for (int p = 0; p < sameArr.Count - 1; p++)
        //        {
        //            for (int q = 0; q < s1Only.Count - 1; q++)
        //            {
        //                if (sameArr[p] == s1Only[q])
        //                {
        //                    //筛选出脉搏波起始点跟s2一一对应的点
        //                    PointIndex.Add(GlobalVariable.WFMAPosArrayLeft0[q]);
        //                }
        //            }
        //        }
        //        double s2PositonTime;
        //        int PointTime, ETTime;
        //        for (int k = 0; k < GlobalVariable.WFMAPosArrayLeft0.Count; k++)
        //        {
        //            for (int p = 0; p < s2.Count; p++)
        //            {
        //                //第二心音点对应时间   dll中计算出来的是秒需要乘以1000换算成ms进行减操作
        //                s2PositonTime = s2[p] * 1000;//换算成ms
        //                                             //与心音点对应肱动脉起始点时间
        //                PointTime = GlobalVariable.WFMAPosArrayLeft0[k] * 2;//乘以时间也换算成ms   rate=500
        //                ETTime = (int)s2PositonTime - PointTime;
        //                if (ETTime > 200 && ETTime < 280 + Cycle)
        //                    ET.Add(ETTime);//ET集合保存的就是两组数据时间差的集和
        //            }
        //        }
        //        int Max = 0, Min = 0, Sum = 0;
        //        if (ET.Count > 4)
        //        {
        //            for (int i = 0; i < ET.Count; i++)
        //            {
        //                //循环遍历找到最大值和最小值
        //                if (Min > ET[i])
        //                    Min = ET[i];
        //                if (Max < ET[i])
        //                    Max = ET[i];
        //                Sum = Sum + ET[i];
        //            }//获取
        //            double ETSumTime = Sum - Max - Min;//总时间减去一个最小值，减去一个最大值
        //            double ETCount = ET.Count - 2;
        //            double ETRatio = ETSumTime / ETCount;
        //            g_typeIndexValue.ET = (int)ETRatio;
        //        }
        //        else
        //        {
        //            //for (int i = 0; i < ET.Count; i++)
        //             //   Sum = Sum + ET[i];
        //            //if (ET.Count == 0)//未找到第二心音点
        //            //    g_typeIndexValue.ET = 280;
        //           // else
        //            //    g_typeIndexValue.ET = (int)(Sum / ET.Count);
        //        }
        //        g_typeIndexValue.ET_PEP = (double)g_typeIndexValue.ET / g_typeIndexValue.PEP;
        //        //判断计算得到的ET/PEP是否为正常的值  
        //        //
        //        //if (g_typeIndexValue.ET <= 0)
        //         //   g_typeIndexValue.ET = 280;
        //        //if (g_typeIndexValue.ET_PEP <= 0)
        //         //   g_typeIndexValue.ET_PEP = 2.8;

        //        //显示处理后的波形
        //        //for (int i = 0; i < HeartSounds.Length; i++)
        //        //{
        //        //    Variable.PCGNormData.Add((double)HeartSounds[i, 0] + 1000);
        //        //    PCGRawData.Add((double)HeartSounds[i, 0] + 1000);
        //        //}
        //        ECGPCGWaveformAnalysis = true;
        //    }
        //    catch (Exception ex)//分析数据出错时将数据保存到表中
        //    {
        //        //Dispatcher.BeginInvoke(new Action(() =>
        //        //{
        //        //    measureViewModel.Tips = "心音数据分析失败" + ex;
        //        //    LogUtil.Info("PCG","心音数据分析失败" + ex.Message);
        //        //}));
        //        //g_typeIndexValue.PEP = 200;
        //        //g_typeIndexValue.LeftBraUT = 102;
        //        //g_typeIndexValue.LeftAnkUT = 122;
        //        //g_typeIndexValue.RightBraUT = 101;
        //        //g_typeIndexValue.RightAnkUT = 132;
        //        //g_typeIndexValue.LeftBraMAP_PER = 53;
        //        //g_typeIndexValue.LeftAnkMAP_PER = 40;
        //        //g_typeIndexValue.RightAnkMAP_PER = 50;
        //        //g_typeIndexValue.RightBraMAP_PER = 61;
        //    }

        //    //if (TestMode.ECGPCG_Select)
        //    //{
        //    //    try
        //    //    {
        //    //        string PCGPackData = null;
        //    //        PCGPackData = stringMerge.MergeString(Variable.PCGNormData);
        //    //        if (PCGPackData.Length == 0)//将取得的数据按照分号拆分，疮毒为0时则表示没有保存到数据
        //    //        {
        //    //            measureViewModel.Tips = "温馨提示：心音数据采集错误！";
        //    //        }
        //    //        string ECGPackData = null;
        //    //        ECGPackData = stringMerge.MergeString(Variable.ECGNormData);
        //    //        if (ECGPackData.Length == 0)
        //    //        {//
        //    //            measureViewModel.Tips = "温馨提示：心电数据采集错误！";
        //    //        }
        //    //        pulsedata.ECG_num = 1;
        //    //        pulsedata.PEP = g_typeIndexValue.PEP;
        //    //        pulsedata.ET = g_typeIndexValue.ET;
        //    //        pulsedata.ET_PEP = g_typeIndexValue.ET_PEP;
        //    //        pulsedata.LeftBraUT = g_typeIndexValue.LeftBraUT;
        //    //        pulsedata.RightBraUT = g_typeIndexValue.RightBraUT;
        //    //        pulsedata.LeftAnkUT = g_typeIndexValue.LeftAnkUT;
        //    //        pulsedata.RightAnkUT = g_typeIndexValue.RightAnkUT;
        //    //        pulsedata.STI = g_typeIndexValue.STI;
        //    //        pulsedata.PCGRawData = PCGPackData;
        //    //        pulsedata.ECGRawData = ECGPackData;
        //    //        pulsedata.LeftBraMAP_PER = g_typeIndexValue.LeftBraMAP_PER;
        //    //        pulsedata.RightBraMAP_PER = g_typeIndexValue.RightBraMAP_PER;
        //    //        pulsedata.LeftAnkMAP_PER = g_typeIndexValue.LeftAnkMAP_PER;
        //    //        pulsedata.RightAnkMAP_PER = g_typeIndexValue.RightAnkMAP_PER;
        //    //        Variable.Test_ECG_num = 1;
        //    //        Dispatcher.BeginInvoke(new Action(() =>
        //    //        {
        //    //            measureViewModel.IsRunning = "Hidden";
        //    //        }));
        //    //    }
        //    //    catch (Exception e)
        //    //    {
        //    //        //Growl.Info("心电心音数据赋值失败！");
        //    //    }
        //    //}
        //    return ECGPCGWaveformAnalysis;
        //}
        //血压测试
        private void BpTest_Function(byte commandBP)
        {
            SendDataBytes.Clear();
            SendDataBytes.Add(0x00);
            SendDataBytes.Add(commandBP);
            serialPortManager.SendDataToMCU(CommandWord.REQ_BP_START, SendDataBytes, APPSettingUtil.ShortWaitTime);
        }
        //脉搏波测试
        private void PwvTest_Fucntion()
        {
            //发送脉搏波测量命令
            SendData.Clear();
            SendData.Add(0x00);
            SendData.Add(0x00);
            if (serialPortManager.SendDataToMCU(CommandWord.REQ_PWV_START, SendData, APPSettingUtil.ShortWaitTime) == false)
            {
                Timer_ACKTimeout.Enabled = false;
                measureViewModel.Tips = "温馨提示：PWV【开始测量】命令发送失败，请检查设备通信状况!";
                return;
            }
            Thread.Sleep(100);
            bPulseMrsStart = false;
            PwvMrsFinishFlag = "No";
            PulseMrsFinishFlag = "No";
            measureViewModel.Tips = "温馨提示：PWV测量开始,正在筛选脉搏波形... ...";
            //3秒容错处理
            enumPwvMrsResp = PWVMrsResp.PwvStart;
        }
        //脉搏波测量停止
        private void PWVStop_Function()
        {
           SendDataBytes.Clear();
            SendDataBytes.Add(0x00);
            SendDataBytes.Add(0x05);
            if (serialPortManager.SendDataToMCU(CommandWord.REQ_PWV_STOP, null, APPSettingUtil.ShortWaitTime) == false) 
            {
                Timer_ACKTimeout.Enabled = false;
                measureViewModel.Tips = "温馨提示：【停止采集】命令发送失败，请检查设备通信状况！";
            }
            PwvMrsFinishFlag = "No";
            PulseMrsFinishFlag = "No";
        }
        ////PWV测试异常结束时，所有测试停止
        private void AlltestStopWhenPWVfail()
        {
            PWV_Fail_num = PWV_Fail_num + 1;
            //恢复到初始状态
            Timer_ACKTimeout.Enabled = true;
            Thread.Sleep(1000);
            //指令发送失败
            BpModleIndex = 0x05;
            //'''''''''''''''''''''''打开阀门
            SendDataBytes.Clear();
            SendDataBytes.Add(0x02);
            SendDataBytes.Add(BpModleIndex);
           serialPortManager.SendDataToMCU(CommandWord.REQ_BP_CONTROL, SendDataBytes, APPSettingUtil.ShortWaitTime);
            //bPressMrsStart = true;
            bPressMrsAIStart = true;
        }
        ////当血压测量完成时，开始测量设置绘图控件的布局
        private void SetPWVDisplay()
        {
            if (TestMode.ECGPCG_Select)//勾选了心电心音测量
            {
                Dispatcher.BeginInvoke(new Action(() =>
                {
                    //Grid.SetRow(ECGPCG, 0);
                    //Grid.SetRow(LeftPWV, 2);
                    //Grid.SetRow(RightPWV, 4);
                    //Grid.SetRowSpan(ECGPCG, 2);
                   // Grid.SetRowSpan(LeftPWV, 2);
                    //Grid.SetRowSpan(RightPWV, 2);
                    //ECGPCG.Visibility = Visibility.Visible;
                    //LeftPWV.Visibility = Visibility.Visible;
                    //RightPWV.Visibility = Visibility.Visible;
                    measureViewModel.ECGPCG_Img = "pack://application:,,,/Resources/Image/Measure/心电心音.jpg";
                    measureViewModel.LeftPWV_Img = "pack://application:,,,/Resources/Image/Measure/左侧pwvep.jpg";
                    measureViewModel.RightPWV_Img = "pack://application:,,,/Resources/Image/Measure/右侧pwvep.jpg";
                }));
            }
           else
            {
                Dispatcher.BeginInvoke(new Action(() =>
                {
                    //Grid.SetRow(LeftPWV, 0);
                    //Grid.SetRow(RightPWV, 3);
                    //Grid.SetRowSpan(LeftPWV, 3);
                    //Grid.SetRowSpan(RightPWV, 3);
                    //LeftPWV.Visibility = Visibility.Visible;
                    //RightPWV.Visibility = Visibility.Visible;
                    //ECGPCG.Visibility = Visibility.Hidden;
                    measureViewModel.LeftPWV_Img = "pack://application:,,,/Resources/Image/Measure/左侧pwv.jpg";
                    measureViewModel.RightPWV_Img = "pack://application:,,,/Resources/Image/Measure/右侧pwv.jpg";
                }));
            }
        }
        #endregion
        #region 处理串口数据事件
        /// <summary>
        /// 处理接收的数据
        /// </summary>
        /// <param name="code"></param>
        /// <param name="cmd"></param>
        /// <param name="dataList"></param>
        private void ReciveAlarm(MCErrorCode code,List<ReceiveDataStructure> dataList)
        {
            if (code==MCErrorCode.NoError && dataList != null)
            {
                //不同类型的帧分开存储
                List<ReceiveDataStructure> dataValueAndTypePulse = new List<ReceiveDataStructure>();//脉搏波数据
                for (int i = 0; i < dataList.Count; i++)
                {
                    if (dataList[i].frameType == CommandWord.REQ_PWV_START_Back)
                    {
                        //是四肢脉搏波
                        if (dataList[i].dataValue == 0)
                        {
                            for (int p = 0; p < 7; p++)
                            {
                                iCpData[0] = dataList[i + 2 + p * 4].dataValue;//左臂
                                //iFpData[0] = dataList[i + 3 + p * 4].dataValue;//左踝
                                //iCpData[1] = dataList[i + 4 + p * 4].dataValue;
                                //iFpData[1] = dataList[i + 5 + p * 4].dataValue;
                                DataCountNum++;
                                if (DataCountNum % 20 == 0)
                                {
                                    if (TestMode.LBBP_Select)
                                    {
                                        ObservablePoint item2 = new ObservablePoint();
                                        item2.X = DataCountNum;
                                        item2.Y = dataList[i + 2 + p * 4].dataValue;
                                        LeftBraData.Add(item2);
                                    }
                                    //if (TestMode.LABP_Select)
                                    //{

                                    //    ObservablePoint item3 = new ObservablePoint();
                                    //    item3.X = DataCountNum;
                                    //    item3.Y = dataList[i + 3 + p * 4].dataValue;
                                    //    LeftAnkData.Add(item3);
                                    //}
                                    //if (TestMode.RBBP_Select)
                                    //{ObservablePoint item4= new ObservablePoint();
                                    //    item4.X = DataCountNum;
                                    //    item4.Y = dataList[i + 4 + p * 4].dataValue;
                                    //    RightBraData.Add(item4);
                                    //}
                                    //if (TestMode.RABP_Select)
                                    //{
                                    //    ObservablePoint item5 = new ObservablePoint();
                                    //    item5.X = DataCountNum;
                                    //    item5.Y = dataList[i + 5 + p * 4].dataValue;
                                    //    RightAnkData.Add(item5);
                                    //}
                                }
                                if ((RCpRawDataNum < 12 * Variable.Sample_Rate) || (RFpRawDataNum < 12 * Variable.Sample_Rate))
                                {
                                    if (HandlePulseData(ref DataCountNum, ref iCpData[0], ref iFpData[0], ref iCpData[1], ref iFpData[1]) == false)
                                    {
                                        measureViewModel.Tips = strTip;
                                        //AlltestStopWhenPWVfail();
                                        //if (TestMode.ECGPCG_Select)
                                        //{
                                        //    //ECGPCGStop_Function();
                                        //}
                                        Thread.Sleep(200);
                                    }
                                }
                                if (DataCountNum >= 6000)
                                {
                                    DataCountNum = 0;
                                    LeftBraData.Clear();
                                    //LeftAnkData.Clear(); 
                                    //RightBraData.Clear();
                                    //RightAnkData.Clear();
                                    ECGData.Clear();
                                    PCGData.Clear();
                                    HKDataCountNum = 0;
                                }
                            }
                            i = i + 29;
                            //Growl.Info("ProgressBarStartFlag：" + ProgressBarStartFlag);
                            if (ProgressBarStartFlag)
                            {
                                Dispatcher.BeginInvoke(new Action(() =>
                                {
                                    measureViewModel.TestStatus = ProgressBarValue.ToString();  //后续替换为hc的进度条
                                }));
                            }
                        }
                        else if (dataList[i].dataValue == 1)   //桡动脉波形图
                        {
                            for (int p = 0; p < 14; p++)
                            {
                                iData[0] = dataList[i + 2 + p].dataValue;
                                DataCount++;
                                ObservablePoint item2 = new ObservablePoint();
                                item2.X = DataCount;
                                item2.Y = iData[0] - 1000;
                                AIData.Add(item2);
                                HandleAIPulseData(ref DataCount, ref iData[0]);
                                if (DataCount >= 6000)
                                {
                                    Dispatcher.BeginInvoke(new Action(() =>
                                    {
                                        DataCount = 0;
                                        AIData.Clear();
                                    }));
                                }
                            }
                            i = i + 15;
                        }
                    }
                    else if (dataList[i].frameType == CommandWord.REQ_PWV_INC_GAIN_Back)
                    {
                        i += 2;
                    }
                    else if (dataList[i].frameType == CommandWord.REQ_PWV_DEC_GAIN_Back)
                    {
                        i = i + 2;
                    }
                    else if (dataList[i].frameType == CommandWord.REQ_BP_INIT_SET_Back)
                    {
                        if (dataList[i + 1].dataValue == 0x4B && dataList[i + 2].dataValue == 0x73)//"K"响应
                        {
                            switch (dataList[i + 3].dataValue)
                            {
                                case 1:
                                    if (BP_ACK_Flag[0] == -9)
                                    {
                                        BpInflateRun[0] = 3;
                                    }
                                    else
                                        FourBpInflateFinish[0] = 0x01;
                                    break;
                                case 2:
                                    if (BP_ACK_Flag[1] == -9)
                                    {
                                        BpInflateRun[1] = 3;
                                    }
                                    else
                                        FourBpInflateFinish[1] = 0x02;
                                    break;
                                case 3:
                                    if (BP_ACK_Flag[2] == -9)
                                        BpInflateRun[2] = 3;
                                    else
                                        FourBpInflateFinish[2] = 0x03;
                                    break;
                                case 4:
                                    if (BP_ACK_Flag[3] == -9)
                                        BpInflateRun[3] = 3;
                                    else
                                        FourBpInflateFinish[3] = 0x04;
                                    break;
                            }
                            //左右上肢设定预期压力完成(判断只有下肢收到了命令，与发送pwv前的设置压力区分开）
                            if (FourBpInflateFinish[0] == 0x01 && FourBpInflateFinish[2] == 0x03 && FourBpInflateFinish[1] == 0 && FourBpInflateFinish[3] == 0 && Variable.Test_ABI_num == 0)
                            {
                                FourBpInflateFinish[0] = 0;
                                FourBpInflateFinish[2] = 0;
                                BPinflateBeforeBPStart(BPInflateValue[1], 0x09);//发送下肢设定预期压力命令
                            }//收到下肢设定预期压力完成k响应后，发送测量血压命令(同上）
                            if (FourBpInflateFinish[1] == 0x02 && FourBpInflateFinish[3] == 0x04 && FourBpInflateFinish[0] == 0 && FourBpInflateFinish[2] == 0 && Variable.Test_ABI_num == 0)
                            {
                                //判断以后直接置0

                                FourBpInflateFinish[1] = 0;
                                FourBpInflateFinish[3] = 0;
                                TestMode.ModelChange = 2;
                                if (TestMode.ModelChange == 2)
                                {
                                    if (CommandWordSend == 0x00)// || CommandWordSend == 0x06 || CommandWordSend == 0x0E || CommandWordSend == 0x0D || CommandWordSend == 0x0C || CommandWordSend == 0x0B)//测量四肢/左侧/左踝不测/右臂不测/有踝不测/左臂右踝
                                    {
                                        TestMode.CommandWordSend = 0x01;
                                        Dispatcher.BeginInvoke(new Action(() =>
                                        {
                                            measureViewModel.Tips = "温馨提示：血压测量开始！";
                                        }));
                                    }
                                    //else if (CommandWordSend == 0x07)
                                    //{
                                    //    TestMode.CommandWordSend = 0x03;
                                    //    Dispatcher.BeginInvoke(new Action(() =>
                                    //    {
                                    //        measureViewModel.Tips = "温馨提示：右臂血压测量开始！";
                                    //    }));
                                    //}
                                    //else if (CommandWordSend == 0x0F || CommandWordSend == 0x0A)//左臂不测
                                    //{
                                    //    TestMode.CommandWordSend = 0x02;
                                    //    Dispatcher.BeginInvoke(new Action(() =>
                                    //    {
                                    //        measureViewModel.Tips = "温馨提示：左踝血压测量开始！";
                                    //    }));
                                    //}
                                    CuffAssignment(TestMode.CommandWordSend);
                                    BpTest_Function(TestMode.CommandWordSend);
                                }
                            }
                            //pwv测量时使用
                            if (FourBpInflateFinish[0] == 0x01 && FourBpInflateFinish[1] == 0x02 && FourBpInflateFinish[2] == 0x03 && FourBpInflateFinish[3] == 0x04 && Variable.Test_ABI_num == 1)
                            {
                                Thread.Sleep(3000);//三秒钟后开始儿童血压的测量
                                for (int j = 0; j < 4; j++)
                                {
                                    FourBpInflateFinish[j] = 0;
                                }
                                //发送儿童血压测量命令
                                ConcatenatedData(CommandWordSend);
                                serialPortManager.SendDataToMCU(CommandWord.REQ_BP_OBJECT_SET, SendDataBytes, APPSettingUtil.ShortWaitTime);
                                strDebug = "各袖带压力值设定完成！";
                                Thread.Sleep(500);
                                //启动四个检测计时器,如果四十秒钟还没正确关闭阀门直接启动进入容错环节
                                InintTimer();
                                Dispatcher.BeginInvoke(new Action(() =>
                                {
                                    measureViewModel.Tips = "温馨提示：" + strDebug;
                                }));
                            }
                        }
                        i = i + 3;
                    }
                    else if (dataList[i].frameType == CommandWord.REQ_BP_OBJECT_SET_Back)
                    {
                        if (dataList[i + 1].dataValue == 0x4F && dataList[i + 2].dataValue == 0x6F)//"O"响应
                        {
                            switch (dataList[3 + i].dataValue)
                            {
                                case 1:
                                    //收到儿童血压，将状态值复制为0开始读取袖带压力
                                    if (BP_ACK_Flag[0] == -12)
                                    {
                                        BP_ACK_Flag[0] = 0;
                                        BpInflateRun[0] = 0;
                                    }
                                    else
                                        FourBpStartPwv[0] = 0x01;
                                    break;
                                case 2:
                                    if (BP_ACK_Flag[1] == -12)
                                    {
                                        BP_ACK_Flag[1] = 0;
                                        BpInflateRun[1] = 0;
                                    }
                                    else
                                        FourBpStartPwv[1] = 0x02;
                                    break;
                                case 3:
                                    if (BP_ACK_Flag[2] == -12)
                                    {
                                        BP_ACK_Flag[2] = 0;
                                        BpInflateRun[2] = 0;
                                    }
                                    else
                                        FourBpStartPwv[2] = 0x03;
                                    break;
                                case 4:
                                    if (BP_ACK_Flag[3] == -12)
                                    {
                                        BP_ACK_Flag[3] = 0;
                                        BpInflateRun[3] = 0;
                                    }
                                    else
                                        FourBpStartPwv[3] = 0x04;
                                    break;
                            }
                            //Growl.Info(FourBpStartPwv[0].ToString() + FourBpStartPwv[1].ToString() + FourBpStartPwv[2].ToString() + FourBpStartPwv[3].ToString());
                            if (FourBpStartPwv[0] == 0x01)//(//) && FourBpStartPwv[1] == 0x02 && FourBpStartPwv[2] == 0x03 && FourBpStartPwv[3] == 0x04)
                            {
                                for (int j = 0; j < 4; j++)
                                {
                                    FourBpStartPwv[j] = 0;
                                }
                                strTip = "温馨提示：血压发送成功";
                                measureViewModel.Tips = strTip;
                                if (Variable.Test_ABI_num > 0)//判断是否进行过abi测量 
                                {
                                    Dispatcher.BeginInvoke(new Action(() =>
                                    {
                                        timerRealLeftBra.Start();
                                    }));
                                }
                            }
                        }
                        else if (dataList[i + 1].dataValue == 0x42 && dataList[i + 2].dataValue == 0x7C)
                        {
                            switch (dataList[3 + i].dataValue)
                            {
                                case 1:
                                    strTip = "左上臂袖带忙";
                                    Bt_Pressureindex = 0x01;
                                    break;
                                case 2:
                                    strTip = "左脚踝袖带忙";
                                    Bt_Pressureindex = 0x02;
                                    break;
                                case 3:
                                    strTip = "右上臂袖带忙";
                                    Bt_Pressureindex = 0x03;
                                    break;
                                case 4:
                                    strTip = "右脚踝袖带忙";
                                    Bt_Pressureindex = 0x04;
                                    break;
                            }//只要提示忙则立马发送四肢停止测量命令，重新发送儿童血压测量命令,出现袖带忙的情况一般比较少见，
                            measureViewModel.Tips = strTip;
                            ConcatenatedData(0x00);
                            if (serialPortManager.SendDataToMCU(CommandWord.REQ_BP_STOP, SendDataBytes, APPSettingUtil.ShortWaitTime))//停止血压测量
                            {

                            }
                            Dispatcher.BeginInvoke(new Action(() =>
                            {
                                TimerCValueACK.Stop();//超时判断计时器关闭
                            }));
                            Thread.Sleep(2000);//停止完血压测量后，休息2000ms后重新开始充气测量
                            CuffAssignment(CommandWordSend);
                            PWVStartWhenBPStop();
                            for (int k = 0; k < 4; k++)
                            {
                                BpInflateRun[k] = 0;
                            }
                            measureViewModel.Tips = "PWV测量开始";
                        }
                        else if (dataList[i + 1].dataValue == 0x4B && dataList[i + 2].dataValue == 0x73)
                        {
                            switch (dataList[3 + i].dataValue)
                            {
                                case 1:
                                    strTip = "左上臂袖带测量完成";
                                    break;
                                case 2:
                                    strTip = "左脚踝袖带开始测量";
                                    break;
                                case 3:
                                    strTip = "右上臂袖带开始测量";
                                    break;
                                case 4:
                                    strTip = "右脚踝袖带开始测量";
                                    break;
                            }
                            measureViewModel.Tips = strTip;
                        }
                        i = i + 3;
                    }
                    else if (dataList[i].frameType == CommandWord.REQ_BP_START_Back)
                    {
                        if ((dataList[i + 1].dataValue == 0x4F) && (dataList[i + 2].dataValue == 0x6F))////收到响应指令“O”
                        {
                            //根DataReceive中我们切割的数组有关，一般至少要切割三位，要有四肢选择的情况，
                            switch (dataList[i + 3].dataValue)
                            {
                                case 1:
                                    strTip = "左上臂血压测量开始";
                                    break;
                            }
                        }
                        else if ((dataList[i + 1].dataValue == 0x42) && (dataList[i + 2].dataValue == 0x7C))////收到响应指令“B”
                        {
                            switch (dataList[i + 3].dataValue)
                            {
                                case 1:
                                    strTip = "左上臂血压模块忙";
                                    break;
                            }
                            measureViewModel.Tips = "温馨提示：" + strTip;
                        }
                        else if ((dataList[i + 1].dataValue == 0x4B) && (dataList[i + 2].dataValue == 0x73))////收到响应指令“K”（指令执行完成）
                        {
                            switch (dataList[i + 3].dataValue)
                            {
                                case 1:
                                    FourBPFinish[0] = 0x01;
                                    strTip = "温馨提示：血压数据测量完成";
                                    break;
                            }
                            if (FourBPFinish[0] == 0x01)
                            {
                                for (int j = 0; j < 1; j++)
                                {
                                    FourBPFinish[j] = 0;
                                }
                                ConcatenatedData(TestMode.CommandWordSend);
                                if (serialPortManager.SendDataToMCU(CommandWord.REQ_BP_GET_RESULT, SendDataBytes, APPSettingUtil.ShortWaitTime))
                                    strTip = "温馨提示：正在读取血压测量结果....";
                            }
                            measureViewModel.Tips = strTip;
                        }
                        i += 3;
                    }
                    else if (dataList[i].frameType == CommandWord.REQ_BP_STOP_Back)
                    {
                        if ((dataList[1 + i].dataValue == 0x41) && (dataList[2 + i].dataValue == 0x7D))////收到响应指令“A”
                        {
                            //判断是否是关闭阀门出错时的流程
                            switch (dataList[3 + i].dataValue)
                            {
                                case 1:
                                    if (BP_ACK_Flag[0] == -11)
                                    {
                                        BP_ACK_Flag[0] = 0;
                                        FourBPEnd[0] = 0x01;
                                        strTip = "温馨提示：左上臂血压测量正在停止";
                                        BpInflateRun[0] = 2;
                                    }
                                    else
                                    {
                                        FourBPEnd[0] = 0x01;
                                        strTip = "温馨提示：左脚踝血压测量已停止";
                                        BpInflateRun[0] = 5;
                                    }
                                    break;
                                case 2:
                                    if (BP_ACK_Flag[1] == -11)
                                    {
                                        BP_ACK_Flag[1] = 0;
                                        FourBPEnd[1] = 0x02;
                                        strTip = "温馨提示：左脚踝血压测量正在停止";
                                        BpInflateRun[1] = 2;
                                    }
                                    else
                                    {
                                        FourBPEnd[1] = 0x02;
                                        strTip = "温馨提示：左脚踝血压测量已停止";
                                        BpInflateRun[1] = 5;
                                    }
                                    break;
                                case 3:
                                    if (BP_ACK_Flag[2] == -11)
                                    {
                                        BP_ACK_Flag[2] = 0;
                                        FourBPEnd[2] = 0x03;
                                        strTip = "温馨提示：右上臂血压测量正在停止";
                                        BpInflateRun[2] = 2;
                                    }
                                    else
                                    {
                                        FourBPEnd[2] = 0x03;
                                        strTip = "温馨提示：右上臂血压测量已停止";
                                        BpInflateRun[2] = 5;
                                    }
                                    break;
                                case 4:
                                    if (BP_ACK_Flag[3] == -11)
                                    {
                                        BP_ACK_Flag[3] = 0;
                                        FourBPEnd[3] = 0x04;
                                        strTip = "温馨提示：右脚踝血压测量正在停止";
                                        BpInflateRun[3] = 2;
                                    }
                                    else
                                    {
                                        FourBPEnd[3] = 0x04;
                                        strTip = "温馨提示：右脚踝血压测量已停止";
                                        BpInflateRun[3] = 5;
                                    }
                                    break;
                            }
                        }
                        //判断bpx是那一位数据，返回对应的测量结果
                        else if ((dataList[1 + i].dataValue == 0x4B) && (dataList[2 + i].dataValue == 0x73))////收到响应指令“K”
                        {
                            switch (dataList[3 + i].dataValue)
                            {
                                case 1:
                                    FourBPStop[0] = 0x01;
                                    strTip = "左上臂血压测量停止";
                                    break;
                                case 2:
                                    FourBPStop[1] = 0x02;
                                    strTip = "左脚踝血压测量停止";
                                    break;
                                case 3:
                                    FourBPStop[2] = 0x03;
                                    strTip = "右上臂血压测量停止";
                                    break;
                                case 4:
                                    FourBPStop[3] = 0x04;
                                    strTip = "右脚踝血压测量停止";
                                    break;
                            }
                            Growl.Info("温馨提示：" + strTip);
                            strTip = "";
                        }
                        i += 3;
                    }
                    else if (dataList[i].frameType == CommandWord.REQ_BP_GET_RESULT_Back)
                    {
                        switch (dataList[11 + i].dataValue)
                        {
                            case 1:
                                //左臂
                                get_bp_hr = dataList[5 + i].dataValue;
                                GetBPnum = GetBPnum + 1;
                                get_bp.LtBraBp_Sbp = dataList[1 + i].dataValue;
                                get_bp.LtBraBp_Dbp = dataList[2 + i].dataValue;
                                get_bp.LtBraBp_Map = dataList[6 + i].dataValue;
                                FourPressGreater[0] = 0x01;
                                break;
                                
                        }
                        //当四肢全采到血压值后进入，对血压值进行处理
                        string fault = "";
                        if (GetBPnum >= 1)
                        {
                            GetBPnum = 0;
                            if (FourPressGreater[0] == 0x01) //&& FourPressGreater[1] == 0x02 && FourPressGreater[2] == 0x03 && FourPressGreater[3] == 0x04)
                            {
                                for (int j = 0; j < 1; j++)
                                {
                                    FourPressGreater[j] = 0;
                                }
                                //四路血压全部有值的时候在读取处理,处理获取的四肢血压结果
                                Dispatcher.BeginInvoke(new Action(() =>
                                {
                                    measureViewModel.LBRealPre = "--";
                                }));
                                try
                                {
                                    if (get_bp.LtBraBp_Sbp == 0)
                                    {
                                        fault = GetBPResultFault(dataList[6].dataValue);
                                        Dispatcher.BeginInvoke(new Action(() =>
                                        {
                                            measureViewModel.Tips = fault;
                                        }));
                                        return;
                                    }
                                    HandleBPData(ref get_bp);//get_Bp为保存了下位机测得的血压信息
                                }
                                catch(Exception e)
                                {
                                    measureViewModel.Tips = e.Message;
                                }
                            }
                            else
                            {
                                strTip = "";
                                if (get_bp.LtBraBp_Sbp < 250)
                                    strTip = strTip + "左臂 ";
                                strTip = "温馨提示：" + strTip + "血压测量有误，请重新绑扎袖带！";
                                measureViewModel.Tips = strTip;
                                bPressMrsStart = false;   //测量按钮状态切换 lzx20241112
                                measureViewModel.MeasureBtn_Img = "pack://application:,,,/Resources/Image/Measure/开始测量.jpg";
                            }
                        }
                        i += 11;
                    }
                    else if (dataList[i].frameType == CommandWord.REQ_BP_PRESSURE_Back)
                    {

                        Real_press = dataList[i + 1].dataValue;
                        RealPressure = Real_press;
                        switch (dataList[3 + i].dataValue)
                        {
                            case 1:
                                BP_Test_Pressure[0] = Real_press;
                                //如果当前压力小于等于上一次测量到的压力值（表示还未到达峰值已经开始放气了或者没有对袖带进行充气）
                                if (Real_press < BPOldPressure[0])
                                {
                                    BpInflateRun[0] = 1;//进入异常第一
                                }
                                else
                                {
                                    BPOldPressure[0] = Real_press;
                                    BpInflateRun[0] = 0;
                                }
                                if (Real_press >= GlobalVariable.Pressure)
                                {
                                    //血压测量停止，关闭阀门
                                    BpInflateRun[0] = 4;//启动停止充气命令
                                }
                                a++;
                                Dispatcher.BeginInvoke(new Action(() =>
                                {
                                    measureViewModel.LBRealPre = Real_press.ToString();
                                }));
                                break;
                            case 2:
                                BP_Test_Pressure[1] = Real_press;
                                //如果当前压力小于上一次测量到的压力值（表示还未到达峰值已经开始放气了）
                                if (Real_press < BPOldPressure[1])
                                {
                                    BpInflateRun[1] = 1;//进入异常第一步
                                }
                                else
                                {
                                    BPOldPressure[1] = Real_press;
                                    BpInflateRun[1] = 0;
                                }
                                if (Real_press >= GlobalVariable.Pressure)
                                {
                                    //血压测量停止，关闭阀门
                                    BpInflateRun[1] = 4;//启动停止充气命令
                                }
                                Dispatcher.BeginInvoke(new Action(() =>
                                {
                                    measureViewModel.LARealPre = Real_press.ToString();
                                }));
                                break;
                            //右侧
                            case 3:
                                BP_Test_Pressure[2] = Real_press;
                                //如果当前压力小于上一次测量到的压力值（表示还未到达峰值已经开始放气了）
                                if (Real_press < BPOldPressure[2])
                                {
                                    BpInflateRun[2] = 1;//进入异常第一步
                                }
                                else
                                {
                                    BPOldPressure[2] = Real_press;
                                    BpInflateRun[2] = 0;
                                }
                                if (Real_press >= GlobalVariable.Pressure)
                                {
                                    BpInflateRun[2] = 4;//启动停止充气命令
                                }
                                b++;
                                Dispatcher.BeginInvoke(new Action(() =>
                                {
                                    measureViewModel.RBRealPre = Real_press.ToString();
                                }));
                                break;
                            case 4:
                                BP_Test_Pressure[3] = Real_press;
                                //如果当前压力小于上一次测量到的压力值（表示还未到达峰值已经开始放气了）
                                if (Real_press < BPOldPressure[3])
                                {
                                    BpInflateRun[3] = 1;//进入异常第一步 
                                }
                                else
                                {
                                    BPOldPressure[3] = Real_press;
                                    BpInflateRun[3] = 0;
                                }
                                if (Real_press >= GlobalVariable.Pressure)
                                {
                                    //血压测量停止，关闭阀门
                                    BpInflateRun[3] = 4;//启动停止充气命令
                                }
                                Dispatcher.BeginInvoke(new Action(() =>
                                {
                                    measureViewModel.RARealPre = Real_press.ToString();
                                }));
                                break;
                        }
                        i += 3;
                    }
                    else if (dataList[i].frameType == CommandWord.REQ_BP_CONTROL_Back)
                    {
                        if (dataList[1 + i].dataValue == 0x4B && dataList[2 + i].dataValue == 0x73)//响应“O”"K"
                        {
                            //如果相等，则表示是pwv过程还未测试完成时，发送的打开阀门按钮，那么此时发送停止采集pwv
                            if (enumPwvMrsResp == PWVMrsResp.PwvStart)
                            {
                                SendDataBytes.Clear();
                                SendDataBytes.Add(0x00);
                                SendDataBytes.Add(0x05);
                                serialPortManager.SendDataToMCU(CommandWord.REQ_PWV_STOP, null, APPSettingUtil.ShortWaitTime);
                            }
                            if (BP_ACK_Flag[0] == -2 && BP_ACK_Flag[1] == -2 && BP_ACK_Flag[2] == -2 && BP_ACK_Flag[3] == -2)
                            {
                                //for (int j = 0; j < 4; j++)
                                //{
                                //    BP_ACK_Flag[j] = 0;
                                //}
                                //PWVStopFist = true;
                                //WaitForAck = MrsWaitForAck.MrsPWV;
                                //Dispatcher.BeginInvoke(new Action(() => {
                                //    TimerProcessData.Enabled = true;
                                //    TimerProcessData.Interval = 1000;
                                //    Timer_ACKTimeout.Enabled = true;
                                //    measureViewModel.Tips = "波形采集完成，等待分析结果";
                                //    measureViewModel.TestStatus = "100";
                                //}));
                                //if (TestMode.ECGPCG_Select == true)
                                //    ECGPCGStop_Function();//心电心音停止测量
                                //PWVStop_Function();
                                //bPressMrsStart = true;
                            }
                            switch (dataList[3 + i].dataValue)
                            {
                                case 1:
                                    if (BP_ACK_Flag[0] == -3)
                                    {
                                        BP_ACK_Flag[0] = 0;
                                        FourBPClosevalve[0] = 0x01;
                                        ValueOpen_Flag[0] = 1;
                                        BpInflateRun[0] = 10;
                                        BpInflateRunFlag[0] = 1;
                                    }
                                    break;
                                case 2:
                                    if (BP_ACK_Flag[1] == -3)
                                    {
                                        BP_ACK_Flag[1] = 0;
                                        FourBPClosevalve[1] = 0x02;
                                        ValueOpen_Flag[1] = 1;
                                        BpInflateRun[1] = 10;
                                        BpInflateRunFlag[1] = 2;

                                    }
                                    break;
                                case 3:
                                    if (BP_ACK_Flag[2] == -3)
                                    {
                                        BP_ACK_Flag[2] = 0;
                                        FourBPClosevalve[2] = 0x03;
                                        ValueOpen_Flag[2] = 1;
                                        BpInflateRun[2] = 10;
                                        BpInflateRunFlag[2] = 3;
                                    }
                                    break;
                                case 4:
                                    if (BP_ACK_Flag[3] == -3)
                                    {
                                        BP_ACK_Flag[3] = 0;
                                        FourBPClosevalve[3] = 0x04;
                                        ValueOpen_Flag[3] = 1;
                                        BpInflateRun[3] = 10;
                                        BpInflateRunFlag[3] = 4;
                                    }
                                    break;
                            }
                            if (FourBPClosevalve[0] == 0x01)   // && FourBPClosevalve[1] == 0x02 && FourBPClosevalve[2] == 0x03 && FourBPClosevalve[3] == 0x04)
                            {
                                //四个肢体全是1，表示四肢都正常执行
                                if (BpInflateRunFlag[0] == 1)// && BpInflateRunFlag[1] == 2 && BpInflateRunFlag[2] == 3 && BpInflateRunFlag[3] == 4)
                                {
                                    //Dispatcher.Invoke(new Action(() =>
                                    //{
                                    //    timerRealLeftBra.Stop();
                                    //    TimerCValueACK.Stop();//停止检测
                                    //}));
                                    //for (int j = 0; j < 4; j++)
                                    //{
                                    //    FourBPClosevalve[j] = 0;
                                    //    BpInflateRun[j] = 0;
                                    //    BpInflateRunFlag[j] = 0;
                                    //}
                                    //if (TestMode.ECGPCG_Select)
                                    //{
                                    //    if (ECGPCGTest_Function() == false)
                                    //    {
                                    //        Growl.Info("心电模块启动异常！");
                                    //    }
                                    //}
                                    //SetPWVDisplay();
                                    ////PwvTest_Fucntion(); //'80mmhg
                                    //ProgressBarStartFlag = true;
                                    //measureViewModel.TestStatus = "0";
                                }
                            }
                        }
                        measureViewModel.Tips = strTip;
                        i += 3;
                    }
                    else if (dataList[i].frameType == CommandWord.REQ_BP_PRESS_CAL)
                    {
                        if ((dataList[1].dataValue == 79) && (dataList[2].dataValue == 111))////收到响应指令“O”
                        {
                            strTip = "温馨提示：正在进行校准....";
                        }
                        else if ((dataList[1].dataValue == 75) && (dataList[2].dataValue == 115))////收到响应指令“K”
                        {
                            strTip = "温馨提示：血压模块校准完成！";
                        }
                        measureViewModel.Tips = strTip;
                        i += 3;
                    }
                    else if (dataList[i].frameType == CommandWord.REQ_BP_READ_NO)
                    {
                        if ((dataList[1].dataValue == 79) && (dataList[2].dataValue == 111))////收到响应指令“O”
                        {
                            strTip = "温馨提示：正在进行校准....";
                        }
                        measureViewModel.Tips = strTip;
                        i += 5;
                    }
                    else if (dataList[i].frameType == CommandWord.REQ_PWV_STOP_Back)
                    {
                        if (PWVStopFist)
                        {
                            PWVStopFist = false;
                            if (PwvMrsFinishFlag == "Yes")
                            {
                                SendDataBytes.Clear();
                                SendDataBytes.Add(0x02);
                                SendDataBytes.Add(0x05);
                                if (serialPortManager.SendDataToMCU(CommandWord.REQ_BP_CONTROL, SendDataBytes, APPSettingUtil.ShortWaitTime)) //PWV测试完全正常结束，打开阀门放气，
                                {
                                    strTip = "温馨提示：脉搏波采集完成，正在分析......";
                                    if (TestMode.ECGPCG_Select)
                                    {
                                        Thread thread = new Thread(() =>
                                        {
                                            measureViewModel.IsRunning = "Visible";
                                        });
                                        thread.Start();
                                    }
                                }
                                for (int j = 0; j < 4; j++)
                                {
                                    BP_ACK_Flag[j] = -2;
                                }
                            }
                            if (PulseMrsFinishFlag == "Yes")
                            {
                                strTip = "温馨提示：心动脉脉搏数据采集完成，正在保存... ...";
                                //AI处理
                                PWVStopFist = true;
                                WaitForAck = MrsWaitForAck.MrsPulse;
                                measureViewModel.TestStatus = "100";
                                Dispatcher.BeginInvoke(new Action(() =>
                                {
                                    TimerProcessData.Start();
                                    TimerProcessData.Interval = 1000;
                                    measureViewModel.Tips = strTip;
                                }));
                                bPressMrsStart = true;
                                Thread.Sleep(200);
                            }
                        }
                    }
                    else if (dataList[i].frameType == CommandWord.REQ_PWV_INC_GAIN_Back)
                    {
                        Dispatcher.BeginInvoke(new Action(() =>
                        {
                            measureViewModel.Tips = "温馨提示：脉搏波增益成功";
                        }));
                    }
                    else if (dataList[i].frameType == CommandWord.REQ_PWV_DEC_GAIN_Back)
                    {
                        Dispatcher.BeginInvoke(new Action(() =>
                        {
                            measureViewModel.Tips = "温馨提示：脉搏波减益成功";
                        }));
                    }
                }
            }
            else if (code == MCErrorCode.OpenSerialFail)
            {
                HandyControl.Controls.Growl.Warning("打开串口失败！");
                Recover();
            }
            else if (code == MCErrorCode.TimeLimited)//超时
            {
                HandyControl.Controls.Growl.Warning("接收超时！");
                if (serialPortManager.SendTimes>=2)
                {
                    HandyControl.Controls.Growl.Warning("通讯故障！");
                    //Recover();
                }
            }
        }
        /// <summary>
        /// 处理接收的数据
        /// </summary>
        /// <param name="code"></param>
        /// <param name="cmd"></param>
        /// <param name="dataList"></param>
        private void EPReciveAlarm(MCErrorCode code, List<ReceiveDataStructure> ECGdataValueAndType)
        {
            if (code == MCErrorCode.NoError && ECGdataValueAndType != null)
            {
                //不同类型的帧分开存储
                List<ReceiveDataStructure> dataValueAndTypeXY = new List<ReceiveDataStructure>();
                for (int i = 0; i < ECGdataValueAndType.Count; i++)
                {
                    if (ECGdataValueAndType[i].dataType == cmdWord.Data_HKXinyin)
                    {
                        XYDataCountNum++;
                        if (HKDataCountNum % 20 == 0)
                        {
                            if (HKDataCountNum != LastCount)
                            {
                                LastCount = HKDataCountNum;
                                ObservablePoint item6 = new ObservablePoint();
                                item6.X = HKDataCountNum;
                                item6.Y = ECGdataValueAndType[i].dataValue;
                                PCGData.Add(item6);
                            }
                        }
                        dataValueAndTypeXY.Add(ECGdataValueAndType[i]);
                        XYDataCountNum = XYDataCountNum + 1;
                        if (isSampleOK && HKdataXY.Count < 12000) //开始采样心音 12s
                            HKdataXY.Add(ECGdataValueAndType[i].dataValue);
                    }
                    else if (ECGdataValueAndType[i].dataType == cmdWord.Data_HKECG)
                    {
                        //HKDataCountNum++;
                        //if (HKDataCountNum % 20 == 0) 
                        //{
                        //    ObservablePoint item7 = new ObservablePoint();
                        //    item7.X = HKDataCountNum;
                        //    item7.Y = ECGdataValueAndType[i].dataValue * 20 - 2000;//心电
                        //    ECGData.Add(item7);
                        //}
                        //if (isSampleOK && HKdataECG.Count < 2400) //开始采样心电  12s
                        //    HKdataECG.Add(ECGdataValueAndType[i].dataValue * 6 + 1000);
                        //if (HKDataCountNum >= 2400)
                        //{
                        //    XYDataCountNum = 0;
                        //    HKDataCountNum = 0;

                        //    ECGData.Clear();
                        //    PCGData.Clear();
                        //}
                    }
                    else if (ECGdataValueAndType[i].dataType == CommandWord.HKEndTest)
                    {
                    }
                    else if (ECGdataValueAndType[i].dataType == CommandWord.HKSet)
                    {
                        Growl.Info("信号放大倍数设置成功！");
                    }

                }
            }
            else if (code == MCErrorCode.OpenSerialFail)
            {
                HandyControl.Controls.Growl.Warning("打开串口失败！");
            }
            else if (code == MCErrorCode.TimeLimited)//超时
            {
                HandyControl.Controls.Growl.Warning("接收超时！");
                if (serialPortManager.SendTimes >= 2)
                {
                    HandyControl.Controls.Growl.Warning("通讯故障！");

                }
            }
        }
        //读取血压返回的故障码  01：从袖带获得脉搏波信号弱  02：从修改获得脉搏波信号不稳定   03：血压值超出测量范围   04：超过测量时限   55：气动堵塞
        //                    56：用户终止读取BP值       57：充气超时、漏气或袖带松动     58：安全超时            59：袖带过压       5a：电源超出范围或其他硬件问题
        //                    5b：如未授权的命令或超出范围的自动归零        61：传感器超出范围       62：EEPROM校准数据故障；
        private string GetBPResultFault(int ECFault)
        {
            string FaultStr = "";
            switch (ECFault)
            {
                case 0x01:
                    FaultStr = "从袖带获得脉搏波信号弱";
                    break;
                case 0x02:
                    FaultStr = "从修改获得脉搏波信号不稳定";
                    break;
                case 0x03:
                    FaultStr = "血压值超出测量范围";
                    break;
                case 0x04:
                    FaultStr = "超过测量时限";
                    break;
                case 0x55:
                    FaultStr = "气动堵塞";
                    break;
                case 0x56:
                    FaultStr = "用户终止读取BP值";
                    break;
                case 0x57:
                    FaultStr = "充气超时、漏气或袖带松动";
                    break;
                case 0x58:
                    FaultStr = "安全超时";
                    break;
                case 0x59:
                    FaultStr = "袖带过压";
                    break;
                case 0x5a:
                    FaultStr = "电源超出范围或其他硬件问题";
                    break;
                case 0x5b:
                    FaultStr = "如未授权的命令或超出范围的自动归零";
                    break;
                case 0x61:
                    FaultStr = "传感器超出范围";
                    break;
                case 0x62:
                    FaultStr = "EEPROM校准数据故障";
                    break;
            }
            bPressMrsStart = true;   //测量按钮状态切换 lzx20241112
            measureViewModel.MeasureBtn_Img = "pack://application:,,,/Resources/Image/Measure/开始测量.jpg";
            return "血压结果读取失败，" + FaultStr;
            
        }
        /// <summary>
        /// 拼接发送指令
        /// </summary>
        /// <param name="bpx">肢体的编号</param>
        private void ConcatenatedData(byte bpx)
        {
            SendDataBytes.Clear();
            SendDataBytes.Add(0x00);
            SendDataBytes.Add(bpx);
        }
        private void msg(string m)
        {
        }
        private void PlayVideo(string url)
        {
            Thread thread = new Thread(() =>
            {
                PlayVideoUtil.Play(url);
            });
            thread.Start();
        }
        #endregion

        #region 点击事件
        /// <summary>
        /// 点击返回按钮
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BackBtn(object sender, RoutedEventArgs e)
        {
            //ECGPCGTest_Function();
            //measureViewModel.IsRunning = "Visible";
            if (measureViewModel.IsRunning == "Visible")
            {
                Growl.Info("温馨提示：正在分析数据，请稍等！");
                return;
            }
            //PWVStop_Function();//停止采集脉搏波信号
            //if (TestMode.ECGPCG_Select)
                //ECGPCGStop_Function();
            //当前还有任务在执行
            //if (workStatus == WorkStatus.NoWork)
            //{
            //    this.NavigationService.GoBack();
            //}
            //else
            //{
            //    Growl.Info("正在测试，请先结束测量！");
            //}

            //d = Dialog.Show(new EPDialog(tabAction, "心电心音检测", "           请佩戴好心电心音模块检测器，点击确认后开始心电心音和脉搏波测量."));
            //if (isEP == "确定")
            //{
            //    ConutDownThirtySec = 10;//数据保存完成，每一秒执行一次，CountDownThirtySec递减，十秒完成当十秒读完以后开始执行函数进行脉搏波测量
            //    Timer_ABIDelay.Start();
            //    Variable.Test_ABI_num = 1;
            //}
        }
        #endregion

        #region 处理数据流
        /// <summary>
        /// 不同测量状态的处理
        /// </summary>

        //处理检测到的脉搏波数据(实时处理颈动脉和股动脉脉搏数据,在接收数据处理时被一直被调用)
        private bool HandlePulseData(ref long iPos, ref int iCpData0, ref int iFpData0, ref int iCpData1, ref int iFpData1)
        {
            nCounter = nCounter + 1;
            if (nCpMarkSelect[0] >= 3 && nFpMarkSelect[0] >= 3)
            {
                if (CommandWordSend != 0x07)//只要选的不是右侧
                    strTip = "温馨提示：正在采集左侧脉搏波信号，请保持身体稳定！";
            }
            //采样频率降低至一半(保存偶数点的数据)，降低运算时间
            if (iPos % 2 == 0)//0 2 4 6 8 10 12 14 16 18 20  22 24
            {
                LCpDataOneSec.Add((double)iCpData0);
                LCpDataTwoSec.Add((double)iCpData0);
                RCpDataOneSec.Add((double)iCpData1);
                RCpDataTwoSec.Add((double)iCpData1);

                LFpDataOneSec.Add((double)iFpData0);
                LFpDataTwoSec.Add((double)iFpData0);
                RFpDataOneSec.Add((double)iFpData1);
                RFpDataTwoSec.Add((double)iFpData1);
                CountOneSec = CountOneSec + 1;
                CountTwoSec = CountTwoSec + 1;
            }
            //新的采集波形程序，确保所有波形时间是同轴的  
            if ((nCpMarkSelect[0] >= 3) && (nCpMarkSelect[1] >= 3) && (nFpMarkSelect[0] >= 3) && (nFpMarkSelect[1] >= 3))
                isSampleOK = true;
            else
                isSampleOK = false;
            if (isSampleOK)
            {
                //开始记录左侧波形，到9结束，共12秒
                if (CpRawDataNum[0] < 12 * Variable.Sample_Rate && FpRawDataNum[0] < 12 * Variable.Sample_Rate)//正式记录左侧波形
                {
                    if (TestMode.LBBP_Select == true)
                    {
                        LCpRawData.Add((double)iCpData0);
                        CpRawDataNum[0] = CpRawDataNum[0] + 1;
                    }
                    if (TestMode.LABP_Select == true)
                    {
                        LFpRawData.Add((double)iFpData0);
                        FpRawDataNum[0] = FpRawDataNum[0] + 1;
                    }
                    isSampleStop[0] = false;
                }
                else
                    isSampleStop[0] = true;
                //开始记录右侧波形，到9结束，共12秒
                if (CpRawDataNum[1] < 12 * Variable.Sample_Rate && FpRawDataNum[1] < 12 * Variable.Sample_Rate)//正式记录右侧波形
                {
                    if (TestMode.RBBP_Select == true)
                    {
                        RCpRawData.Add((double)iCpData1);
                        CpRawDataNum[1] = CpRawDataNum[1] + 1;
                    }
                    if (TestMode.RABP_Select == true)
                    {
                        RFpRawData.Add((double)iFpData1);
                        FpRawDataNum[1] = FpRawDataNum[1] + 1;
                    }
                    isSampleStop[1] = false;
                }
                isSampleStop[1] = true;
            }
            double MaxValue;
            double MinValue;
            double DifValue;
            AcquireData clsAcquisition;
            //只要有一个袖带的nCpMarkSelect大于3，就证明已经开始采集了，就不让进入增益减益函数  
            if ((!(nCpMarkSelect[0] > 3 || nCpMarkSelect[1] > 3 || nFpMarkSelect[1] > 3 || nFpMarkSelect[0] > 3)) && CountOneSec == 500)
            {
                //-----------左上肢动脉放大倍数
                MaxValue = LCpDataOneSec.Max();
                MinValue = LCpDataOneSec.Min();
                DifValue = MaxValue - MinValue;
                if ((MinValue <= 100 && DifValue <= 1000) || (MinValue > 100 && DifValue <= 1100))
                {
                    // '放大倍数加1
                    BpModleIndex = 0x0;
                    SendDataBytes.Clear();
                    SendDataBytes.Add(0x0);
                    SendDataBytes.Add(BpModleIndex);
                    if (serialPortManager.SendDataToMCU(CommandWord.REQ_PWV_INC_GAIN, SendDataBytes, APPSettingUtil.ShortWaitTime) == false)
                    {
                        if (CommandWordSend == 0x00 || CommandWordSend == 0x06 || CommandWordSend == 0x0B || CommandWordSend == 0x0C || CommandWordSend == 0x0D || CommandWordSend == 0x0E)
                            strTip = "温馨提示：左上肢动脉波形幅度增加命令发送失败，请检查设备通信状况！";
                         
                        //AlltestStopWhenPWVfail();
                        return false;
                    }
                    else
                    {
                        if (CommandWordSend == 0x00 || CommandWordSend == 0x06 || CommandWordSend == 0x0B || CommandWordSend == 0x0C || CommandWordSend == 0x0D || CommandWordSend == 0x0E)
                            strTip = "温馨提示：左上肢动脉波形幅度增加命令发送成功。";
                    }
                    Dispatcher.BeginInvoke(new Action(() =>
                    {
                        measureViewModel.Tips = strTip;
                    }));
                }
                if (MaxValue >= 3900 && DifValue > 3700)
                {
                    // '放大倍数减1
                    BpModleIndex = 0x0;
                    SendDataBytes.Clear();
                    SendDataBytes.Add(0x0);
                    SendDataBytes.Add(BpModleIndex);
                    if (serialPortManager.SendDataToMCU(CommandWord.REQ_PWV_DEC_GAIN, SendDataBytes, APPSettingUtil.ShortWaitTime) == false)
                    {
                        if (CommandWordSend == 0x00 || CommandWordSend == 0x06 || CommandWordSend == 0x0B || CommandWordSend == 0x0C || CommandWordSend == 0x0D || CommandWordSend == 0x0E)
                            strTip = "温馨提示：左上肢动脉波形幅度减小命令发送失败，请检查设备通信状况！";
                        //AlltestStopWhenPWVfail();
                        return false;
                    }
                    else
                    {
                        if (CommandWordSend == 0x00 || CommandWordSend == 0x06 || CommandWordSend == 0x0B || CommandWordSend == 0x0C || CommandWordSend == 0x0D || TestMode.CommandWordSend == 0x0E)
                            strTip = "温馨提示：左上肢动脉波形幅度减小命令发送成功。";
                    }
                    Dispatcher.BeginInvoke(new Action(() =>
                    {
                        measureViewModel.Tips = strTip;
                    }));
                }
                //------------左下肢动脉放大倍数
                MaxValue = LFpDataOneSec.Max();
                MinValue = LFpDataOneSec.Min();
                DifValue = MaxValue - MinValue;
                if ((MinValue <= 100 && DifValue <= 1000) || (MinValue > 100 && DifValue <= 1100))
                {
                    // '放大倍数加1
                    BpModleIndex = 0x01;
                    SendDataBytes.Clear();
                    SendDataBytes.Add(0x00);
                    SendDataBytes.Add(BpModleIndex);
                    if (serialPortManager.SendDataToMCU(CommandWord.REQ_PWV_INC_GAIN, SendDataBytes, APPSettingUtil.ShortWaitTime) == false)
                    {
                        if (CommandWordSend == 0x00 || CommandWordSend == 0x06 || CommandWordSend == 0x0A || CommandWordSend == 0x0C || CommandWordSend == 0x0D || CommandWordSend == 0x0F)//包含左下肢的有
                            strTip = "温馨提示：左下肢动脉波形幅度增加命令发送失败，请检查设备通信状况！";
                        //AlltestStopWhenPWVfail();
                        return false;
                    }
                }
                if (MaxValue >= 3900 && DifValue > 3700)
                {
                    // '放大倍数减1
                    BpModleIndex = 0x01;
                    SendDataBytes.Clear();
                    SendDataBytes.Add(0x00);
                    SendDataBytes.Add(BpModleIndex);
                    if (serialPortManager.SendDataToMCU(CommandWord.REQ_PWV_DEC_GAIN, SendDataBytes, APPSettingUtil.ShortWaitTime) == false)
                    {
                        if (CommandWordSend == 0x00 || CommandWordSend == 0x06 || CommandWordSend == 0x0A || CommandWordSend == 0x0C || CommandWordSend == 0x0D || CommandWordSend == 0x0F)//包含左下肢的有
                            strTip = "温馨提示：左下肢动脉波形幅度减小命令发送失败，请检查设备通信状况！";
                        //AlltestStopWhenPWVfail();
                        return false;
                    }
                }
                Dispatcher.BeginInvoke(new Action(() =>
                {
                    measureViewModel.Tips = strTip;
                }));
                //------------右上肢动脉放大倍数
                MaxValue = RCpDataOneSec.Max();
                MinValue = RCpDataOneSec.Min();
                DifValue = MaxValue - MinValue;
                if ((MinValue <= 100 && DifValue <= 1000) || (MinValue > 100 && DifValue <= 1100))
                {
                    // '放大倍数加1
                    BpModleIndex = 0x03;
                    SendDataBytes.Clear();
                    SendDataBytes.Add(0x00);
                    SendDataBytes.Add(BpModleIndex);
                    if (serialPortManager.SendDataToMCU(CommandWord.REQ_PWV_INC_GAIN, SendDataBytes, APPSettingUtil.ShortWaitTime) == false)
                    {
                        if (CommandWordSend == 0x00 || CommandWordSend == 0x07 || CommandWordSend == 0x0A || CommandWordSend == 0x0C || CommandWordSend == 0x0E || CommandWordSend == 0x0F)//包含左下肢的有
                            strTip = "温馨提示：右上肢动脉波形幅度增加命令发送失败，请检查设备通信状况！";
                        //AlltestStopWhenPWVfail();
                        return false;
                    }
                }
                if (MaxValue >= 3900 && DifValue > 3700)
                {
                    // '放大倍数减1
                    BpModleIndex = 0x03;
                    SendDataBytes.Clear();
                    SendDataBytes.Add(0x0);
                    SendDataBytes.Add(BpModleIndex);
                    if (serialPortManager.SendDataToMCU(CommandWord.REQ_PWV_DEC_GAIN, SendDataBytes, APPSettingUtil.ShortWaitTime) == false)
                    {
                        if (CommandWordSend == 0x00 || CommandWordSend == 0x07 || CommandWordSend == 0x0A || CommandWordSend == 0x0C || CommandWordSend == 0x0E || CommandWordSend == 0x0F)//包含左下肢的有
                            strTip = "温馨提示：右上肢动脉波形幅度减小命令发送失败，请检查设备通信状况！";
                        //AlltestStopWhenPWVfail();
                        return false;
                    }
                }
                Dispatcher.BeginInvoke(new Action(() =>
                {
                    measureViewModel.Tips = strTip;
                }));
                //------------右下肢动脉放大倍数
                MaxValue = RFpDataOneSec.Max();
                MinValue = RFpDataOneSec.Min();
                DifValue = MaxValue - MinValue;
                if ((MinValue <= 100 && DifValue <= 1000) || (MinValue > 100 && DifValue <= 1100))
                {
                    // '放大倍数加1
                    BpModleIndex = 0x04;
                    SendDataBytes.Clear();
                    SendDataBytes.Add(0x00);
                    SendDataBytes.Add(BpModleIndex);
                    if (serialPortManager.SendDataToMCU(CommandWord.REQ_PWV_INC_GAIN, SendDataBytes, APPSettingUtil.ShortWaitTime) == false)
                    {
                        if (CommandWordSend == 0x00 || CommandWordSend == 0x07 || CommandWordSend == 0x0B || CommandWordSend == 0x0D || CommandWordSend == 0x0E || CommandWordSend == 0x0F)//包含左下肢的有
                            strTip = "温馨提示：右下肢动脉波形幅度增加命令发送失败，请检查设备通信状况！";
                        //AlltestStopWhenPWVfail();
                        return false;
                    }
                }
                if (MaxValue >= 3900 && DifValue > 3700)
                {
                    // '放大倍数减1
                    BpModleIndex = 0x04;
                    SendDataBytes.Clear();
                    SendDataBytes.Add(0x00);
                    SendDataBytes.Add(BpModleIndex);
                    if (serialPortManager.SendDataToMCU(CommandWord.REQ_PWV_DEC_GAIN, SendDataBytes, APPSettingUtil.ShortWaitTime) == false)
                    {
                        if (CommandWordSend == 0x00 || CommandWordSend == 0x07 || CommandWordSend == 0x0B || CommandWordSend == 0x0D || CommandWordSend == 0x0E || CommandWordSend == 0x0F)//包含左下肢的有
                            strTip = "温馨提示：右下肢动脉波形幅度减小命令发送失败，请检查设备通信状况！";
                        //AlltestStopWhenPWVfail();
                        return false;
                    }
                }
                Dispatcher.BeginInvoke(new Action(() =>
                {
                    measureViewModel.Tips = strTip;
                }));
                CountOneSec = 0;
                LCpDataOneSec.Clear();
                LFpDataOneSec.Clear();
                RCpDataOneSec.Clear();
                RFpDataOneSec.Clear();
            }
            //----------------------------2秒钟筛选一次波形----------------------------
            if (CountTwoSec == 500)
            {
                //----------------------------------------------------------左侧
                //'等待时间
                nCpMarkWait[0] = nCpMarkWait[0] + 1;
                nFpMarkWait[0] = nFpMarkWait[0] + 1;
                if (nCpMarkSelect[0] > 2 && nCpMarkSelect[0] <= 8 && nFpMarkSelect[0] > 2 && nFpMarkSelect[0] <= 8)
                {
                    nCpMarkSelect[0] = nCpMarkSelect[0] + 1;
                    nFpMarkSelect[0] = nFpMarkSelect[0] + 1;
                    if (nCpMarkSelect[0] >= 3 && nFpMarkSelect[0] >= 3)
                    {
                        if (CommandWordSend != 0x07)//只要不是只测右侧的
                            strTip = "温馨提示：正在采集左侧脉搏信号，请保持身体稳定！";

                    }
                    //Dispatcher.BeginInvoke(new Action(() =>
                    //{
                    //    measureViewModel.Tips = strTip;
                    //    measureViewModel.TestStatus = (Convert.ToDouble(nFpMarkSelect[0]) / 12 * 100).ToString("f0");
                    //}));
                }
                //----------------------------------------------------------右侧
                //'等待时间 +1
                nCpMarkWait[1] = nCpMarkWait[1] + 1;
                nFpMarkWait[1] = nFpMarkWait[1] + 1;
                if (nCpMarkSelect[1] > 2 && nCpMarkSelect[1] <= 8 && nFpMarkSelect[1] > 2 && nFpMarkSelect[1] <= 8)//-----12.06  如果勾选三个时会出现不同步的情况比如 左踝不测，直接赋值为2 ，当
                {
                    nCpMarkSelect[1] = nCpMarkSelect[1] + 1;
                    nFpMarkSelect[1] = nFpMarkSelect[1] + 1;
                    if (nCpMarkSelect[1] >= 3 && nFpMarkSelect[1] >= 3)
                    {
                        if (CommandWordSend != 0x06)//只要不是只测左侧的
                            strTip = "温馨提示：正在采集右侧脉搏信号，请保持身体稳定！";
                        
                    }
                    Dispatcher.BeginInvoke(new Action(() =>
                    {
                        measureViewModel.Tips = strTip;
                        measureViewModel.TestStatus = (Convert.ToInt32(nCpMarkSelect[1]) / 12 * 100).ToString();
                    }));
                }
                //********************************************
                //       脉搏波采集完成，转到脉搏波分析程序
                //********************************************
                if (nCpMarkSelect[0] >= 9 && nFpMarkSelect[1] >= 9)
                {
                    // 首先确保脉搏数据已经发送完毕
                    // 再转入脉搏波数据处理子程序
                    List<byte> XinYinBytes = new List<byte>();
                    if (TestMode.ECGPCG_Select)
                    {
                        epserialPortManager.SendDataToMCU(CommandWord.HKEndTest, XinYinBytes, APPSettingUtil.ShortWaitTime);
                    }
                    if (serialPortManager.SendDataToMCU(CommandWord.REQ_PWV_STOP, null, APPSettingUtil.ShortWaitTime) == false)
                    {
                        Timer_ACKTimeout.Enabled = false;
                        strTip = "温馨提示：脉搏数据采集完成，脉搏停止指令没有发送成功，请检查设备连接状况！";
                    }
                    else
                    {
                        //脉搏波测量完成
                        PwvMrsFinishFlag = "Yes";
                        PWVStopFist = true;
                        //避免程序卡顿，停止测量指令发送后，休息300ms
                        Thread.Sleep(300);
                        Timer_ACKTimeout.Enabled = true;
                        enumPwvMrsResp = PWVMrsResp.PwvStop;
                    }
                    Dispatcher.BeginInvoke(new Action(() =>
                    {
                        measureViewModel.Tips = strTip;
                    }));
                    return true;
                }
                //----------------------------------左上肢动脉波形处理-----------------------------
                if (TestMode.LBBP_Select)
                {
                    #region
                    if (LCpDataTwoSec.Count > 0)//左上肢最大值
                        MaxValue = (int)LCpDataTwoSec.Max();
                    else
                        MaxValue = 0;
                    if (LCpDataTwoSec.Count > 0)
                        MinValue = (int)LCpDataTwoSec.Min();
                    else
                        MinValue = 0;
                    //差值
                    DifValue = MaxValue - MinValue;
                    //对每次获取的2秒脉搏波数据进行判断处理   
                    if ((nCpMarkSelect[0] <= 2) && MinValue > 50 && DifValue > 600 && DifValue < 3800 && MaxValue < 3800)
                    {
                        clsAcquisition = new AcquireData();
                        //左上肢脉搏波形
                        if (clsAcquisition.SelectWaveform(LCpDataTwoSec, Variable.Sample_Rate) == 1)
                            nCpMarkSelect[0] = nCpMarkSelect[0] + 1;
                    }//
                    CountTwoSec = 0;
                    LCpDataTwoSec.Clear();
                    //0秒内测量未结束，50秒内提示，测量不停止；超过50秒测量自动停止
                    if (nCpMarkSelect[0] < 2 && nCpMarkWait[0] >= 20)
                    {
                        if (nCpMarkWait[0] < 25)
                        {
                            if (CommandWordSend != 0x07 && CommandWordSend != 0x0A && CommandWordSend != 0x0F)//只要不是只测右侧的
                                strTip = "温馨提示：左上肢脉搏信号不好，请静息或重新绑扎后测量";
                            Dispatcher.BeginInvoke(new Action(() =>
                            {
                                 measureViewModel.Tips =strTip;
                            }));
                        }
                        else
                        {
                            SendDataBytes.Clear();
                            SendDataBytes.Add(0x02);
                            SendDataBytes.Add(0x00);
                            if (serialPortManager.SendDataToMCU(CommandWord.REQ_BP_CONTROL, SendDataBytes, APPSettingUtil.ShortWaitTime))
                            {
                                Timer_ACKTimeout.Enabled = true;
                            }
                            strTip = "温馨提示：脉搏波测量停止，请结束测量，重新绑扎后测量";
                            Dispatcher.BeginInvoke(new Action(() =>
                            {
                                 measureViewModel.Tips =strTip;
                            }));
                            return false;
                        }
                    }
                    #endregion
                }
                else if (TestMode.LBBP_Select == false && PwvInflatRunFlag[0] == true)
                {
                    PwvInflatRunFlag[0] = false;
                    nCpMarkSelect[0] = 3;
                }
                //----------------------------------左下肢动脉波形处理-----------------------------
                if (TestMode.LABP_Select == true)
                {
                    #region
                    if (LFpDataTwoSec.Count > 0)
                        MaxValue = (int)LFpDataTwoSec.Max();
                    else
                        MaxValue = 0;
                    if (LFpDataTwoSec.Count > 0)
                        MinValue = (int)LFpDataTwoSec.Min();
                    else
                        MinValue = 0;
                    DifValue = MaxValue - MinValue;
                    //对每次获取的2秒脉搏波数据进行判断处理
                    if ((nFpMarkSelect[0] <= 2) && MinValue > 50 && DifValue > 600 && DifValue < 3800 && MaxValue < 3800)
                    {
                        clsAcquisition = new AcquireData();
                        if (clsAcquisition.SelectWaveform(LFpDataTwoSec, Variable.Sample_Rate) == 1)
                            nFpMarkSelect[0] = nFpMarkSelect[0] + 1;
                    }
                    CountTwoSec = 0;
                    LFpDataTwoSec.Clear();
                    //0秒内测量未结束，50秒内提示，测量不停止；超过50秒测量自动停止
                    if (nFpMarkSelect[0] < 2 && nFpMarkWait[0] >= 20)
                    {
                        if (nFpMarkWait[0] < 25)
                        {
                            if (CommandWordSend != 0x07 && CommandWordSend != 0x0B && CommandWordSend != 0x0E)//只要不是只测右侧的
                                strTip = "温馨提示：左下肢脉搏信号不好，请静息或重新绑扎后测量";
                            Dispatcher.BeginInvoke(new Action(() =>
                            {
                                measureViewModel.Tips = strTip;
                            }));
                        }
                        else
                        {
                            //AlltestStopWhenPWVfail();
                            SendDataBytes.Clear();
                            SendDataBytes.Add(0x02);
                            SendDataBytes.Add(0x00);
                            if (serialPortManager.SendDataToMCU(CommandWord.REQ_BP_CONTROL, SendDataBytes, APPSettingUtil.ShortWaitTime))
                            {
                                Timer_ACKTimeout.Enabled = true;
                            }

                            strTip = "温馨提示：左下肢脉搏信号不好，脉搏结束测量，静息或重新绑扎后测量";
                             measureViewModel.Tips =strTip;
                            Thread.Sleep(1000);
                            if (serialPortManager.SendDataToMCU(CommandWord.REQ_PWV_STOP, null, APPSettingUtil.ShortWaitTime))
                            {
                                Dispatcher.BeginInvoke(new Action(() =>
                                {
                                    measureViewModel.Tips = "阀门已打开！";
                                }));
                                enumPwvMrsResp = PWVMrsResp.PwvStop;
                            }
                            return false;
                        }

                    }
                    #endregion
                }
                else if (TestMode.LABP_Select == false && PwvInflatRunFlag[1] == true)
                {
                    PwvInflatRunFlag[1] = false;
                    nFpMarkSelect[0] = 3;
                }
                //----------------------------------右上肢动脉波形处理-----------------------------
                if (TestMode.RBBP_Select == true)
                {
                    #region
                    if (RCpDataTwoSec.Count > 0)
                        MaxValue = (int)RCpDataTwoSec.Max();
                    else
                        MaxValue = 0;
                    if (RCpDataTwoSec.Count > 0)
                        MinValue = (int)RCpDataTwoSec.Min();
                    else
                        MinValue = 0;
                    DifValue = MaxValue - MinValue;
                    //对每次获取的2秒脉搏波数据进行判断处理
                    if ((nCpMarkSelect[1] <= 2) && MinValue > 50 && DifValue > 600 && DifValue < 3800 && MaxValue < 3800)
                    {
                        clsAcquisition = new AcquireData();
                        if (clsAcquisition.SelectWaveform(RCpDataTwoSec, Variable.Sample_Rate) == 1)
                            nCpMarkSelect[1] = nCpMarkSelect[1] + 1;
                    }
                    CountTwoSec = 0;
                    RCpDataTwoSec.Clear();
                    //0秒内测量未结束，50秒内提示，测量不停止；超过50秒测量自动停止
                    if (nCpMarkSelect[1] < 2 && nCpMarkWait[1] >= 20)
                    {
                        if (nCpMarkWait[1] < 25)
                        {
                            if (TestMode.CommandWordSend != 0x06 && TestMode.CommandWordSend != 0x0B && TestMode.CommandWordSend != 0x0D)//只要不是不测右侧的
                                strTip = "温馨提示：右上肢脉搏信号不好，请静息或重新绑扎后测量";
                            Dispatcher.BeginInvoke(new Action(() =>
                            {
                                measureViewModel.Tips = strTip;
                            }));
                        }
                        else
                        {
                            SendDataBytes.Clear();
                            SendDataBytes.Add(0x02);
                            SendDataBytes.Add(0x00);
                            if (serialPortManager.SendDataToMCU(CommandWord.REQ_BP_CONTROL, SendDataBytes, APPSettingUtil.ShortWaitTime))
                            {
                                Timer_ACKTimeout.Enabled = true;
                            }
                            strTip = "温馨提示：脉搏波测量停止，请结束测量重新绑扎后测量";
                            Dispatcher.BeginInvoke(new Action(() =>
                            {
                                measureViewModel.Tips = strTip;
                            }));
                            //AlltestStopWhenPWVfail();
                            return false;
                        }
                    }
                    #endregion
                }
                else if (TestMode.RBBP_Select == false && PwvInflatRunFlag[2] == true)
                {
                    PwvInflatRunFlag[2] = false;
                    nCpMarkSelect[1] = 3;
                }
                //----------------------------------右下肢动脉波形处理-----------------------------
                if (TestMode.RABP_Select)
                {
                    #region
                    if (RFpDataTwoSec.Count > 0)
                        MaxValue = (int)RFpDataTwoSec.Max();
                    else
                        MaxValue = 0;
                    if (RFpDataTwoSec.Count > 0)
                        MinValue = (int)RFpDataTwoSec.Min();
                    else
                        MinValue = 0;
                    DifValue = MaxValue - MinValue;
                    //对每次获取的2秒脉搏波数据进行判断处理
                    if ((nFpMarkSelect[1] <= 2) && MinValue > 50 && DifValue > 600 && DifValue < 3800 && MaxValue < 3800)
                    {
                        clsAcquisition = new AcquireData();
                        if (clsAcquisition.SelectWaveform(RFpDataTwoSec, Variable.Sample_Rate) == 1)
                            nFpMarkSelect[1] = nFpMarkSelect[1] + 1;
                    }
                    CountTwoSec = 0;
                    RFpDataTwoSec.Clear();
                    //0秒内测量未结束，50秒内提示，测量不停止；超过50秒测量自动停止
                    if (nFpMarkSelect[1] < 2 && nFpMarkWait[1] >= 20)
                    {
                        if (nFpMarkWait[1] < 25)
                        {
                            if (TestMode.CommandWordSend != 0x06 && TestMode.CommandWordSend != 0x0A && TestMode.CommandWordSend != 0x0C)//只要不是不测右侧的
                                strTip = "温馨提示：右下肢脉搏信号不好，请静息或重新绑扎后测量";
                            Dispatcher.BeginInvoke(new Action(() =>
                            {
                                measureViewModel.Tips = strTip;
                            }));
                        }
                        else
                        {
                            SendDataBytes.Clear();
                            SendDataBytes.Add(0x02);
                            SendDataBytes.Add(0x00);
                            if (serialPortManager.SendDataToMCU(CommandWord.REQ_BP_CONTROL, SendDataBytes, APPSettingUtil.ShortWaitTime))
                            {
                                Timer_ACKTimeout.Enabled = true;
                            }
                            strTip = "温馨提示：脉搏波测量停止，请结束测量，重新绑扎后测量";
                            Dispatcher.BeginInvoke(new Action(() =>
                            {
                                measureViewModel.Tips = strTip;
                            }));
                            //AlltestStopWhenPWVfail();
                            return false;
                        }
                    }
                    #endregion
                }
                else if (TestMode.RABP_Select == false && PwvInflatRunFlag[3] == true)
                {
                    PwvInflatRunFlag[3] = false;
                    nFpMarkSelect[1] = 3;
                }
            }
            return true;
        }
        #endregion
        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            bool isVisible = (bool)e.NewValue;//判断当前界面是否可见
            if (!isVisible)
            {
                GC.Collect();//回收内存
            }
        }
        private new void ManipulationBoundaryFeedback(object sender, ManipulationBoundaryFeedbackEventArgs e)
        {
            e.Handled = true;
        }
        /// <summary>
        /// pwv测试时计时器的启动操控(定为跟启动获取压力一样设定为一个计时器)
        /// </summary>
        private void InintTimer()
        {
            //启动检测计时器40秒启动(待修改20秒—)

            TimerCValueACK.Interval = 40000;
            TimerCValueACK.Start();
        }
        public void DisPlayTips(string text)
        {
            Dispatcher.Invoke(new Action(() => {
                if (LastMsg == text)
                {
                    return;
                }
                TipsStruct tipsStruct = new TipsStruct();
                tipsStruct.Name = text;
                measureViewModel.TipsPPGList.Add(tipsStruct);
                LastMsg = text;
            }));
        }
        //'过程名称：PulseWaveformAnalysis
        //'过程功能：波形分析，识别起始点和峰值点计算PTT
        private bool PulseWaveformAnalysis()
        {
            int RawDataNum_Record = 12 * Variable.Sample_Rate;
            string LFpPackData = null;
            string LCpPackData = null;
            //string RCpPackData = null;
            //string RFpPackData = null;
            bool PulseAnalysisFlag = false;
            //double MaxWFMA_temp;
            //double TempPwv;
            //varPWVtemp[0] = 0;//
            //varPWVtemp[1] = 0;//左侧
            //varPWVtemp[2] = 0;//
            //varPWVtemp[3] = 0;//右侧
            //varPWVtemp[4] = 0;//
            //varPWVtemp[5] = 0;//左臂右踝
            //varPWVtemp[6] = 0;//
            //varPWVtemp[7] = 0;//右臂左踝
            //varPWVtemp[8] = 0;
            //varPWVtemp[9] = 0;
            //无论勾选四肢中的几个肢体，最多只需计算四次，不用跟据switch来计算，只需判断是否勾选即可，勾选后即计算对应的肢体pwv ptt
            //if (TestMode.LBBP_Select && TestMode.LABP_Select)
            //{
            //    #region 左侧PWV
            //    FeatureExtraction clsFeature;
            //    clsFeature = new FeatureExtraction();
            //    //确定下肢波形最大可拉升长度
            //    if (Annalyz_BPRecord[0, 0] == 0)
            //    {
            //        Annalyz_BPRecord[0, 0] = Convert.ToInt16(measureViewModel.LBSbp) - Convert.ToInt16(measureViewModel.LBDbp);
            //        Annalyz_BPRecord[1, 0] = Convert.ToInt16(measureViewModel.LASbp) - Convert.ToInt16(measureViewModel.LADbp);
            //    }
            //    if (Annalyz_BPRecord[0, 0] > 0)
            //        MaxWFMA_temp = 10 * Annalyz_BPRecord[1, 0] / Annalyz_BPRecord[0, 0];
            //    else
            //        MaxWFMA_temp = 0;
            //    varMaxWFMA = (int)MaxWFMA_temp;
            //    if (varMaxWFMA < MaxWFMA_temp)
            //        varMaxWFMA = varMaxWFMA - 9;
            //    else
            //        varMaxWFMA = varMaxWFMA - 10;
            //    if (varMaxWFMA < 5)
            //        varMaxWFMA = 5;
            //    if (clsFeature.Identify(LCpRawData, LFpRawData, nBSbp, nBDbp, varMaxWFMA) > 0)
            //    {
            //        PulseAnalysisFlag = false;
            //        return PulseAnalysisFlag;
            //    }
            //    //左侧肢体各值点,用来心电心音测得数据时计算心电指标和衍生指标
            //    GlobalVariable.WFMAPosArrayLeft0 = FeatureExtraction.WFMAPosArray0;
            //    GlobalVariable.WFMAPosArrayLeft1 = FeatureExtraction.WFMAPosArray1;
            //    GlobalVariable.WFMAPosArrayLeft2 = FeatureExtraction.WFMAPosArray2;
            //    GlobalVariable.WFMAPosArrayLeft3 = FeatureExtraction.WFMAPosArray3;
            //    GlobalVariable.WFMAPosArrayLeft4 = FeatureExtraction.WFMAPosArray4;
            //    GlobalVariable.WFMAPosArrayLeft5 = FeatureExtraction.WFMAPosArray5;
            //    GlobalVariable.WFMAPosArrayLeft6 = FeatureExtraction.WFMAPosArray6;
            //    GlobalVariable.WFMAPosArrayLeft7 = FeatureExtraction.WFMAPosArray7;
            //    //PWV和HR脉率值
            //    get_hr = clsFeature.varHr;
            //    get_Lbaptt = clsFeature.varPtt;
            //    //如果Ptt大于0.5*Sample_Rate，说明肱动脉和踝动脉传感器位置反了，
            //    //或者肱动脉信号采集口测量的是踝动脉信号
            //    if (get_Lbaptt > 0.5 * Variable.Sample_Rate)
            //    {
            //        Growl.Info("传导时间异常，请检查左侧肱踝传感器是否正确放置！");
            //        return PulseAnalysisFlag;
            //    }
            //    else
            //    {
            //        TempPwv = (double)Math.Round(userInfo.UserDistance * 10 / get_Lbaptt, 1);
            //        if (TempPwv < 3 || TempPwv > 30)
            //        {
            //            //MyMsgBox.Show("数据采集异常，请重新测量！");
            //            pwvtestFlag = true;//表示已经测试过一次pwv了才会报错采集异常  1130
            //            return PulseAnalysisFlag;
            //        }
            //        else
            //        {
            //            measureViewModel.LeftPWV = TempPwv.ToString();
            //            if (get_bp_hr > 0)
            //                g_typeIndexValue.Hr = get_bp_hr;
            //            else
            //                g_typeIndexValue.Hr = get_hr; //脉搏波波形计算的心率不太准确
            //            g_typeIndexValue.LbaPwv = TempPwv;
            //            g_typeIndexValue.LbaPTT = get_Lbaptt;
            //        }
            //    }
            //    #region//------------------------左上肢动脉-------------------
            //    List<double> LCpSmoothedData = new List<double>();
            //    int LCpSmoothedDataNum = 0;
            //    //滤波后的颈动脉波形
            //    LCpSmoothedData.Clear();
            //    foreach (double Pos in clsFeature.CpSmoothedData)
            //    {
            //        LCpSmoothedData.Add(Pos);
            //        LCpSmoothedDataNum++;
            //    }
            //    LCpNormDataNum = 0;
            //    LCpNormData.Clear();
            //    //去基线后的波形
            //    foreach (int Pos in clsFeature.CpNormData)
            //    {
            //        LCpNormData.Add(Pos);
            //        LCpNormDataNum++;
            //    }
            //    //左上肢动脉起始点(2阶导数)
            //    LCpFootPosNum = 0;
            //    LCpFootPos.Clear();
            //    foreach (int Pos in clsFeature.CpNormFootPos)
            //    {
            //        LCpFootPos.Add(Pos);
            //        LCpFootPosNum++;
            //    }
            //    LCpFirstMaxPointNum = 0;
            //    LCpFirstMaxPoint.Clear();
            //    foreach (int Pos in clsFeature.CpDifSigMaxPos)//此处有问题-----(一阶级导数极大值点）
            //    {
            //        LCpFirstMaxPoint.Add(Pos);
            //        LCpFirstMaxPointNum++;
            //    }
            //    //左上肢动脉峰值点
            //    LCpPeakPosNum = 0;
            //    LCpPeakPos.Clear();
            //    foreach (int Pos in clsFeature.CpNormPeakPos)
            //    {
            //        LCpPeakPos.Add(Pos);
            //        LCpPeakPosNum++;
            //    }
            //    #endregion

            //    #region//------------------------左下肢动脉-------------------
            //    List<double> LFpSmoothedData = new List<double>();
            //    int LFpSmoothedDataNum = 0;
            //    //滤波后的颈动脉波形
            //    LFpSmoothedData.Clear();
            //    foreach (double Pos in clsFeature.FpSmoothedData)
            //    {
            //        LFpSmoothedData.Add(Pos);
            //        LFpSmoothedDataNum = LFpSmoothedDataNum + 1;
            //    }
            //    LFpNormDataNum = 0;
            //    LFpNormData.Clear();
            //    //去基线后的波形
            //    foreach (double Pos in clsFeature.FpNormData)
            //    {
            //        LFpNormData.Add(Pos);
            //        LFpNormDataNum = LFpNormDataNum + 1;
            //    }
            //    //左下肢动脉起始点(2阶导数)
            //    LFpFootPosNum = 0;
            //    LFpFootPos.Clear();
            //    foreach (double Pos in clsFeature.FpNormFootPos)
            //    {
            //        LFpFootPos.Add(Pos);
            //        LFpFootPosNum++;
            //    }
            //    LFpFirstMaxPointNum = 0;
            //    LFpFirstMaxPoint.Clear();
            //    foreach (double Pos in clsFeature.FpDifSigMaxPos)//此处有问题
            //    {
            //        LFpFirstMaxPoint.Add(Pos);
            //        LFpFirstMaxPointNum++;
            //    }
            //    //左下肢动脉峰值点
            //    LFpPeakPosNum = 0;
            //    LFpPeakPos.Clear();
            //    foreach (double Pos in clsFeature.FpNormPeakPos)
            //    {
            //        LFpPeakPos.Add(Pos);
            //        LFpPeakPosNum++;
            //    }
            //    #endregion
            //    varPWVtemp[0] = (double)Math.Round(clsFeature.varPWVtemp[0], 1);//二阶导数ptt
            //    varPWVtemp[1] = (double)Math.Round(clsFeature.varPWVtemp[1], 1);//匹配法varptt
            //    #endregion
            //}
            //if (TestMode.LBBP_Select && TestMode.RABP_Select)
            //{
            //    #region 左臂右踝
            //    FeatureExtraction clsrlsReature;
            //    clsrlsReature = new FeatureExtraction();
            //    //确定下肢波形最大可拉升长度
            //    if (Annalyz_BPRecord[2, 0] == 0)
            //    {
            //        Annalyz_BPRecord[2, 0] = Convert.ToInt16(measureViewModel.LBSbp) - Convert.ToInt16(measureViewModel.LBDbp);
            //        Annalyz_BPRecord[3, 0] = Convert.ToInt16(measureViewModel.RASbp) - Convert.ToInt16(measureViewModel.RADbp);
            //    }
            //    if (Annalyz_BPRecord[2, 0] > 0)
            //        MaxWFMA_temp = 10 * Annalyz_BPRecord[3, 0] / Annalyz_BPRecord[2, 0];
            //    else
            //        MaxWFMA_temp = 0;
            //    varMaxWFMA = (int)MaxWFMA_temp;
            //    if (varMaxWFMA < MaxWFMA_temp)
            //        varMaxWFMA = varMaxWFMA - 9;
            //    else
            //        varMaxWFMA = varMaxWFMA - 10;
            //    if (varMaxWFMA < 5)
            //        varMaxWFMA = 5;
            //    if (clsrlsReature.Identify(LCpRawData, RFpRawData, nBSbp, nBDbp, varMaxWFMA) > 0)
            //    {
            //        PulseAnalysisFlag = false;
            //        return PulseAnalysisFlag;
            //    }
            //    /////这里也能得到一组峰值点，极大值点，拐点
            //    //PWV和HR脉率值
            //    get_hr = clsrlsReature.varHr;
            //    get_LRbaptt = clsrlsReature.varPtt;
            //    //如果Ptt大于0.5*Sample_Rate，说明肱动脉和踝动脉传感器位置反了，
            //    //或者肱动脉信号采集口测量的是踝动脉信号
            //    if (get_LRbaptt > 0.5 * Variable.Sample_Rate)
            //    {
            //        return PulseAnalysisFlag;
            //    }
            //    else
            //    {
            //        TempPwv = (double)Math.Round(userInfo.UserDistance * 10 / get_LRbaptt, 1);//g_typeUserInfo.Distance * 10 / get_ptt;
            //        if (TempPwv < 3 || TempPwv > 30)
            //        {
            //            //MyMsgBox.Show("数据采集异常，请重新测量！");
            //            pwvtestFlag = true;//表示已经测试过一次pwv了才会报错采集异常  1130
            //            return PulseAnalysisFlag;
            //        }
            //        else
            //        {
            //            measureViewModel.LeftPWV = TempPwv.ToString();
            //            if (get_bp_hr > 0)
            //                g_typeIndexValue.Hr = get_bp_hr;
            //            else
            //                g_typeIndexValue.Hr = get_hr; //脉搏波波形计算的心率不太准确
            //            g_typeIndexValue.LRbaPwv = TempPwv;
            //            g_typeIndexValue.LRbaPTT = get_LRbaptt;
            //        }
            //    }
            //    #region 左上肢动脉
            //    List<double> LCpSmoothedData = new List<double>();
            //    int LCpSmoothedDataNum = 0;
            //    //滤波后的颈动脉波形
            //    LCpSmoothedData.Clear();
            //    foreach (double Pos in clsrlsReature.CpSmoothedData)
            //    {
            //        LCpSmoothedData.Add(Pos);
            //        LCpSmoothedDataNum = LCpSmoothedDataNum + 1;
            //    }
            //    LCpNormDataNum = 0;
            //    LCpNormData.Clear();
            //    //去基线后的波形
            //    foreach (int Pos in clsrlsReature.CpNormData)
            //    {
            //        LCpNormData.Add(Pos);
            //        LCpNormDataNum = LCpNormDataNum + 1;
            //    }
            //    //左上肢动脉起始点(2阶导数)
            //    LCpFootPosNum = 0;
            //    LCpFootPos.Clear();
            //    foreach (int Pos in clsrlsReature.CpNormFootPos)
            //    {
            //        LCpFootPos.Add(Pos);
            //        LCpFootPosNum = LCpFootPosNum + 1;
            //    }
            //    RCpFirstMaxPointNum = 0;
            //    RCpFirstMaxPoint.Clear();
            //    foreach (double Pos in clsrlsReature.CpDifSigMaxPos)//此处有问题
            //    {
            //        RCpFirstMaxPoint.Add(Pos);
            //        RCpFirstMaxPointNum = RCpFirstMaxPointNum + 1;
            //    }
            //    //左上肢动脉峰值点
            //    LCpPeakPosNum = 0;
            //    LCpPeakPos.Clear();
            //    foreach (int Pos in clsrlsReature.CpNormPeakPos)
            //    {
            //        LCpPeakPos.Add(Pos);
            //        LCpPeakPosNum = LCpPeakPosNum + 1;
            //    }
            //    #endregion
            //    #region 右下肢
            //    List<double> RFpSmoothedData = new List<double>();
            //    int RFpSmoothedDataNum = 0;
            //    //滤波后的颈动脉波形
            //    RFpSmoothedData.Clear();
            //    foreach (double Pos in clsrlsReature.FpSmoothedData)
            //    {
            //        RFpSmoothedData.Add(Pos);
            //        RFpSmoothedDataNum = RFpSmoothedDataNum + 1;
            //    }
            //    RFpNormDataNum = 0;
            //    RFpNormData.Clear();
            //    //去基线后的波形
            //    foreach (double Pos in clsrlsReature.FpNormData)
            //    {
            //        RFpNormData.Add(Pos);
            //        RFpNormDataNum = RFpNormDataNum + 1;
            //    }
            //    //右下肢动脉起始点(2阶导数)
            //    RFpFootPosNum = 0;
            //    RFpFootPos.Clear();
            //    foreach (double Pos in clsrlsReature.FpNormFootPos)
            //    {
            //        RFpFootPos.Add(Pos);
            //        RFpFootPosNum = RFpFootPosNum + 1;
            //    }
            //    RFpFirstMaxPointNum = 0;
            //    RFpFirstMaxPoint.Clear();
            //    foreach (double Pos in clsrlsReature.FpDifSigMaxPos)//此处有问题（王志成修改） 
            //    {
            //        RFpFirstMaxPoint.Add(Pos);
            //        RFpFirstMaxPointNum = RFpFirstMaxPointNum + 1;
            //    }
            //    //右下肢动脉峰值点
            //    RFpPeakPosNum = 0;
            //    RFpPeakPos.Clear();
            //    foreach (double Pos in clsrlsReature.FpNormPeakPos)
            //    {
            //        RFpPeakPos.Add(Pos);
            //        RFpPeakPosNum = RFpPeakPosNum + 1;
            //    }
            //    #endregion
            //    varPWVtemp[4] = Math.Round(clsrlsReature.varPWVtemp[0], 1);//二阶导数
            //    varPWVtemp[5] = Math.Round(clsrlsReature.varPWVtemp[1], 1);//匹配法
            //    #endregion
            //}
            //if (TestMode.RBBP_Select && TestMode.RABP_Select)
            //{
            //    #region 右侧
            //    FeatureExtraction RclsFeature;
            //    RclsFeature = new FeatureExtraction();
            //    //确定下肢波形最大可拉升长度
            //    if (Annalyz_BPRecord[0, 1] == 0)
            //    {
            //        Annalyz_BPRecord[0, 1] = Convert.ToInt16(measureViewModel.RBSbp) - Convert.ToInt16(measureViewModel.RBDbp);
            //        Annalyz_BPRecord[1, 1] = Convert.ToInt16(measureViewModel.RASbp) - Convert.ToInt16(measureViewModel.RADbp);
            //    }
            //    if (Annalyz_BPRecord[0, 1] > 0)
            //        MaxWFMA_temp = 10 * Annalyz_BPRecord[1, 1] / Annalyz_BPRecord[0, 1];
            //    else
            //        MaxWFMA_temp = 0;
            //    varMaxWFMA = (int)MaxWFMA_temp;
            //    if (varMaxWFMA < MaxWFMA_temp)
            //        varMaxWFMA = varMaxWFMA - 9;
            //    else
            //        varMaxWFMA = varMaxWFMA - 10;
            //    if (varMaxWFMA < 5)
            //        varMaxWFMA = 5;
            //    if (RclsFeature.Identify(RCpRawData, RFpRawData, rBSbp, rBDbp, varMaxWFMA) > 0)
            //    {
            //        PulseAnalysisFlag = false;
            //        return PulseAnalysisFlag;
            //    }
            //    //脉搏波右肢各值点
            //    GlobalVariable.WFMAPosArrayRight0 = FeatureExtraction.WFMAPosArray0;
            //    GlobalVariable.WFMAPosArrayRight1 = FeatureExtraction.WFMAPosArray1;
            //    GlobalVariable.WFMAPosArrayRight2 = FeatureExtraction.WFMAPosArray2;
            //    GlobalVariable.WFMAPosArrayRight3 = FeatureExtraction.WFMAPosArray3;
            //    GlobalVariable.WFMAPosArrayRight4 = FeatureExtraction.WFMAPosArray4;
            //    GlobalVariable.WFMAPosArrayRight5 = FeatureExtraction.WFMAPosArray5;
            //    GlobalVariable.WFMAPosArrayRight6 = FeatureExtraction.WFMAPosArray6;
            //    GlobalVariable.WFMAPosArrayRight7 = FeatureExtraction.WFMAPosArray7;
            //    //PWV和HR值
            //    get_Rbaptt = RclsFeature.varPtt;
            //    //如果Ptt大于0.5*Sample_Rate，说明肱动脉和踝动脉传感器位置反了，
            //    //或者肱动脉信号采集口测量的是踝动脉信号
            //    if (get_Rbaptt > 0.5 * Variable.Sample_Rate)
            //    {
            //        Growl.Info("传导时间异常，请检查右侧肱踝传感器是否正确放置！");
            //        return PulseAnalysisFlag;
            //    }
            //    else
            //    {
            //        TempPwv = (double)Math.Round(userInfo.UserDistance * 10 / get_Rbaptt, 1);//g_typeUserInfo.Distance * 10 / get_ptt;
            //        if (TempPwv < 3 || TempPwv > 30)//临时注释6.1
            //        {
            //            Growl.Info("数据采集异常，请重新测量！");
            //            pwvtestFlag = true;//表示已经测试过一次pwv了才会报错采集异常  1130
            //            return PulseAnalysisFlag;
            //        }
            //        else
            //        {
            //            measureViewModel.RightPWV = TempPwv.ToString();
            //            g_typeIndexValue.RbaPWV = TempPwv;
            //            g_typeIndexValue.RbaPTT = get_Rbaptt;
            //        }
            //    }
            //    #region 右上肢动脉 
            //    List<double> RCpSmoothedData = new List<double>();
            //    int RCpSmoothedDataNum = 0;
            //    //滤波后的颈动脉波形
            //    RCpSmoothedData.Clear();
            //    foreach (double Pos in RclsFeature.CpSmoothedData)
            //    {
            //        RCpSmoothedData.Add(Pos);
            //        RCpSmoothedDataNum = RCpSmoothedDataNum + 1;
            //    }
            //    RCpNormDataNum = 0;
            //    RCpNormData.Clear();
            //    //去基线后的波形
            //    foreach (double Pos in RclsFeature.CpNormData)
            //    {
            //        RCpNormData.Add(Pos);
            //        RCpNormDataNum = RCpNormDataNum + 1;
            //    }
            //    //右上肢动脉起始点(2阶导数)
            //    RCpFootPosNum = 0;
            //    RCpFootPos.Clear();
            //    foreach (double Pos in RclsFeature.CpNormFootPos)
            //    {
            //        RCpFootPos.Add(Pos);
            //        RCpFootPosNum = RCpFootPosNum + 1;
            //    }
            //    RCpFirstMaxPointNum = 0;
            //    RCpFirstMaxPoint.Clear();
            //    foreach (double Pos in RclsFeature.CpDifSigMaxPos)//此处有问题
            //    {
            //        RCpFirstMaxPoint.Add(Pos);
            //        RCpFirstMaxPointNum = RCpFirstMaxPointNum + 1;
            //    }
            //    //右上肢动脉峰值点
            //    RCpPeakPosNum = 0;
            //    RCpPeakPos.Clear();
            //    foreach (double Pos in RclsFeature.CpNormPeakPos)
            //    {
            //        RCpPeakPos.Add(Pos);
            //        RCpPeakPosNum = RCpPeakPosNum + 1;
            //    }
            //    #endregion

            //    #region 右下肢动脉 
            //    List<double> RFpSmoothedData = new List<double>();
            //    int RFpSmoothedDataNum = 0;
            //    //滤波后的颈动脉波形
            //    RFpSmoothedData.Clear();
            //    foreach (double Pos in RclsFeature.FpSmoothedData)
            //    {
            //        RFpSmoothedData.Add(Pos);
            //        RFpSmoothedDataNum = RFpSmoothedDataNum + 1;
            //    }
            //    RFpNormDataNum = 0;
            //    RFpNormData.Clear();
            //    //去基线后的波形
            //    foreach (double Pos in RclsFeature.FpNormData)
            //    {
            //        RFpNormData.Add(Pos);
            //        RFpNormDataNum = RFpNormDataNum + 1;
            //    }
            //    //右下肢动脉起始点(2阶导数)
            //    RFpFootPosNum = 0;
            //    RFpFootPos.Clear();
            //    foreach (double Pos in RclsFeature.FpNormFootPos)
            //    {
            //        RFpFootPos.Add(Pos);
            //        RFpFootPosNum = RFpFootPosNum + 1;
            //    }
            //    RFpFirstMaxPointNum = 0;
            //    RFpFirstMaxPoint.Clear();
            //    foreach (double Pos in RclsFeature.FpDifSigMaxPos)//此处有问题
            //    {
            //        RFpFirstMaxPoint.Add(Pos);
            //        RFpFirstMaxPointNum = RFpFirstMaxPointNum + 1;
            //    }
            //    //左下肢动脉峰值点
            //    RFpPeakPosNum = 0;
            //    RFpPeakPos.Clear();
            //    foreach (double Pos in RclsFeature.FpNormPeakPos)
            //    {
            //        RFpPeakPos.Add(Pos);
            //        RFpPeakPosNum = RFpPeakPosNum + 1;
            //    }
            //    #endregion
            //    varPWVtemp[2] = Math.Round(RclsFeature.varPWVtemp[0], 1);//二阶导数
            //    varPWVtemp[3] = Math.Round(RclsFeature.varPWVtemp[1], 1);//匹配法
            //    #endregion
            //}//右侧
            //if (TestMode.RBBP_Select && TestMode.LABP_Select)
            //{
            //    #region 右臂左踝
            //    FeatureExtraction rlsclsReature;
            //    rlsclsReature = new FeatureExtraction();
            //    //确定下肢波形最大可拉升长度
            //    if (Annalyz_BPRecord[2, 1] == 0)
            //    {
            //        Annalyz_BPRecord[2, 1] = Convert.ToInt16(measureViewModel.RBSbp) - Convert.ToInt16(measureViewModel.RBDbp);
            //        Annalyz_BPRecord[3, 1] = Convert.ToInt16(measureViewModel.LASbp) - Convert.ToInt16(measureViewModel.LADbp);
            //    }
            //    if (Annalyz_BPRecord[2, 1] > 0)
            //        MaxWFMA_temp = 10 * Annalyz_BPRecord[3, 1] / Annalyz_BPRecord[2, 1];
            //    else
            //        MaxWFMA_temp = 0;
            //    varMaxWFMA = (int)MaxWFMA_temp;
            //    if (varMaxWFMA < MaxWFMA_temp)
            //        varMaxWFMA = varMaxWFMA - 9;
            //    else
            //        varMaxWFMA = varMaxWFMA - 10;
            //    if (varMaxWFMA < 5)
            //        varMaxWFMA = 5;
            //    if (rlsclsReature.Identify(RCpRawData, LFpRawData, rBSbp, rBDbp, varMaxWFMA) > 0)
            //    {
            //        PulseAnalysisFlag = false;
            //        return PulseAnalysisFlag;
            //    }
            //    /////这里也能得到一组峰值点，极大值点，拐点
            //    //PWV和HR脉率值
            //    get_hr = rlsclsReature.varHr;
            //    get_RLbaptt = rlsclsReature.varPtt;
            //    //如果Ptt大于0.5*Sample_Rate，说明肱动脉和踝动脉传感器位置反了，
            //    //或者肱动脉信号采集口测量的是踝动脉信号
            //    if (get_RLbaptt > 0.5 * Variable.Sample_Rate)
            //    {
            //        Growl.Info("传导时间异常，请检查左侧肱踝传感器是否正确放置！");
            //        return PulseAnalysisFlag;
            //    }
            //    else
            //    {
            //        TempPwv = (double)Math.Round(userInfo.UserDistance * 10 / get_RLbaptt, 1);//g_typeUserInfo.Distance * 10 / get_ptt;
            //        if (TempPwv < 3 || TempPwv > 30)
            //        {
            //            Growl.Info("数据采集异常，请重新测量！");
            //            pwvtestFlag = true;//表示已经测试过一次pwv了才会报错采集异常  1130
            //            return PulseAnalysisFlag;
            //        }
            //        else
            //        {
            //            measureViewModel.LeftPWV = TempPwv.ToString();
            //            if (get_bp_hr > 0)
            //                g_typeIndexValue.Hr = get_bp_hr;
            //            else
            //                g_typeIndexValue.Hr = get_hr; //脉搏波波形计算的心率不太准确
            //            g_typeIndexValue.RLbaPwv = TempPwv;
            //            g_typeIndexValue.RLbaPTT = get_RLbaptt;
            //        }
            //    }
            //    #region 左下肢动脉 
            //    List<double> LFpSmoothedData = new List<double>();
            //    int LFpSmoothedDataNum = 0;
            //    //滤波后的颈动脉波形
            //    LFpSmoothedData.Clear();
            //    foreach (double Pos in rlsclsReature.FpSmoothedData)
            //    {
            //        LFpSmoothedData.Add(Pos);
            //        LFpSmoothedDataNum = LFpSmoothedDataNum + 1;
            //    }
            //    LFpNormDataNum = 0;
            //    LFpNormData.Clear();
            //    //去基线后的波形
            //    foreach (double Pos in rlsclsReature.FpNormData)
            //    {
            //        LFpNormData.Add(Pos);
            //        LFpNormDataNum = LFpNormDataNum + 1;
            //    }
            //    //左下肢动脉起始点(2阶导数)
            //    LFpFootPosNum = 0;
            //    LFpFootPos.Clear();
            //    foreach (double Pos in rlsclsReature.FpNormFootPos)
            //    {
            //        LFpFootPos.Add(Pos);
            //        LFpFootPosNum = LFpFootPosNum + 1;
            //    }
            //    LFpFirstMaxPointNum = 0;
            //    LFpFirstMaxPoint.Clear();
            //    foreach (double Pos in rlsclsReature.FpDifSigMaxPos)//此处有问题
            //    {
            //        LFpFirstMaxPoint.Add(Pos);
            //        LFpFirstMaxPointNum = LFpFirstMaxPointNum + 1;
            //    }
            //    //左下肢动脉峰值点
            //    LFpPeakPosNum = 0;
            //    LFpPeakPos.Clear();
            //    foreach (double Pos in rlsclsReature.FpNormPeakPos)
            //    {
            //        LFpPeakPos.Add(Pos);
            //        LFpPeakPosNum = LFpPeakPosNum + 1;
            //    }
            //    #endregion

            //    #region 右上肢动脉 
            //    List<double> RCpSmoothedData = new List<double>();
            //    int RCpSmoothedDataNum = 0;
            //    //滤波后的颈动脉波形
            //    RCpSmoothedData.Clear();
            //    foreach (double Pos in rlsclsReature.CpSmoothedData)
            //    {
            //        RCpSmoothedData.Add(Pos);
            //        RCpSmoothedDataNum = RCpSmoothedDataNum + 1;
            //    }
            //    RCpNormDataNum = 0;
            //    RCpNormData.Clear();
            //    //去基线后的波形
            //    foreach (double Pos in rlsclsReature.CpNormData)
            //    {
            //        RCpNormData.Add(Pos);
            //        RCpNormDataNum = RCpNormDataNum + 1;
            //    }
            //    //右上肢动脉起始点(2阶导数)
            //    RCpFootPosNum = 0;
            //    RCpFootPos.Clear();
            //    foreach (double Pos in rlsclsReature.CpNormFootPos)
            //    {
            //        RCpFootPos.Add(Pos);
            //        RCpFootPosNum = RCpFootPosNum + 1;
            //    }
            //    RCpFirstMaxPointNum = 0;
            //    RCpFirstMaxPoint.Clear();
            //    foreach (double Pos in rlsclsReature.CpDifSigMaxPos)//此处有问题
            //    {
            //        RCpFirstMaxPoint.Add(Pos);
            //        RCpFirstMaxPointNum = RCpFirstMaxPointNum + 1;
            //    }
            //    //右上肢动脉峰值点
            //    RCpPeakPosNum = 0;
            //    RCpPeakPos.Clear();
            //    foreach (double Pos in rlsclsReature.CpNormPeakPos)
            //    {
            //        RCpPeakPos.Add(Pos);
            //        RCpPeakPosNum = RCpPeakPosNum + 1;
            //    }
            //    #endregion
            //    varPWVtemp[6] = Math.Round(rlsclsReature.varPWVtemp[0], 1);//二阶导数
            //    varPWVtemp[7] = Math.Round(rlsclsReature.varPWVtemp[1], 1);//匹配法
            //    #endregion
            //}
            if (varPWVtemp[0] != 0)
            {
                varPWVtemp[8] = varPWVtemp[1] / varPWVtemp[0];//左侧
                varPWVtemp[9] = varPWVtemp[3] / varPWVtemp[2];//右侧
                if (varPWVtemp[9] > 1.2 || varPWVtemp[9] < 0.8)//如果比值在这个范围内，则表示误差较小
                {
                    if (varPWVtemp[8] > 1.2 || varPWVtemp[8] < 0.8)
                    {
                        g_typeIndexValue.LbaPwv = (double)Math.Round(userInfo.UserDistance * 10 / varPWVtemp[0], 1);
                        g_typeIndexValue.LbaPTT = varPWVtemp[0];
                        g_typeIndexValue.RbaPWV = (double)Math.Round(userInfo.UserDistance * 10 / varPWVtemp[2], 1);
                        g_typeIndexValue.RbaPTT = varPWVtemp[2];
                    }
                }
            }
            if (varPWVtemp[4] != 0)
            {
                varPWVtemp[8] = varPWVtemp[5] / varPWVtemp[4];//左臂右踝
                varPWVtemp[9] = varPWVtemp[7] / varPWVtemp[6];//右臂左踝
                if (varPWVtemp[9] > 1.2 || varPWVtemp[9] < 0.8)
                {
                    if (varPWVtemp[8] > 1.2 || varPWVtemp[8] < 0.8)
                    {
                        g_typeIndexValue.LRbaPwv = (double)Math.Round(userInfo.UserDistance * 10 / varPWVtemp[4], 1);
                        g_typeIndexValue.LRbaPTT = varPWVtemp[4];
                        g_typeIndexValue.RLbaPwv = (double)Math.Round(userInfo.UserDistance * 10 / varPWVtemp[6], 1);
                        g_typeIndexValue.RLbaPTT = varPWVtemp[6];
                    }
                }
            }
            if (g_typeIndexValue.LbaPwv == 0 && g_typeIndexValue.LRbaPwv != 0)
                g_typeIndexValue.AvaerageLbaPwv = g_typeIndexValue.LRbaPwv;
            else if (g_typeIndexValue.LbaPwv != 0 && g_typeIndexValue.LRbaPwv == 0)
                g_typeIndexValue.AvaerageLbaPwv = g_typeIndexValue.LbaPwv;
            else if (g_typeIndexValue.LbaPwv != 0 && g_typeIndexValue.LRbaPwv != 0)
                g_typeIndexValue.AvaerageLbaPwv = (g_typeIndexValue.LbaPwv + g_typeIndexValue.LRbaPwv) / 2;

            if (g_typeIndexValue.RbaPWV == 0 && g_typeIndexValue.RLbaPwv != 0)
                g_typeIndexValue.AvaeraegRbaPwv = g_typeIndexValue.RLbaPwv;
            else if (g_typeIndexValue.RbaPWV != 0 && g_typeIndexValue.RLbaPwv == 0)
                g_typeIndexValue.AvaeraegRbaPwv = g_typeIndexValue.RbaPWV;
            else if (g_typeIndexValue.RbaPWV != 0 && g_typeIndexValue.RLbaPwv != 0)
                g_typeIndexValue.AvaeraegRbaPwv = (g_typeIndexValue.RbaPWV + g_typeIndexValue.RLbaPwv) / 2;

            if (TestMode.LBBP_Select)
            {
                LCpPackData = stringMerge.MergeString(LCpRawData);
                Variable.ErrorLCP = LCpPackData;
                if (LCpPackData.Length <= 0)
                {
                    Dispatcher.BeginInvoke(new Action(() =>
                    {
                        measureViewModel.Tips = "温馨提示：左上臂脉搏数据保存出错，请重新测量！";
                    }));
                    return PulseAnalysisFlag;
                }
            }
            if (TestMode.LABP_Select)
            {
                LFpPackData = stringMerge.MergeString(LFpRawData);
                Variable.ErrorLFP = LFpPackData;
                if (LFpPackData.Length <= 0)
                {
                    Dispatcher.BeginInvoke(new Action(() =>
                    {
                        measureViewModel.Tips = "温馨提示：左下肢脉搏数据保存出错，请重新测量！";
                    }));
                    return PulseAnalysisFlag;
                }
            }
            //------右侧
            if (TestMode.RBBP_Select)
            {
                RCpPackData = stringMerge.MergeString(RCpRawData);
                Variable.ErrorRCP = RCpPackData;
                if (RCpPackData.Length <= 0)
                {
                    Dispatcher.BeginInvoke(new Action(() =>
                    {
                        measureViewModel.Tips = "温馨提示：右上臂脉搏数据保存出错，请重新测量！";
                    }));
                    return PulseAnalysisFlag;
                }
            }
            if (TestMode.RABP_Select)
            {
                RFpPackData = stringMerge.MergeString(RFpRawData);
                Variable.ErrorRFP = RFpPackData;
                if (RFpPackData.Length <= 0)
                {
                    Dispatcher.BeginInvoke(new Action(() =>
                    {

                        measureViewModel.Tips = "温馨提示：右下肢脉搏数据保存出错，请重新测量！";
                    }));
                    return PulseAnalysisFlag;
                }
            }
            //-----------------计算数据
            Variable.Test_PWV_num = 1;
            string str = "TestDateTime = '" + g_strDateTime + " '";
            pulsedata.PWV_num = 1;
            pulsedata.Hr = g_typeIndexValue.Hr;
            pulsedata.Distance = userInfo.UserDistance;
            pulsedata.LbaPTT = get_Lbaptt;
            pulsedata.LbaPWV = g_typeIndexValue.AvaerageLbaPwv;
            pulsedata.RbaPTT = get_Rbaptt;
            pulsedata.RbaPWV = g_typeIndexValue.AvaeraegRbaPwv;
            pulsedata.LbRabaPTT = get_LRbaptt;//左臂右踝ptt

            pulsedata.LbRabaPWV = g_typeIndexValue.LRbaPwv;
            pulsedata.RbLabaPTT = get_RLbaptt;//右臂左踝ptt
            pulsedata.RbLabaPWV = g_typeIndexValue.RLbaPwv;
            //保存脉搏波数据
            pulsedata.RCpRawData = RCpPackData;
            pulsedata.RFpRawData = RFpPackData;
            pulsedata.LCpRawData = LCpPackData;
            pulsedata.LFpRawData = LFpPackData;
            pulsedata.MrsLocation = Variable.strMrsLocation;
            pulsedata.HaveUpload = "N";
            pulsedata.DeviceNumber = Variable.strSerialNumber;        //产品序列号
            pulsedata.CarSbp = BP_Test_Pressure[0];// 采集波形时左上肢袖带压力值
            //pulsedata.CarDbp = BP_Test_Pressure[1];// 采集波形时左下肢袖带压力值
            //pulsedata.CarPp = BP_Test_Pressure[2];// 采集波形时you上肢袖带压力值
            //pulsedata.Sbp2 = BP_Test_Pressure[3];// 采集波形时you下肢袖带压力值
                                                 //默认保存为否
            pulsedata.IsRepertPrinted = "N";
            pulsedata.IsPDFReportPrinted = "N";
            PulseAnalysisFlag = true;
            return PulseAnalysisFlag;
        }
        private void InitMreasureRelatedControls()
        {
            LeftBraData.Clear();
            LeftAnkData.Clear();
            RightBraData.Clear();
            RightAnkData.Clear();
            AIData.Clear();
            ECGData.Clear();
            PCGData.Clear();
            for (int i = 0; i < 4; i++)
                BpInflateRun[i] = 0;
            Dispatcher.BeginInvoke(new Action(() =>
            {
                measureViewModel.Sevr = "--";
                //measureViewModel.LeftAbi = "--";
                //measureViewModel.RightAbi = "--";
                //measureViewModel.LeftPWV = "--";
                //measureViewModel.RightPWV = "--";
                //测量指标文本框初始化
                measureViewModel.LBSbp = "--";
                measureViewModel.LBDbp = "--";
                measureViewModel.LBMap = "--";

                //measureViewModel.RBSbp = "--";
                //measureViewModel.RBDbp = "--";
                //measureViewModel.RBMap = "--";

                //measureViewModel.LASbp = "--";
                //measureViewModel.LADbp = "--";
                //measureViewModel.LAMap = "--";

                //measureViewModel.RASbp = "--";
                //measureViewModel.RADbp = "--";
                //measureViewModel.RAMap = "--";

                measureViewModel.LBRealPre = "--";
                //measureViewModel.LARealPre = "--";
                //measureViewModel.RBRealPre = "--";
                //measureViewModel.RARealPre = "--";
                //LeftPWV.Visibility = Visibility.Hidden;
                //RightPWV.Visibility = Visibility.Hidden;
                //ECGPCG.Visibility = Visibility.Hidden;
            }));
        }
        //初始化
        private void InitMreasureRelatedVariables()
        {
            sbpCount = 0;
            XYDataCountNum = 0;
            HKDataCountNum = 0;
            get_bp.LtBraBp_Sbp = 0;
            get_bp.LtBraBp_Dbp = 0;
            get_bp.LtBraBp_Map = 0;

            //get_bp.RtBraBp_Sbp = 0;
            //get_bp.RtBraBp_Dbp = 0;
            //get_bp.RtBraBp_Map = 0;

            //get_bp.LtAnkBp_Sbp = 0;
            //get_bp.LtAnkBp_Dbp = 0;
            //get_bp.LtAnkBp_Map = 0;

            //get_bp.RtAnkBp_Sbp = 0;
            //get_bp.RtAnkBp_Dbp = 0;
            //get_bp.RtAnkBp_Map = 0;
            for (int i = 0; i < 2; i++)
            {
                arrGetBpHandle[i].LtBraBp_Sbp = 0;
                arrGetBpHandle[i].LtBraBp_Dbp = 0;
                arrGetBpHandle[i].LtBraBp_Map = 0;

                //arrGetBpHandle[i].RtBraBp_Sbp = 0;
                //arrGetBpHandle[i].RtBraBp_Dbp = 0;
                //arrGetBpHandle[i].RtBraBp_Map = 0;

                //arrGetBpHandle[i].LtAnkBp_Sbp = 0;
                //arrGetBpHandle[i].LtAnkBp_Dbp = 0;
                //arrGetBpHandle[i].LtAnkBp_Map = 0;

                //arrGetBpHandle[i].RtAnkBp_Sbp = 0;
                //arrGetBpHandle[i].RtAnkBp_Dbp = 0;
                //arrGetBpHandle[i].RtAnkBp_Map = 0;
            }
            for (int i = 0; i < 4; i++)
            {
                FourBPStart[i] = 0x0;//判断四肢血压测量是否开始
                FourBPOpenvalve[i] = 0x0;
                FourBPClosevalve[i] = 0x0;
                FourBPFinish[i] = 0x0;
                FourBPOpenfinish[i] = 0x0;
                FourBPEnd[i] = 0x0;
                FourPressGreater[i] = 0x0;
                FourBpFinishPwv[i] = 0x0;
                ValveOpen_Flag[i] = 0;
                BP_ACK_Flag[i] = 0;
                BpInflateRun[i] = 0;
                BPOldPressure[i] = -1;
                PwvInflatRunFlag[i] = true;
                FourBpInflateFinish[i] = 0x0;
            }
            //避免发送信息导致第二次不能测试
            PwvMrsFinishFlag = "No";
            PulseMrsFinishFlag = "No";
            PWV_Fail_num = 0;
            DataCountNum = 0;
            Variable.Test_ABI_num = 0;
            Variable.Test_PWV_num = 0;
            Variable.Test_AI_num = 0;
            DataCountNum = 0;
            nCounter = 0;
            CountTwoSec = 0;
            CountOneSec = 0;
            AICountOneSec = 0;
            AICountTwoSec = 0;
            LCpDataTwoSec.Clear();
            LCpDataOneSec.Clear();
            LFpDataTwoSec.Clear();
            LFpDataOneSec.Clear();
            RCpDataTwoSec.Clear();
            RCpDataOneSec.Clear();
            RFpDataTwoSec.Clear();
            RFpDataOneSec.Clear();
            nCpMarkSelect[0] = 0;
            nCpMarkSelect[1] = 0;
            nFpMarkSelect[0] = 0;
            nFpMarkSelect[1] = 0;

            CpRawDataNum[0] = 0;
            CpRawDataNum[1] = 0;
            FpRawDataNum[0] = 0;
            FpRawDataNum[1] = 0;

            nCpMarkWait[0] = 0;
            nCpMarkWait[1] = 0;
            nFpMarkWait[0] = 0;
            nFpMarkWait[1] = 0;
            #region  //用来采集肱动脉点时的操作
            RCpRawDataNum = 0;
            RFpRawDataNum = 0;
            RCpRawData.Clear();
            RFpRawData.Clear();
            LCpRawData.Clear();
            LFpRawData.Clear();
            RApRawData.Clear();
            Variable.ECGNormData.Clear();
            Variable.PCGNormData.Clear();
            #endregion
            //采集桡动脉
            RpRawDataNum = 0;
            RpRawData.Clear();
            NumOfBpMrs = 0;
            Annalyz_BPRecord[0, 0] = 0;
            Annalyz_BPRecord[1, 0] = 0;
            Annalyz_BPRecord[1, 0] = 0;
            Annalyz_BPRecord[1, 1] = 0;
            ProgressBarStartFlag = false;
            BPInflateValue[0] = 0;
            BPInflateValue[1] = 0;
            BPinflateBeforeBPStartFlag = false;

            WaitForAck = 0;

            WaitForAck = MrsWaitForAck.MrsBP;
            enumPwvMrsResp = PWVMrsResp.PwvStop;
            if (NumOfBpMrs == 0)
            {
                for (int i = 0; i < 2; i++)
                {
                    arrGetBpSave[i].LtBraBp_Sbp = 0;
                    arrGetBpSave[i].LtBraBp_Dbp = 0;
                    arrGetBpSave[i].LtBraBp_Map = 0;

                    arrGetBpSave[i].RtBraBp_Sbp = 0;
                    arrGetBpSave[i].RtBraBp_Dbp = 0;
                    arrGetBpSave[i].RtBraBp_Map = 0;

                    arrGetBpSave[i].LtAnkBp_Sbp = 0;
                    arrGetBpSave[i].LtAnkBp_Dbp = 0;
                    arrGetBpSave[i].LtAnkBp_Map = 0;

                    arrGetBpSave[i].RtAnkBp_Sbp = 0;
                    arrGetBpSave[i].RtAnkBp_Dbp = 0;
                    arrGetBpSave[i].RtAnkBp_Map = 0;
                }
            }
            if (NumOfBpMrs > 0)
            {
                if ((arrGetBpHandle[0].LtBraBp_Sbp > 0) && (arrGetBpHandle[1].LtBraBp_Sbp > 0))
                    NumOfBpMrs = 3;
            }
            Dispatcher.Invoke(new Action(() =>
            {
                timerRealLeftBra.Enabled = false;
            }));
        }
        //当pwv测试时出现问题再次测量时对变量进行初始化
        private void IntiResendTest()
        {
            PWVStopFist = true;
            DataCountNum = 0;
            nCounter = 0;
            CountTwoSec = 0;
            CountOneSec = 0;
            LCpDataTwoSec.Clear();
            LCpDataOneSec.Clear();
            LFpDataTwoSec.Clear();
            LFpDataOneSec.Clear();
            RCpDataTwoSec.Clear();
            RCpDataOneSec.Clear();
            RFpDataTwoSec.Clear();
            RFpDataOneSec.Clear();
            nCpMarkSelect[0] = 0;
            nCpMarkSelect[1] = 0;
            nFpMarkSelect[0] = 0;
            nFpMarkSelect[1] = 0;
            CpRawDataNum[0] = 0;
            CpRawDataNum[1] = 0;
            FpRawDataNum[0] = 0;
            FpRawDataNum[1] = 0;
            nCpMarkWait[0] = 0;
            nCpMarkWait[1] = 0;
            nFpMarkWait[0] = 0;
            nFpMarkWait[1] = 0;
            #region  //用来采集肱动脉点时的操作
            RCpRawDataNum = 0;
            RFpRawDataNum = 0;
            RCpRawData.Clear();
            RFpRawData.Clear();
            LCpRawData.Clear();
            LFpRawData.Clear();
            RApRawData.Clear();
            LeftBraData.Clear();
            LeftAnkData.Clear();
            RightBraData.Clear();
            RightAnkData.Clear();
            RpRawDataNum = 0;
            AIData.Clear();
            ECGData.Clear();
            PCGData.Clear();
            #endregion
            //采集桡动脉
            RpRawDataNum = 0;
            RpRawData.Clear();
            ProgressBarStartFlag = false;
            BPinflateBeforeBPStartFlag = false;
            Dispatcher.Invoke(new Action(() =>
            {
                timerRealLeftBra.Enabled = false;
            }));
        }
        private void Pic_test_Click(object sender, RoutedEventArgs e)
        {
            if(measureViewModel.IsRunning == "Visible")
            {
                Growl.Info("温馨提示：正在分析数据，请稍等！");
                return;
            }
            //每次点击测试按钮都会初始化数据，让缓存清空，图片复位 bPressMrsStart真值互换 重置循环语句的判定
            if (bPressMrsStart && pwvtestFlag == false)
            {
                pulsedata = new PulseDataLocalEntity();//初始化测试数据实体
                InitMreasureRelatedControls();
                InitMreasureRelatedVariables();
                Timer_ACKTimeout.Interval = 3000;
                Timer_ACKTimeout.Enabled = false;
                //转到结束测试
                bPressMrsStart = false;
                bPulseMrsStart = true;
                //开始血压测量前设定各袖带预期压力
                if (Variable.Test_ABI_num == 0)
                {
                    BPInflateValue[0] = 80;
                    BPInflateValue[1] = 80;
                    BPinflateBeforeBPStart(BPInflateValue[0], 0x08);//0x08对应的左右上肢
                }
                //由设置预定压力发送血压测量命令此处不需要//第二次检测时
                else if (Variable.Test_ABI_num == 1)
                {
                    BPInflateValue[0] = (g_typeBpMrsValue.LtBraBp_Sbp + g_typeBpMrsValue.RtBraBp_Sbp) / 2 + 30;
                    //BPInflateValue[1] = (g_typeBpMrsValue.LtAnkBp_Sbp + g_typeBpMrsValue.RtAnkBp_Sbp) / 2 + 30;
                    BPinflateBeforeBPStart(BPInflateValue[0], 0x08);//0x08对应的左右上肢
                }
                workStatus = WorkStatus.StartBPtest;
                Dispatcher.BeginInvoke(new Action(() =>
                {
                    measureViewModel.MeasureBtn_Img = "pack://application:,,,/Resources/Image/Measure/结束测量.png";
                }));
                return;
            }
            else if (bPressMrsStart && pwvtestFlag)//pwvtestflag只有正常测试完成以后才能把值置为真  wzc 0815 添加
            {
                IntiResendTest();
                Dispatcher.BeginInvoke(new Action(() =>
                {
                    measureViewModel.MeasureBtn_Img = "pack://application:,,,/Resources/Image/Measure/结束测量.png";
                }));
                if (TestMode.ECGPCG_Select)//如果勾选了 心电心音在提示
                {
                    d = Dialog.Show(new EPDialog(tabAction));
                    //if (isEP == "确定")
                    //{
                    //    ConutDownThirtySec = 10;//数据保存完成，每一秒执行一次，CountDownThirtySec递减，十秒完成当十秒读完以后开始执行函数进行脉搏波测量
                    //    Timer_ABIDelay.Start();
                    //    Variable.Test_ABI_num = 1;
                    //}
                }
                else
                {
                    ConutDownThirtySec = 10;
                    Timer_ABIDelay.Start();
                    Variable.Test_ABI_num = 1;
                }
                return;
            }
            else if (bPressMrsStart == false)//偶数次点击时进入该语句内
            {
                workStatus = WorkStatus.NoWork;
                //如果图片不可见了，重新变为可见的
                bPressMrsStart = true;
                bPulseMrsStart = true;//脉搏波可测试
                pwvtestFlag = false;
                PWVStopFist = true;
                //PWVStop_Function();
                WaitForAck = 0;
                //容错处理，3秒后有没有接收到停止响应应答，则提示出错
                Thread.Sleep(500);
                Timer_ACKTimeout.Enabled = true;
                Timer_ABIDelay.Enabled = false;
                //发送停止命令
                SendDataBytes.Clear();
                SendDataBytes.Add(0x00);
                SendDataBytes.Add(0x05);
                if (serialPortManager.SendDataToMCU(CommandWord.REQ_BP_STOP, SendDataBytes, 3) == false)
                {
                    Timer_ACKTimeout.Enabled = false;
                    return;
                }
                Thread.Sleep(300);
                SendDataBytes.Clear();
                SendDataBytes.Add(0x00);
                SendDataBytes.Add(0x00);
                serialPortManager.SendDataToMCU(CommandWord.REQ_BP_CONTROL, SendDataBytes, 3);
                Thread.Sleep(500);
                //if (TestMode.ECGPCG_Select)
                //    ECGPCGStop_Function();
                Dispatcher.Invoke(new Action(() =>
                {
                    measureViewModel.Tips = "温馨提示：测量停止！";
                    measureViewModel.MeasureBtn_Img = "pack://application:,,,/Resources/Image/Measure/开始测量.jpg";

                }));
            }
        }
        private void TabCallBackExcute(string t)
        {
            d.Close();
            if (t == "确定")
            {
                {
                    ConutDownThirtySec = 10;//数据保存完成，每一秒执行一次，CountDownThirtySec递减，十秒完成当十秒读完以后开始执行函数进行脉搏波测量
                    Timer_ABIDelay.Start();
                    Variable.Test_ABI_num = 1;
                }
            }
        }
        //开始pwv测量  ////开始进行心血管测量
        private void Commit_Click(object sender, RoutedEventArgs e)
        {
            if (measureViewModel.IsRunning == "Visible")
            {
                Growl.Info("温馨提示：正在分析数据，请稍等！");
                return;
            }
            //if (pulsedata.PWV_num == 1)
            //{
            if (TestMode.AI_Select)
            {
                if (pulsedata.AI_num == 1)
                {
                    this.NavigationService.Navigate(new OpenReportPage(pulsedata));
                }
            }
            else
            {
                Growl.Info("心血管还未测试，请测试完成后再打开报表文件！");
                return;
            }
            //AiTest_Fucntion();
            //}
            //else
            //{
            //    this.NavigationService.Navigate(new OpenReportPage(pulsedata));
            //}
            //}
            //else
            //{
            //    Growl.Info("脉搏波还未测试，请测试完成后再打开报表文件！");
            //    return;
            //}
            //ECGPCGTest_Function();
            //PwvTest_Fucntion();



            #region  只测pwv
            Variable.Test_ABI_num = 1;
            //ConutDownThirtySec = 10;
            //CuffAssignment(CommandWordSend);
            //PWVStartWhenBPStop();// ''''ABI测试完全正常结束，此时方可再次启动PWV测量（测试时注释）
            //Dispatcher.BeginInvoke(new Action(() =>
            //{
            //    measureViewModel.Tips = "温馨提示：正在启动PWV测量……";
            //}));
            IntiResendTest();
            Dispatcher.BeginInvoke(new Action(() =>
            {
                measureViewModel.MeasureBtn_Img = "pack://application:,,,/Resources/Image/Measure/结束测量.png";
            }));
            if (TestMode.ECGPCG_Select)//如果勾选了 心电心音在提示
            {
                d = Dialog.Show(new EPDialog(tabAction));
            }
            else
            {
                ConutDownThirtySec = 10;
                Timer_ABIDelay.Start();
                Variable.Test_ABI_num = 1;
            }
            #endregion
        }
        private void Pic_AI_test_Click(object sender, RoutedEventArgs e)
        {
            if (measureViewModel.IsRunning == "Visible")
            {
                Growl.Info("温馨提示：正在分析数据，请稍等！");
                return;
            }
            if (workStatus == WorkStatus.NoWork && Variable.Test_ABI_num != 0) 
            {
                if (TestMode.AI_Select)
                {
                    Variable.LFpNormData.Clear();
                    Variable.LCpNormData.Clear();
                    //Variable.RFpNormData.Clear();
                    //Variable.RCpNormData.Clear();
                    Variable.AINormData.Clear();
                    RpRawData.Clear();
                    AIData.Clear();
                    DataCount = 0;
                    RpRawDataNum = 0;
                    PWVStopFist = true;
                    measureViewModel.TestStatus = "0";
                    nMarkWait = 0;
                    DataCount = 0;
                    if (bPressMrsAIStart == true)
                    {
                        bPressMrsAIStart = false;
                        SendDataBytes.Clear();
                        SendDataBytes.Add(0x00);
                        SendDataBytes.Add(0x01);
                        serialPortManager.SendDataToMCU(CommandWord.REQ_PWV_START, SendDataBytes, APPSettingUtil.ShortWaitTime);
                        ProgressBarStartFlag = true;
                        workStatus = WorkStatus.StartAItest;
                        Dispatcher.BeginInvoke(new Action(() =>
                        {
                            measureViewModel.AITest_Img= "pack://application:,,,/Resources/Image/Measure/结束测量.png";
                        }));
                    }
                    else
                    {
                        //偶数次点击桡动脉测量按钮后，停止测量
                        PwvMrsFinishFlag = "No";
                        PulseMrsFinishFlag = "No";
                        bPressMrsAIStart = true;
                        serialPortManager.SendDataToMCU(CommandWord.REQ_PWV_STOP, null, APPSettingUtil.ShortWaitTime);
                        workStatus = WorkStatus.NoWork;
                        Dispatcher.BeginInvoke(new Action(() =>
                        {
                            measureViewModel.AITest_Img = "pack://application:,,,/Resources/Image/Measure/心血管测试.png";
                        }));
                    }
                }
                else
                {
                    Growl.Info("未选择心血管测量！");
                }
            }
            else if (workStatus == WorkStatus.StartAItest)
            {
                //偶数次点击桡动脉测量按钮后，停止测量
                PwvMrsFinishFlag = "No";
                PulseMrsFinishFlag = "No";
                bPressMrsAIStart = true;
                serialPortManager.SendDataToMCU(CommandWord.REQ_PWV_STOP, null, APPSettingUtil.ShortWaitTime);
                workStatus = WorkStatus.NoWork;
            }
            else
            {
                Growl.Info("当前有其他任务正在执行，请稍后测试心血管功能。");
            }
        }

        private void ProgressBar_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {

        }

        private void InintTimer(object sender, RoutedEventArgs e)
        {
            pulsedata.userId = "wzc";
            pulsedata.userName = "wzc";
            pulsedata.userSex = "nan";
            pulsedata.userAge = 20;
            pulsedata.userHeight = 175;
            pulsedata.userWeight = 70;
            pulsedata.userBirthday = "2000/10/04";
            pulsedata.TestDateTime = DateTime.Now.ToString();
            pulsedata.TestDate = DateTime.Now.ToString();
            pulsedata.ABI_num = 1;
            pulsedata.Sbp = 123;
            pulsedata.Dbp = 80;
            pulsedata.Pp = 45;
            pulsedata.Map = 86;
            pulsedata.BpHr = 75;

            pulsedata.LeftBraSbp = 132;
            pulsedata.LeftBraDbp = 67;
            pulsedata.LeftBraMap = 56;
            pulsedata.RightBraSbp = 123;
            pulsedata.RightBraDbp = 45;
            pulsedata.RightBraMap = 44;
            pulsedata.LeftAnkSbp = 144;
            pulsedata.LeftAnkDbp = 178;
            pulsedata.LeftAnkMap = 156;
            pulsedata.RightAnkSbp = 111;
            pulsedata.RightAnkDbp = 1112;
            pulsedata.RightAnkMap = 21;
            pulsedata.LeftABI = 1.45;
            pulsedata.RightABI = 3.1;
            //踝动脉较高的SBP除以肱动脉较高的SBP
            pulsedata.ABI = Convert.ToInt32(1.23);
            // '保存两次测量的血压值
            pulsedata.FristBraBP = strFirBraBp;
            pulsedata.SecondBraBP = strSecBraBp;
            //pulsedata.FristAnkBP = strFirAnkBp;
            //pulsedata.SecondAnkBP = strSecAnkBp;
            pulsedata.HaveUpload = "N";
            pulsedata.MrsLocation = Variable.strMrsLocation;
            pulsedata.DeviceNumber = Variable.strSerialNumber;          // '产品序列号
            pulsedata.MeasureMode = PressMrsMode.ToString();
            if (TestMode.LBBP_Select)
            {
                pulsedata.LBBP_Select = "1";
            }
            else
            {
                pulsedata.LBBP_Select = "0";
            }
            //if (TestMode.LABP_Select)
            //{
            //    pulsedata.LABP_Select = "1";
            //}
            //else
            //{
            //    pulsedata.LABP_Select = "0";
            //}
            //if (TestMode.RBBP_Select)
            //{
            //    pulsedata.RBBP_Select = "1";
            //}
            //else
            //{
            //    pulsedata.RBBP_Select = "0";
            //}
            //if(TestMode.RABP_Select)
            //{
            //    pulsedata.RABP_Select = "1";
            //}
            //else
            //{
            //    pulsedata.RABP_Select = "0";
            //}
            pulsedata.AIDiagnosisResult = "心脏功能正常。";
            pulsedata.AIDiagnosisProposal = "建议多食蔬菜，适量运动！";
            pulsedata.TestDateTime = "2023-11-07 09:12:30";
            if (pulsedataDAL.Insert(pulsedata) > 0)
            {
            }
        }
    }
}
